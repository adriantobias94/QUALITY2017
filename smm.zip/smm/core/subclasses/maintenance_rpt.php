<?php
require_once 'maintenance_dd.php';
class maintenance_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'MAINTENANCE_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'maintenance_html';
    var $data_subclass = 'maintenance';
    var $result_page = 'reporter_result_maintenance.php';
    var $cancel_page = 'listview_maintenance.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_maintenance.php';

    function __construct()
    {
        $this->fields        = maintenance_dd::load_dictionary();
        $this->relations     = maintenance_dd::load_relationships();
        $this->subclasses    = maintenance_dd::load_subclass_info();
        $this->table_name    = maintenance_dd::$table_name;
        $this->tables        = maintenance_dd::$table_name;
        $this->readable_name = maintenance_dd::$readable_name;
        $this->get_report_fields();
    }
}
