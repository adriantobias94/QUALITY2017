<?php
require_once 'maintenance_dd.php';
class maintenance extends data_abstraction
{
    var $fields = array();


    function __construct()
    {
        $this->fields     = maintenance_dd::load_dictionary();
        $this->relations  = maintenance_dd::load_relationships();
        $this->subclasses = maintenance_dd::load_subclass_info();
        $this->table_name = maintenance_dd::$table_name;
        $this->tables     = maintenance_dd::$table_name;
    }

    function add($param)
    {
        $this->set_parameters($param);

        if($this->stmt_template=='')
        {
            $this->set_query_type('INSERT');
            $this->set_fields('id, type, start_date, end_date, time, state, reason, status, service_provider, cost, equipment_id, employee_id');
            $this->set_values("?,?,?,?,?,?,?,?,?,?,?,?");

            $bind_params = array('issssssssdii',
                                 &$this->fields['id']['value'],
                                 &$this->fields['type']['value'],
                                 &$this->fields['start_date']['value'],
                                 &$this->fields['end_date']['value'],
                                 &$this->fields['time']['value'],
                                 &$this->fields['state']['value'],
                                 &$this->fields['reason']['value'],
                                 &$this->fields['status']['value'],
                                 &$this->fields['service_provider']['value'],
                                 &$this->fields['cost']['value'],
                                 &$this->fields['equipment_id']['value'],
                                 &$this->fields['employee_id']['value']);

            $this->stmt_prepare($bind_params);
        }

        $this->stmt_execute();
        return $this;
    }

    function edit($param)
    {
        $this->set_parameters($param);

        if($this->stmt_template=='')
        {
            $this->set_query_type('UPDATE');
            $this->set_update("type = ?, start_date = ?, end_date = ?, time = ?, state = ?, reason = ?, status = ?, service_provider = ?, cost = ?, equipment_id = ?, employee_id = ?");
            $this->set_where("id = ?");

            $bind_params = array('ssssssssdiii',
                                 &$this->fields['type']['value'],
                                 &$this->fields['start_date']['value'],
                                 &$this->fields['end_date']['value'],
                                 &$this->fields['time']['value'],
                                 &$this->fields['state']['value'],
                                 &$this->fields['reason']['value'],
                                 &$this->fields['status']['value'],
                                 &$this->fields['service_provider']['value'],
                                 &$this->fields['cost']['value'],
                                 &$this->fields['equipment_id']['value'],
                                 &$this->fields['employee_id']['value'],
                                 &$this->fields['id']['value']);

            $this->stmt_prepare($bind_params);
        }
        $this->stmt_execute();

        return $this;
    }

    function delete($param)
    {
        $this->set_parameters($param);
        $this->set_query_type('DELETE');
        $this->set_where("id = ?");

        $bind_params = array('i',
                             &$this->fields['id']['value']);

        $this->stmt_prepare($bind_params);
        $this->stmt_execute();
        $this->stmt_close();

        return $this;
    }

    function delete_many($param)
    {
        $this->set_parameters($param);
        $this->set_query_type('DELETE');
        $this->set_where("");

        $bind_params = array('',
                             );

        $this->stmt_prepare($bind_params);
        $this->stmt_execute();
        $this->stmt_close();

        return $this;
    }

    function select()
    {
        $this->set_query_type('SELECT');
        $this->exec_fetch('array');
        return $this;
    }

    function check_uniqueness($param)
    {
        $this->set_parameters($param);
        $this->set_query_type('SELECT');
        $this->set_where("id = ?");

        $bind_params = array('i',
                             &$this->fields['id']['value']);

        $this->stmt_prepare($bind_params);
        $this->stmt_execute();
        $this->stmt_close();

        if($this->num_rows > 0) $this->is_unique = FALSE;
        else $this->is_unique = TRUE;

        return $this;
    }

    function check_uniqueness_for_editing($param)
    {
        $this->set_parameters($param);


        $this->set_query_type('SELECT');
        $this->set_where("id = ? AND (id != ?)");

        $bind_params = array('ii',
                             &$this->fields['id']['value'],
                             &$this->fields['id']['value']);

        $this->stmt_prepare($bind_params);
        $this->stmt_execute();
        $this->stmt_close();

        if($this->num_rows > 0) $this->is_unique = FALSE;
        else $this->is_unique = TRUE;

        return $this;
    }
}
