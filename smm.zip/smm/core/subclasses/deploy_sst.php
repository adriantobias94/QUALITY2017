<?php
require_once 'sst_class.php';
require_once 'deploy_dd.php';
class deploy_sst extends sst
{
    function __construct()
    {
        $this->fields        = deploy_dd::load_dictionary();
        $this->relations     = deploy_dd::load_relationships();
        $this->subclasses    = deploy_dd::load_subclass_info();
        $this->table_name    = deploy_dd::$table_name;
        $this->readable_name = deploy_dd::$readable_name;
        parent::__construct();
    }
}
