<?php
require_once 'purchase_data_document_dd.php';
class purchase_data_document_html extends html
{
    function __construct()
    {
        $this->fields        = purchase_data_document_dd::load_dictionary();
        $this->relations     = purchase_data_document_dd::load_relationships();
        $this->subclasses    = purchase_data_document_dd::load_subclass_info();
        $this->table_name    = purchase_data_document_dd::$table_name;
        $this->readable_name = purchase_data_document_dd::$readable_name;
    }
}
