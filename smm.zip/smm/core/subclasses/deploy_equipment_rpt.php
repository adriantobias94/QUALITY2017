<?php
require_once 'deploy_equipment_dd.php';
class deploy_equipment_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'DEPLOY_EQUIPMENT_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'deploy_equipment_html';
    var $data_subclass = 'deploy_equipment';
    var $result_page = 'reporter_result_deploy_equipment.php';
    var $cancel_page = 'listview_deploy_equipment.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_deploy_equipment.php';

    function __construct()
    {
        $this->fields        = deploy_equipment_dd::load_dictionary();
        $this->relations     = deploy_equipment_dd::load_relationships();
        $this->subclasses    = deploy_equipment_dd::load_subclass_info();
        $this->table_name    = deploy_equipment_dd::$table_name;
        $this->tables        = deploy_equipment_dd::$table_name;
        $this->readable_name = deploy_equipment_dd::$readable_name;
        $this->get_report_fields();
    }
}
