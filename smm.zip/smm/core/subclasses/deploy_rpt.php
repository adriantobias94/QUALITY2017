<?php
require_once 'deploy_dd.php';
class deploy_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'DEPLOY_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'deploy_html';
    var $data_subclass = 'deploy';
    var $result_page = 'reporter_result_deploy.php';
    var $cancel_page = 'listview_deploy.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_deploy.php';

    function __construct()
    {
        $this->fields        = deploy_dd::load_dictionary();
        $this->relations     = deploy_dd::load_relationships();
        $this->subclasses    = deploy_dd::load_subclass_info();
        $this->table_name    = deploy_dd::$table_name;
        $this->tables        = deploy_dd::$table_name;
        $this->readable_name = deploy_dd::$readable_name;
        $this->get_report_fields();
    }
}
