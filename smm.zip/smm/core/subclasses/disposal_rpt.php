<?php
require_once 'disposal_dd.php';
class disposal_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'DISPOSAL_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'disposal_html';
    var $data_subclass = 'disposal';
    var $result_page = 'reporter_result_disposal.php';
    var $cancel_page = 'listview_disposal.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_disposal.php';

    function __construct()
    {
        $this->fields        = disposal_dd::load_dictionary();
        $this->relations     = disposal_dd::load_relationships();
        $this->subclasses    = disposal_dd::load_subclass_info();
        $this->table_name    = disposal_dd::$table_name;
        $this->tables        = disposal_dd::$table_name;
        $this->readable_name = disposal_dd::$readable_name;
        $this->get_report_fields();
    }
}
