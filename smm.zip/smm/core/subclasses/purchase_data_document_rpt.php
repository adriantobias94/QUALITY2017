<?php
require_once 'purchase_data_document_dd.php';
class purchase_data_document_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'PURCHASE_DATA_DOCUMENT_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'purchase_data_document_html';
    var $data_subclass = 'purchase_data_document';
    var $result_page = 'reporter_result_purchase_data_document.php';
    var $cancel_page = 'listview_purchase_data_document.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_purchase_data_document.php';

    function __construct()
    {
        $this->fields        = purchase_data_document_dd::load_dictionary();
        $this->relations     = purchase_data_document_dd::load_relationships();
        $this->subclasses    = purchase_data_document_dd::load_subclass_info();
        $this->table_name    = purchase_data_document_dd::$table_name;
        $this->tables        = purchase_data_document_dd::$table_name;
        $this->readable_name = purchase_data_document_dd::$readable_name;
        $this->get_report_fields();
    }
}
