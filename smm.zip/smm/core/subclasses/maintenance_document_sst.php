<?php
require_once 'sst_class.php';
require_once 'maintenance_document_dd.php';
class maintenance_document_sst extends sst
{
    function __construct()
    {
        $this->fields        = maintenance_document_dd::load_dictionary();
        $this->relations     = maintenance_document_dd::load_relationships();
        $this->subclasses    = maintenance_document_dd::load_subclass_info();
        $this->table_name    = maintenance_document_dd::$table_name;
        $this->readable_name = maintenance_document_dd::$readable_name;
        parent::__construct();
    }
}
