<?php
require_once 'sst_class.php';
require_once 'maintenance_dd.php';
class maintenance_sst extends sst
{
    function __construct()
    {
        $this->fields        = maintenance_dd::load_dictionary();
        $this->relations     = maintenance_dd::load_relationships();
        $this->subclasses    = maintenance_dd::load_subclass_info();
        $this->table_name    = maintenance_dd::$table_name;
        $this->readable_name = maintenance_dd::$readable_name;
        parent::__construct();
    }
}
