<?php
require_once 'warranty_dd.php';
class warranty_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'WARRANTY_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'warranty_html';
    var $data_subclass = 'warranty';
    var $result_page = 'reporter_result_warranty.php';
    var $cancel_page = 'listview_warranty.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_warranty.php';

    function __construct()
    {
        $this->fields        = warranty_dd::load_dictionary();
        $this->relations     = warranty_dd::load_relationships();
        $this->subclasses    = warranty_dd::load_subclass_info();
        $this->table_name    = warranty_dd::$table_name;
        $this->tables        = warranty_dd::$table_name;
        $this->readable_name = warranty_dd::$readable_name;
        $this->get_report_fields();
    }
}
