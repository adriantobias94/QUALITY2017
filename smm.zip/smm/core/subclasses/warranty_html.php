<?php
require_once 'warranty_dd.php';
class warranty_html extends html
{
    function __construct()
    {
        $this->fields        = warranty_dd::load_dictionary();
        $this->relations     = warranty_dd::load_relationships();
        $this->subclasses    = warranty_dd::load_subclass_info();
        $this->table_name    = warranty_dd::$table_name;
        $this->readable_name = warranty_dd::$readable_name;
    }
}
