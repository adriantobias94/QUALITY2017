<?php
require_once 'equipment_dd.php';
class equipment_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'EQUIPMENT_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'equipment_html';
    var $data_subclass = 'equipment';
    var $result_page = 'reporter_result_equipment.php';
    var $cancel_page = 'listview_equipment.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_equipment.php';

    function __construct()
    {
        $this->fields        = equipment_dd::load_dictionary();
        $this->relations     = equipment_dd::load_relationships();
        $this->subclasses    = equipment_dd::load_subclass_info();
        $this->table_name    = equipment_dd::$table_name;
        $this->tables        = equipment_dd::$table_name;
        $this->readable_name = equipment_dd::$readable_name;
        $this->get_report_fields();
    }
}
