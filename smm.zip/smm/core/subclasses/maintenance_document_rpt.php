<?php
require_once 'maintenance_document_dd.php';
class maintenance_document_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'MAINTENANCE_DOCUMENT_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'maintenance_document_html';
    var $data_subclass = 'maintenance_document';
    var $result_page = 'reporter_result_maintenance_document.php';
    var $cancel_page = 'listview_maintenance_document.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_maintenance_document.php';

    function __construct()
    {
        $this->fields        = maintenance_document_dd::load_dictionary();
        $this->relations     = maintenance_document_dd::load_relationships();
        $this->subclasses    = maintenance_document_dd::load_subclass_info();
        $this->table_name    = maintenance_document_dd::$table_name;
        $this->tables        = maintenance_document_dd::$table_name;
        $this->readable_name = maintenance_document_dd::$readable_name;
        $this->get_report_fields();
    }
}
