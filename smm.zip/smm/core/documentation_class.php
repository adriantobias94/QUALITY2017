<?php
require 'base_documentation_class.php';
class documentation extends base_documentation
{

}