<?php
require 'base_paged_result_class.php';
class paged_result extends base_paged_result
{

}