<?php
require 'base_reporter_class.php';
class reporter extends base_reporter
{

}