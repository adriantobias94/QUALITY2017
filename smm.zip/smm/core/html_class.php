<?php
require 'base_html_class.php';
class html extends base_html
{
	
}