<?php

require 'path.php';
init_cobalt('sample');

$dbh = cobalt_load_class('employee');
$result = $dbh->execute_query('SELECT * FROM `employee`')->result;
$arr_result = array();
while($row = $result->fetch_assoc())
{
	$arr_result[] = $row;
}

// debug($arr_result);
$html = cobalt_load_class('employee_html');

$html->draw_header('Sample');

$html->draw_container_div_start();
$html->draw_fieldset_header('Sample');
$html->draw_fieldset_body_start();
echo '<table border = 4>';


echo '<tr><td>';
$html->draw_text_field('First Name', 'first_name', $detail_view=FALSE, 'text', $draw_table_tags=TRUE, $extra='');
echo '</td>';
echo '<td>';
$html->draw_select_field($options, 'Gender', 'gender', $draw_table_tags=TRUE, $extra='');
echo '</td></tr>';
echo '</table>';

echo '<br />';

echo '<table border = 2>';
echo '<tr><td>Fields</td><td>Filter</td></tr>';
for($a = 0; $a < count($arr_result);++$a)
{
	extract($arr_result[$a]);
	echo '<tr><td>'.$fname.'</td><td>'.$lname.'</td></tr>';

}
echo '</table>';

$html->draw_fieldset_body_end();
$html->draw_fieldset_footer_start();
$html->draw_submit_cancel();
$html->draw_fieldset_footer_end();
$html->draw_container_div_end();


