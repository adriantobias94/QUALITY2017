<?php

require 'path.php';
init_cobalt();


if(xsrf_guard())
{
	//init_var($_POST['back']);


	if($_POST['btn_back']){
		redirect(HOME_PAGE);
	}
	
}

// debug($arr_result);

$html = cobalt_load_class('equipment_html');
$html->draw_header('Report Type Result', $message, $message_type);

$html->draw_container_div_start();
$html->draw_fieldset_header('Report by Type Result');
?>



<?php

$html->draw_fieldset_body_start();

$type = $_GET['type'];

$dbh = cobalt_load_class('equipment');
$result = $dbh->execute_query('SELECT * FROM `equipment` WHERE `type` ="'.$type.'"')->result;
$arr_result = array();
while($row = $result->fetch_assoc()){

	$arr_result[] = $row;
}

?>
<table class="table table-bordered"><thead>
<tr><th>Name</th><th>Type</th><th>Function</th></tr>
</thead><tbody>
 
<?php
    

for($a = 0; $a < count($arr_result);++$a)
{
	extract($arr_result[$a]);
	echo '<tr><td>'.$name.'</td><td>'.$type.'</td><td>'.$function.'</tr>';

}
echo '</tbody></table>';

$html->draw_fieldset_body_end();
$html->draw_fieldset_footer_start();
$html->draw_button($type="back");
$html->draw_fieldset_footer_end();
$html->draw_container_div_end();
