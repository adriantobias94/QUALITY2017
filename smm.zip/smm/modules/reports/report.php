<?php
require 'path.php';
init_cobalt('report');

if(xsrf_guard())
{
    init_var($_POST['btn_cancel']);
    init_var($_POST['btn_submit']);


    if($_POST['btn_cancel'])
    {
        redirect(HOME_PAGE);
    }

    if($_POST['btn_submit'])
	{
		init_var($message);
		switch($_POST['reporttype'])
		{
			case 'Report by Type' :  $target_page = 'report_type.php'; break;
			case 'Report by Brand':  $target_page = 'report_brand.php'; break;
			case 'Report by Price':  $target_page = 'report_price.php'; break;
			default 			  :  $message = 'Please select a valid report type';
		}

		if($message != '')
		{
			$message_type = 'error';
		}
		else
		{
			redirect($target_page);
		}
	}


}





$html = cobalt_load_class('employee_html');

$html->draw_header('Report', $message, $message_type);

$html->draw_container_div_start();
$html->draw_fieldset_header('Report');
$html->draw_fieldset_body_start();

$reports = array('items' =>array('Report by Type','Report by Brand','Report by Price'),
                 'values'=>array('Report by Type','Report by Brand','Report by Price'));
echo '<table>';

echo '<tr><td>';
$html->draw_select_field($reports, 'Report Type', 'reporttype', $draw_table_tags=TRUE, $extra='');
echo '</td></tr>';
echo '</table>';

$html->draw_fieldset_body_end();
$html->draw_fieldset_footer_start();
$html->draw_submit_cancel();
$html->draw_fieldset_footer_end();
$html->draw_container_div_end();