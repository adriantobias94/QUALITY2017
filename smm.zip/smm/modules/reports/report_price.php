<?php

require 'path.php';
init_cobalt();


if(xsrf_guard())
{
	init_var($_POST['btn_cancel']);
    init_var($_POST['btn_submit']);



    if($_POST['btn_cancel'])
    {
        redirect("report.php");
    }

    if($_POST['btn_submit'])
	{
		init_var($message);
		
		

		if($message != '')
		{
			$message_type = 'error';
		}
		else
		{
			redirect("report_price_type.php?price=".$_POST['price']);
		}
	}
}


$dbh_equipment = cobalt_load_class('equipment');
$dbh_equipment->select();
//debug($arr_brand);

$html = cobalt_load_class('equipment_html');
$html->draw_header('Report Price', $message, $message_type);


$html->draw_container_div_start();
$html->draw_fieldset_header('Report by Price');
$html->draw_fieldset_body_start();

echo '<table>';
echo '<tr><td>';
//$html->draw_text_field('Brand', 'brand', $detail_view=FALSE, 'text', $draw_table_tags=TRUE, $extra='');
$html->draw_text_field('Minimum Price', 'price', $detail_view=FALSE, 'text', $draw_table_tags=TRUE, $extra='');

echo '</td></tr>';
echo '</table>';

$html->draw_fieldset_body_end();
$html->draw_fieldset_footer_start();
$html->draw_submit_cancel();
$html->draw_fieldset_footer_end();
$html->draw_container_div_end();
