<?php

require 'path.php';
init_cobalt();


if(xsrf_guard())

{
	init_var($_POST['btn_cancel']);
    init_var($_POST['btn_submit']);



    if($_POST['btn_cancel'])
    {
        redirect("report.php");
    }

    if($_POST['btn_submit'])
	{
		init_var($message);
		
		

		if($message != '')
		{
			$message_type = 'error';
		}
		else
		{
			redirect("report_type_type.php?type=".$_POST['type']);
		}
	}




}
$dbh_equipment = cobalt_load_class('equipment');
$dbh_equipment->select();

$arr_brand['items'] = $dbh_equipment->dump['type'];
$arr_brand['values'] = $dbh_equipment->dump['type'];
$html = cobalt_load_class('equipment_html');
$html->draw_header('Report Type', $message, $message_type);




$html->draw_container_div_start();
$html->draw_fieldset_header('Report by Type');
$html->draw_fieldset_body_start();

echo '<table>';
echo '<tr><td>';
$html->draw_select_field($arr_brand, 'Type', 'type');
echo '</td></tr>';
echo '</table>';

$html->draw_fieldset_body_end();
$html->draw_fieldset_footer_start();
$html->draw_submit_cancel();
$html->draw_fieldset_footer_end();
$html->draw_container_div_end();


