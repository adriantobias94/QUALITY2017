<?php

require 'path.php';
init_cobalt();

init_var($price);

if(xsrf_guard())
{
	//init_var($_POST['back']);


	if($_POST['btn_back']){
		//brpt();
		redirect(HOME_PAGE); 
	}
	
}

if ($_GET['price']){
	$price = $_GET['price'];
	$dbh = cobalt_load_class('equipment');
	$result = $dbh->execute_query('SELECT * FROM `equipment` WHERE `price` >="'.$price.'"')->result;
	$arr_result = array();
	while($row = $result->fetch_assoc()){

		$arr_result[] = $row;
	}
}


// debug($arr_result);

$html = cobalt_load_class('equipment_html');
$html->draw_header('Report Price Result', $message, $message_type);

$html->draw_container_div_start();
$html->draw_fieldset_header('Report by Price Result');
$html->draw_fieldset_body_start();


?>
<table class="table table-bordered"><thead>
<tr><th>Name</th><th>Brand</th><th>Price</th></tr>
</thead><tbody>

<?php

if($_GET['price']){
	for($a = 0; $a < count($arr_result);++$a)
	{
		extract($arr_result[$a]);
		echo '<tr><td>'.$name.'</td><td>'.$brand.'</td><td>'.$price.'</td></tr>';
	}
}
echo '</table>';

$html->draw_fieldset_body_end();
$html->draw_fieldset_footer_start();
$html->draw_button($type="back");
$html->draw_fieldset_footer_end();
$html->draw_container_div_end();
