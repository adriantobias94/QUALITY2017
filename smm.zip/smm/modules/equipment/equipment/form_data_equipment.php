<?php
require 'components/get_listview_referrer.php';

require 'subclasses/equipment.php';
$dbh_equipment = new equipment;
$dbh_equipment->set_where("id='" . quote_smart($id) . "'");
if($result = $dbh_equipment->make_query()->result)
{
    $data = $result->fetch_assoc();
    extract($data);

}

