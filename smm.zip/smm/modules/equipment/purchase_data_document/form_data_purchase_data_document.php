<?php
require 'components/get_listview_referrer.php';

require 'subclasses/purchase_data_document.php';
$dbh_purchase_data_document = new purchase_data_document;
$dbh_purchase_data_document->set_where("id='" . quote_smart($id) . "'");
if($result = $dbh_purchase_data_document->make_query()->result)
{
    $data = $result->fetch_assoc();
    extract($data);

}

