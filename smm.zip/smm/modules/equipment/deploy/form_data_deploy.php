<?php
require 'components/get_listview_referrer.php';

require 'subclasses/deploy.php';
$dbh_deploy = new deploy;
$dbh_deploy->set_where("id='" . quote_smart($id) . "'");
if($result = $dbh_deploy->make_query()->result)
{
    $data = $result->fetch_assoc();
    extract($data);

    $data = explode('-',$deployDate);
    if(count($data) == 3)
    {
        $deployDate_year = $data[0];
        $deployDate_month = $data[1];
        $deployDate_day = $data[2];
    }
}

