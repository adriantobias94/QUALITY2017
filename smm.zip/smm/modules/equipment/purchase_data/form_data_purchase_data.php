<?php
require 'components/get_listview_referrer.php';

require 'subclasses/purchase_data.php';
$dbh_purchase_data = new purchase_data;
$dbh_purchase_data->set_where("id='" . quote_smart($id) . "'");
if($result = $dbh_purchase_data->make_query()->result)
{
    $data = $result->fetch_assoc();
    extract($data);

    $data = explode('-',$purchase_date);
    if(count($data) == 3)
    {
        $purchase_date_year = $data[0];
        $purchase_date_month = $data[1];
        $purchase_date_day = $data[2];
    }
    $data = explode('-',$receive_date);
    if(count($data) == 3)
    {
        $receive_date_year = $data[0];
        $receive_date_month = $data[1];
        $receive_date_day = $data[2];
    }
}

require_once 'subclasses/purchase_data_document.php';
$dbh_purchase_data_document = new purchase_data_document;
$dbh_purchase_data_document->set_fields('document, remarks');
$dbh_purchase_data_document->set_where("purchase_data_id='" . quote_smart($id) . "'");
if($result = $dbh_purchase_data_document->make_query()->result)
{
    $num_purchase_data_document = $dbh_purchase_data_document->num_rows;
    for($a=0; $a<$num_purchase_data_document; $a++)
    {
        $data = $result->fetch_row();
        $cf_purchase_data_document_document[$a] = $data[0];
        $cf_purchase_data_document_remarks[$a] = $data[1];
    }
}

