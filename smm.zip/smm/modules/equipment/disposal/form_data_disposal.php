<?php
require 'components/get_listview_referrer.php';

require 'subclasses/disposal.php';
$dbh_disposal = new disposal;
$dbh_disposal->set_where("id='" . quote_smart($id) . "'");
if($result = $dbh_disposal->make_query()->result)
{
    $data = $result->fetch_assoc();
    extract($data);

    $data = explode('-',$remove_date);
    if(count($data) == 3)
    {
        $remove_date_year = $data[0];
        $remove_date_month = $data[1];
        $remove_date_day = $data[2];
    }
    $data = explode('-',$dispose_date);
    if(count($data) == 3)
    {
        $dispose_date_year = $data[0];
        $dispose_date_month = $data[1];
        $dispose_date_day = $data[2];
    }
}

