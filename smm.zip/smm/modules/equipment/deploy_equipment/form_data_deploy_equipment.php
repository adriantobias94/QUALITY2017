<?php
require 'components/get_listview_referrer.php';

require 'subclasses/deploy_equipment.php';
$dbh_deploy_equipment = new deploy_equipment;
$dbh_deploy_equipment->set_where("id='" . quote_smart($id) . "'");
if($result = $dbh_deploy_equipment->make_query()->result)
{
    $data = $result->fetch_assoc();
    extract($data);

}

