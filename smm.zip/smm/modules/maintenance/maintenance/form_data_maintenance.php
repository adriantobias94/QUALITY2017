<?php
require 'components/get_listview_referrer.php';

require 'subclasses/maintenance.php';
$dbh_maintenance = new maintenance;
$dbh_maintenance->set_where("id='" . quote_smart($id) . "'");
if($result = $dbh_maintenance->make_query()->result)
{
    $data = $result->fetch_assoc();
    extract($data);

    $data = explode('-',$start_date);
    if(count($data) == 3)
    {
        $start_date_year = $data[0];
        $start_date_month = $data[1];
        $start_date_day = $data[2];
    }
    $data = explode('-',$end_date);
    if(count($data) == 3)
    {
        $end_date_year = $data[0];
        $end_date_month = $data[1];
        $end_date_day = $data[2];
    }
}

require_once 'subclasses/maintenance_document.php';
$dbh_maintenance_document = new maintenance_document;
$dbh_maintenance_document->set_fields('document, remarks');
$dbh_maintenance_document->set_where("maintenance_id='" . quote_smart($id) . "'");
if($result = $dbh_maintenance_document->make_query()->result)
{
    $num_maintenance_document = $dbh_maintenance_document->num_rows;
    for($a=0; $a<$num_maintenance_document; $a++)
    {
        $data = $result->fetch_row();
        $cf_maintenance_document_document[$a] = $data[0];
        $cf_maintenance_document_remarks[$a] = $data[1];
    }
}

