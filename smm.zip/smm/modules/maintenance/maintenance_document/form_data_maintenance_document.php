<?php
require 'components/get_listview_referrer.php';

require 'subclasses/maintenance_document.php';
$dbh_maintenance_document = new maintenance_document;
$dbh_maintenance_document->set_where("id='" . quote_smart($id) . "'");
if($result = $dbh_maintenance_document->make_query()->result)
{
    $data = $result->fetch_assoc();
    extract($data);

}

