<?php
//List of modules (tables) for the table of contents to show
//The format is doc_subclass_name => doc_dir_name
$content_pages = array(
        'assignee_doc'=>'assignee',
        'assignment_doc'=>'assignment',
        'corrective_doc'=>'corrective',
        'corrective_document_doc'=>'corrective_document',
        'disposal_doc'=>'disposal',
        'employee_doc'=>'employee',
        'equipment_doc'=>'equipment',
        'preventive_doc'=>'preventive',
        'preventive_history_doc'=>'preventive_history',
        'purchase_data_doc'=>'purchase_data',
        'purchase_data_document_doc'=>'purchase_data_document',
        'warranty_doc'=>'warranty',
);