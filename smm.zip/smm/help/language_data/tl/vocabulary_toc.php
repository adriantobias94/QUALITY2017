<?php
$project_name = GLOBAL_PROJECT_NAME;
$toc_title = 'Dokumentasyon | Talaan ng Nilalaman';