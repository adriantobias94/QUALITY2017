<?php
require 'path.php';
init_cobalt();
require 'subclasses/corrective_document_doc.php';
$obj_doc = new corrective_document_doc;
$obj_doc->auto_doc();