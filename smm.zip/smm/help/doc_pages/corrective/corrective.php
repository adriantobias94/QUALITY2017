<?php
require 'path.php';
init_cobalt();
require 'subclasses/corrective_doc.php';
$obj_doc = new corrective_doc;
$obj_doc->auto_doc();