<?php
require 'path.php';
init_cobalt();
require 'subclasses/disposal_doc.php';
$obj_doc = new disposal_doc;
$obj_doc->auto_doc();