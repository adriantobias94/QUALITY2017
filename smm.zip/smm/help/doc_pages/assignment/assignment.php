<?php
require 'path.php';
init_cobalt();
require 'subclasses/assignment_doc.php';
$obj_doc = new assignment_doc;
$obj_doc->auto_doc();