<?php
require 'path.php';
init_cobalt();
require 'subclasses/equipment_doc.php';
$obj_doc = new equipment_doc;
$obj_doc->auto_doc();