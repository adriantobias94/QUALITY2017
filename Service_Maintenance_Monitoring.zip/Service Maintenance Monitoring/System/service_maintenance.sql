-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2017 at 12:16 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `service_maintenance`
--

-- --------------------------------------------------------

--
-- Table structure for table `cobalt_reporter`
--

CREATE TABLE `cobalt_reporter` (
  `module_name` varchar(255) NOT NULL,
  `report_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `show_field` blob NOT NULL,
  `operator` blob NOT NULL,
  `text_field` blob NOT NULL,
  `sum_field` blob NOT NULL,
  `count_field` blob NOT NULL,
  `group_field1` blob NOT NULL,
  `group_field2` blob NOT NULL,
  `group_field3` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cobalt_reporter`
--

INSERT INTO `cobalt_reporter` (`module_name`, `report_name`, `username`, `show_field`, `operator`, `text_field`, `sum_field`, `count_field`, `group_field1`, `group_field2`, `group_field3`) VALUES
('ASSIGNMENT_REPORT_CUSTOM', 'Ad', 'root', 0x613a31323a7b693a303b733a323a224944223b693a313b733a31373a225b45717569706d656e742049645d204944223b693a323b733a31393a225b45717569706d656e742049645d204e616d65223b693a333b733a31393a225b45717569706d656e742049645d2054797065223b693a343b733a32303a225b45717569706d656e742049645d204272616e64223b693a353b733a32363a225b45717569706d656e742049645d204465736372697074696f6e223b693a363b733a32333a225b45717569706d656e742049645d2046756e6374696f6e223b693a373b733a32303a225b45717569706d656e742049645d205072696365223b693a383b733a31363a225b41737369676e65652049645d204944223b693a393b733a31393a225b41737369676e65652049645d20526f6f6d73223b693a31303b733a32323a225b41737369676e65652049645d204c6f636174696f6e223b693a31313b733a32353a225b41737369676e65652049645d204465706c6f792044617465223b7d, 0x613a31323a7b693a303b733a303a22223b693a313b733a303a22223b693a323b733a303a22223b693a333b733a303a22223b693a343b733a303a22223b693a353b733a303a22223b693a363b733a303a22223b693a373b733a303a22223b693a383b733a303a22223b693a393b733a31323a22455155414c20544f20283d29223b693a31303b733a303a22223b693a31313b733a303a22223b7d, 0x613a31323a7b693a303b733a303a22223b693a313b733a303a22223b693a323b733a303a22223b693a333b733a303a22223b693a343b733a303a22223b693a353b733a303a22223b693a363b733a303a22223b693a373b733a303a22223b693a383b733a303a22223b693a393b733a343a2231303130223b693a31303b733a303a22223b693a31313b733a303a22223b7d, '', '', '', '', ''),
('DISPOSAL_REPORT_CUSTOM', 'ASD', 'root', 0x613a31373a7b693a303b733a323a224944223b693a313b733a363a224d6574686f64223b693a323b733a373a2252656d61726b73223b693a333b733a31313a2252656d6f76652044617465223b693a343b733a31323a22446973706f73652044617465223b693a353b733a31373a225b45717569706d656e742049645d204944223b693a363b733a31393a225b45717569706d656e742049645d204e616d65223b693a373b733a31393a225b45717569706d656e742049645d2054797065223b693a383b733a32303a225b45717569706d656e742049645d204272616e64223b693a393b733a32363a225b45717569706d656e742049645d204465736372697074696f6e223b693a31303b733a32333a225b45717569706d656e742049645d2046756e6374696f6e223b693a31313b733a32303a225b45717569706d656e742049645d205072696365223b693a31323b733a32313a225b45717569706d656e742049645d20526174696e67223b693a31333b733a31363a225b41737369676e65652049645d204944223b693a31343b733a31393a225b41737369676e65652049645d20526f6f6d73223b693a31353b733a32323a225b41737369676e65652049645d204c6f636174696f6e223b693a31363b733a32353a225b41737369676e65652049645d204465706c6f792044617465223b7d, 0x613a31373a7b693a303b733a303a22223b693a313b733a303a22223b693a323b733a303a22223b693a333b733a303a22223b693a343b733a303a22223b693a353b733a303a22223b693a363b733a303a22223b693a373b733a303a22223b693a383b733a303a22223b693a393b733a303a22223b693a31303b733a303a22223b693a31313b733a303a22223b693a31323b733a303a22223b693a31333b733a303a22223b693a31343b733a303a22223b693a31353b733a303a22223b693a31363b733a303a22223b7d, 0x613a31373a7b693a303b733a303a22223b693a313b733a303a22223b693a323b733a303a22223b693a333b733a303a22223b693a343b733a303a22223b693a353b733a303a22223b693a363b733a303a22223b693a373b733a303a22223b693a383b733a303a22223b693a393b733a303a22223b693a31303b733a303a22223b693a31313b733a303a22223b693a31323b733a303a22223b693a31333b733a303a22223b693a31343b733a303a22223b693a31353b733a303a22223b693a31363b733a303a22223b7d, 0x613a313a7b693a303b733a31313a2252656d6f76652044617465223b7d, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `cobalt_sst`
--

CREATE TABLE `cobalt_sst` (
  `auto_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `config_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `deploy`
--

CREATE TABLE `deploy` (
  `id` int(11) NOT NULL,
  `room` char(4) NOT NULL,
  `location` varchar(255) NOT NULL,
  `deployDate` date NOT NULL,
  `employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deploy`
--

INSERT INTO `deploy` (`id`, `room`, `location`, `deployDate`, `employee_id`) VALUES
(3, '1010', '10th Floor', '2017-04-09', 1);

-- --------------------------------------------------------

--
-- Table structure for table `deploy_equipment`
--

CREATE TABLE `deploy_equipment` (
  `id` int(11) NOT NULL,
  `equipment_id` int(11) NOT NULL,
  `deploy_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deploy_equipment`
--

INSERT INTO `deploy_equipment` (`id`, `equipment_id`, `deploy_id`) VALUES
(6, 10, 3),
(7, 11, 3);

-- --------------------------------------------------------

--
-- Table structure for table `disposal`
--

CREATE TABLE `disposal` (
  `id` int(11) NOT NULL,
  `reason` text NOT NULL,
  `method` text NOT NULL,
  `remarks` text NOT NULL,
  `remove_date` date NOT NULL,
  `dispose_date` date NOT NULL,
  `equipment_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `disposal`
--

INSERT INTO `disposal` (`id`, `reason`, `method`, `remarks`, `remove_date`, `dispose_date`, `equipment_id`) VALUES
(7, '', 'Throw into Electronic Basket', 'No Difficulty', '2017-04-09', '2017-04-09', 10),
(8, 'Broken Screen', 'Disposing Unusable Parts', 'Difficulty was easy', '2017-03-10', '2017-03-13', 11);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `mname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `birthday` date NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `fname`, `mname`, `lname`, `position`, `birthday`, `status`) VALUES
(1, 'Rafael', 'Secret', 'Ochotorena', 'Staff Boy', '1997-06-22', 'Single'),
(2, 'Von Matthew', 'Sogocio', 'Alfafara', 'Software Developer', '1997-01-24', 'Separated');

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `function` text NOT NULL,
  `price` double NOT NULL,
  `rating` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`id`, `name`, `type`, `brand`, `description`, `function`, `price`, `rating`) VALUES
(10, 'C008', 'USB', 'ADATA', 'X', 'X', 850, 8),
(11, 'N4050', 'Laptop', 'DELL', 'Laptop for Educational Uses', 'ASD', 20000, 7);

-- --------------------------------------------------------

--
-- Table structure for table `maintenance`
--

CREATE TABLE `maintenance` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `time` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `reason` text NOT NULL,
  `status` varchar(255) NOT NULL,
  `service_provider` varchar(255) NOT NULL,
  `cost` double NOT NULL,
  `equipment_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maintenance`
--

INSERT INTO `maintenance` (`id`, `type`, `start_date`, `end_date`, `time`, `state`, `reason`, `status`, `service_provider`, `cost`, `equipment_id`, `employee_id`) VALUES
(1, 'Corrective', '2017-04-09', '2017-04-15', '7:30', 'Subpar', 'AS', 'Incomplete', 'ADATA', 8500, 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `maintenance_document`
--

CREATE TABLE `maintenance_document` (
  `id` int(11) NOT NULL,
  `document` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `maintenance_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maintenance_document`
--

INSERT INTO `maintenance_document` (`id`, `document`, `remarks`, `maintenance_id`) VALUES
(1, 'ef078c34896429e8f37ba46b5f2fc15b1780e490Context.jpg', '1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `person_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`person_id`, `first_name`, `middle_name`, `last_name`, `gender`) VALUES
(1, 'Super User', 'X', 'Root', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_data`
--

CREATE TABLE `purchase_data` (
  `id` int(11) NOT NULL,
  `purchase_date` date NOT NULL,
  `receive_date` date NOT NULL,
  `receiver` varchar(255) NOT NULL,
  `person` varchar(255) NOT NULL,
  `location` text NOT NULL,
  `contact` varchar(255) NOT NULL,
  `equiment_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_data`
--

INSERT INTO `purchase_data` (`id`, `purchase_date`, `receive_date`, `receiver`, `person`, `location`, `contact`, `equiment_id`) VALUES
(1, '2017-04-09', '2017-04-09', 'Sir Jojo', 'Octagon', 'MOA', '09162839011', 10);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_data_document`
--

CREATE TABLE `purchase_data_document` (
  `id` int(11) NOT NULL,
  `document` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `purchase_data_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_data_document`
--

INSERT INTO `purchase_data_document` (`id`, `document`, `remarks`, `purchase_data_id`) VALUES
(1, '0a1cfe3f115cc903f3107a5582947b35abf20244DFD 2.jpg', 'X', 1);

-- --------------------------------------------------------

--
-- Table structure for table `system_log`
--

CREATE TABLE `system_log` (
  `entry_id` bigint(20) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `datetime` datetime NOT NULL,
  `action` mediumtext NOT NULL,
  `module` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `system_log`
--

INSERT INTO `system_log` (`entry_id`, `ip_address`, `user`, `datetime`, `action`, `module`) VALUES
(1, '::1', 'root', '2017-02-23 13:10:21', 'Logged in', '/smm/login.php'),
(2, '::1', 'root', '2017-02-23 13:10:21', 'Query Executed: UPDATE user SET `password`=?, `salt`=?, `iteration`=?, `method`=? WHERE username=?\r\nArray\n(\n    [0] => ssiss\n    [1] => $2y$12$esc2I5X4hcbI6waT09MrmOjI7eIfKDbnRiykd9wssOhSrG7CHhfTe\n    [2] => esc2I5X4hcbI6waT09MrmQ\n    [3] => 12\n    [4] => blowfish\n    [5] => root\n)\n', '/smm/login.php'),
(3, '::1', 'root', '2017-02-23 13:11:05', 'Pressed submit button', '/smm/modules/add_assignee.php'),
(4, '::1', 'root', '2017-02-23 13:11:05', 'Query Executed: INSERT INTO assignee(id, rooms, location, deployDate, employee_id) VALUES(?,?,?,?,?)\r\nArray\n(\n    [0] => isssi\n    [1] => \n    [2] => 1010\n    [3] => 10th Floor\n    [4] => 2017-02-18\n    [5] => 1\n)\n', '/smm/modules/add_assignee.php'),
(5, '::1', 'root', '2017-02-23 13:11:41', 'Pressed submit button', '/smm/modules/add_equipment.php'),
(6, '::1', 'root', '2017-02-23 13:11:41', 'Query Executed: INSERT INTO equipment(id, name, type, brand, description, function, price) VALUES(?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => isssssi\n    [1] => \n    [2] => ELE-M519\n    [3] => Mouse\n    [4] => Elephant\n    [5] => Optical Mouse\n    [6] => Optical Mouse\n    [7] => 600\n)\n', '/smm/modules/add_equipment.php'),
(7, '::1', 'root', '2017-02-23 13:11:47', 'Pressed submit button', '/smm/modules/assignment/assignment/add_assignment.php'),
(8, '::1', 'root', '2017-02-23 13:11:47', 'Query Executed: INSERT INTO assignment(id, equipment_id, assignee_id) VALUES(?,?,?)\r\nArray\n(\n    [0] => iii\n    [1] => \n    [2] => 1\n    [3] => 1\n)\n', '/smm/modules/assignment/assignment/add_assignment.php'),
(9, '::1', 'root', '2017-02-23 13:13:13', 'Pressed submit button', '/smm/modules/add_equipment.php'),
(10, '::1', 'root', '2017-02-23 13:13:13', 'Query Executed: INSERT INTO equipment(id, name, type, brand, description, function, price) VALUES(?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => isssssi\n    [1] => \n    [2] => K55UB\n    [3] => Laptop\n    [4] => ASUS\n    [5] => Laptop for Classes\n    [6] => Laptop\n    [7] => 12000\n)\n', '/smm/modules/add_equipment.php'),
(11, '::1', 'root', '2017-02-23 13:13:20', 'Pressed submit button', '/smm/modules/assignment/assignment/add_assignment.php'),
(12, '::1', 'root', '2017-02-23 13:13:21', 'Query Executed: INSERT INTO assignment(id, equipment_id, assignee_id) VALUES(?,?,?)\r\nArray\n(\n    [0] => iii\n    [1] => \n    [2] => 2\n    [3] => 1\n)\n', '/smm/modules/assignment/assignment/add_assignment.php'),
(13, '::1', 'root', '2017-02-23 13:13:57', 'Pressed submit button', '/smm/modules/assignment/assignment/reporter_assignment.php'),
(14, '::1', 'root', '2017-02-23 13:14:12', 'Pressed submit button', '/smm/modules/assignment/assignment/reporter_assignment.php'),
(15, '::1', 'root', '2017-02-23 13:14:23', 'Query Executed: DELETE FROM cobalt_reporter WHERE module_name = ? AND report_name = ?\r\nArray\n(\n    [0] => ss\n    [1] => ASSIGNMENT_REPORT_CUSTOM\n    [2] => Ad\n)\n', '/smm/modules/assignment/assignment/reporter_assignment.php'),
(16, '::1', 'root', '2017-02-23 13:14:23', 'Query Executed: INSERT INTO cobalt_reporter(`module_name`,\n                            `report_name`,\n                            `username`,\n                            `show_field`,\n                            `operator`,\n                            `text_field`,\n                            `sum_field`,\n                            `count_field`,\n                            `group_field1`,\n                            `group_field2`,\n                            `group_field3`) VALUES(?,?,?,?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => sssssssssss\n    [1] => ASSIGNMENT_REPORT_CUSTOM\n    [2] => Ad\n    [3] => root\n    [4] => a:12:{i:0;s:2:"ID";i:1;s:17:"[Equipment Id] ID";i:2;s:19:"[Equipment Id] Name";i:3;s:19:"[Equipment Id] Type";i:4;s:20:"[Equipment Id] Brand";i:5;s:26:"[Equipment Id] Description";i:6;s:23:"[Equipment Id] Function";i:7;s:20:"[Equipment Id] Price";i:8;s:16:"[Assignee Id] ID";i:9;s:19:"[Assignee Id] Rooms";i:10;s:22:"[Assignee Id] Location";i:11;s:25:"[Assignee Id] Deploy Date";}\n    [5] => a:12:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";i:4;s:0:"";i:5;s:0:"";i:6;s:0:"";i:7;s:0:"";i:8;s:0:"";i:9;s:12:"EQUAL TO (=)";i:10;s:0:"";i:11;s:0:"";}\n    [6] => a:12:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";i:4;s:0:"";i:5;s:0:"";i:6;s:0:"";i:7;s:0:"";i:8;s:0:"";i:9;s:4:"1010";i:10;s:0:"";i:11;s:0:"";}\n    [7] => \n    [8] => \n    [9] => \n    [10] => \n    [11] => \n)\n', '/smm/modules/assignment/assignment/reporter_assignment.php'),
(17, '::1', 'root', '2017-02-23 13:15:40', 'Pressed submit button', '/smm/modules/assignment/assignment/csv_assignment.php'),
(18, '::1', 'root', '2017-02-23 13:15:40', 'Exported table data to CSV', '/smm/modules/assignment/assignment/csv_assignment.php'),
(19, '::1', 'root', '2017-02-23 13:15:42', 'Failed file download:  (C:\\xampp\\htdocs/smm/tmp/)', '/smm/download_generic.php'),
(20, '::1', 'root', '2017-02-23 15:20:39', 'Logged in', '/smm/login.php'),
(21, '::1', 'root', '2017-02-23 15:23:20', 'Pressed cancel button', '/smm/modules/add_assignee.php'),
(22, '::1', 'root', '2017-02-23 15:31:47', 'Pressed submit button', '/smm/modules/add_equipment.php'),
(23, '::1', 'root', '2017-02-23 15:31:47', 'Query Executed: INSERT INTO equipment(id, name, type, brand, description, function, price) VALUES(?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => isssssi\n    [1] => \n    [2] => Walis Tingting\n    [3] => Broom\n    [4] => BAGUIO\n    [5] => Broom for Janitorial Staff\n    [6] => To sweep dust\n    [7] => 40\n)\n', '/smm/modules/add_equipment.php'),
(24, '::1', 'root', '2017-02-23 15:35:51', 'Pressed submit button', '/smm/modules/add_purchase_data.php'),
(25, '::1', 'root', '2017-02-23 15:35:56', 'Pressed submit button', '/smm/modules/add_purchase_data.php'),
(26, '::1', 'root', '2017-02-23 15:36:34', 'Pressed submit button', '/smm/modules/add_purchase_data.php'),
(27, '::1', 'root', '2017-02-23 15:48:05', 'Pressed submit button', '/smm/modules/add_preventive.php'),
(28, '::1', 'root', '2017-02-23 15:48:05', 'Query Executed: INSERT INTO preventive(id, time, preferred_provider, date_due, cost, status, reason, equipment_id) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => isssissi\n    [1] => \n    [2] => 7:30\n    [3] => ASUS\n    [4] => 2018-01-06\n    [5] => 750\n    [6] => No progress\n    [7] => Yearly Maintenance\n    [8] => 2\n)\n', '/smm/modules/add_preventive.php'),
(29, '::1', 'root', '2017-02-23 15:48:47', 'Pressed submit button', '/smm/modules/add_corrective.php'),
(30, '::1', 'root', '2017-02-23 15:48:47', 'Query Executed: INSERT INTO corrective(id, start_date, end_date, reason, status, service_provider, cost, official_receipt, equipment_id) VALUES(?,?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => isssssisi\n    [1] => \n    [2] => 2017-03-23\n    [3] => 2017-05-23\n    [4] => Laptop was poured with water\n    [5] => No progress\n    [6] => ASUS\n    [7] => 12000\n    [8] => 25015dc89b5631f7de803f0b88780768d6226466module01.doc\n    [9] => 2\n)\n', '/smm/modules/add_corrective.php'),
(31, '::1', 'root', '2017-02-23 15:54:42', 'Pressed submit button', '/smm/modules/add_purchase_data.php'),
(32, '::1', 'root', '2017-02-23 15:54:42', 'Query Executed: INSERT INTO purchase_data(id, purchase_date, receive_date, receiver, person, location, contact, official_receipt, equiment_id) VALUES(?,?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => isssssssi\n    [1] => \n    [2] => 2017-02-23\n    [3] => 2017-02-23\n    [4] => Miguel Mayor\n    [5] => Alvin Tobias\n    [6] => A\n    [7] => 09102949291\n    [8] => 2a0646f3416a618c4d969c368b76d17c99dd11a8HOMEWORK #2 TOBIAS.docx\n    [9] => 1\n)\n', '/smm/modules/add_purchase_data.php'),
(33, '::1', 'root', '2017-02-23 15:55:02', 'Pressed submit button', '/smm/modules/add_warranty.php'),
(34, '::1', 'root', '2017-02-23 15:55:07', 'Pressed submit button', '/smm/modules/add_warranty.php'),
(35, '::1', 'root', '2017-02-23 15:55:07', 'Query Executed: INSERT INTO warranty(id, start_date, end_date, assigned, copy, purchase_id, equipment_equipment_id) VALUES(?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssii\n    [1] => \n    [2] => 2017-02-23\n    [3] => 2017-02-23\n    [4] => Alvin Tobias\n    [5] => d2e0c587e8d4b76124b9228f388736479580d6d1module01.doc\n    [6] => 3\n    [7] => 1\n)\n', '/smm/modules/add_warranty.php'),
(36, '::1', 'root', '2017-02-23 15:55:36', 'Pressed submit button', '/smm/modules/edit_warranty.php'),
(37, '::1', 'root', '2017-02-23 15:55:36', 'Query Executed: UPDATE warranty SET start_date = ?, end_date = ?, assigned = ?, copy = ?, purchase_id = ?, equipment_equipment_id = ? WHERE id = ?\r\nArray\n(\n    [0] => ssssiii\n    [1] => 2017-02-23\n    [2] => 2017-02-23\n    [3] => Jojo Castillo\n    [4] => d2e0c587e8d4b76124b9228f388736479580d6d1module01.doc\n    [5] => 3\n    [6] => 1\n    [7] => 1\n)\n', '/smm/modules/edit_warranty.php'),
(38, '::1', 'root', '2017-02-23 15:56:04', 'Pressed cancel button', '/smm/modules/listview_assignee.php'),
(39, '::1', 'root', '2017-02-23 16:06:50', 'Pressed submit button', '/smm/sysadmin/add_user_passport_groups.php'),
(40, '::1', 'root', '2017-02-23 16:06:50', 'Query Executed: INSERT INTO user_passport_groups(passport_group_id, passport_group, priority, icon) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => isis\n    [1] => \n    [2] => Equipment\n    [3] => 3\n    [4] => blue_folder3.png\n)\n', '/smm/sysadmin/add_user_passport_groups.php'),
(41, '::1', 'root', '2017-02-23 16:07:06', 'Pressed submit button', '/smm/sysadmin/add_user_passport_groups.php'),
(42, '::1', 'root', '2017-02-23 16:07:06', 'Query Executed: INSERT INTO user_passport_groups(passport_group_id, passport_group, priority, icon) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => isis\n    [1] => \n    [2] => Staff\n    [3] => 2\n    [4] => blue_folder3.png\n)\n', '/smm/sysadmin/add_user_passport_groups.php'),
(43, '::1', 'root', '2017-02-23 16:07:24', 'Pressed submit button', '/smm/sysadmin/add_user_passport_groups.php'),
(44, '::1', 'root', '2017-02-23 16:07:24', 'Query Executed: INSERT INTO user_passport_groups(passport_group_id, passport_group, priority, icon) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => isis\n    [1] => \n    [2] => Maintenance\n    [3] => 1\n    [4] => blue_folder3.png\n)\n', '/smm/sysadmin/add_user_passport_groups.php'),
(45, '::1', 'root', '2017-02-23 16:07:52', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(46, '::1', 'root', '2017-02-23 16:07:52', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add assignee\n    [2] => modules/add_assignee.php\n    [3] => Add Assignee\n    [4] => \n    [5] => 4\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 37\n)\n', '/smm/sysadmin/edit_user_links.php'),
(47, '::1', 'root', '2017-02-23 16:07:56', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(48, '::1', 'root', '2017-02-23 16:07:56', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit assignee\n    [2] => modules/edit_assignee.php\n    [3] => Edit Assignee\n    [4] => \n    [5] => 4\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 38\n)\n', '/smm/sysadmin/edit_user_links.php'),
(49, '::1', 'root', '2017-02-23 16:08:01', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(50, '::1', 'root', '2017-02-23 16:08:01', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View assignee\n    [2] => modules/listview_assignee.php\n    [3] => Assignee\n    [4] => \n    [5] => 4\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 39\n)\n', '/smm/sysadmin/edit_user_links.php'),
(51, '::1', 'root', '2017-02-23 16:08:06', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(52, '::1', 'root', '2017-02-23 16:08:06', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete assignee\n    [2] => modules/delete_assignee.php\n    [3] => Delete Assignee\n    [4] => \n    [5] => 4\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 40\n)\n', '/smm/sysadmin/edit_user_links.php'),
(53, '::1', 'root', '2017-02-23 16:08:12', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(54, '::1', 'root', '2017-02-23 16:08:12', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add assignment\n    [2] => modules/assignment/assignment/add_assignment.php\n    [3] => Add Assignment\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 41\n)\n', '/smm/sysadmin/edit_user_links.php'),
(55, '::1', 'root', '2017-02-23 16:08:17', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(56, '::1', 'root', '2017-02-23 16:08:17', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit assignment\n    [2] => modules/assignment/assignment/edit_assignment.php\n    [3] => Edit Assignment\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 42\n)\n', '/smm/sysadmin/edit_user_links.php'),
(57, '::1', 'root', '2017-02-23 16:08:23', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(58, '::1', 'root', '2017-02-23 16:08:23', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View assignment\n    [2] => modules/assignment/assignment/listview_assignment.php\n    [3] => Assignment\n    [4] => \n    [5] => 3\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 43\n)\n', '/smm/sysadmin/edit_user_links.php'),
(59, '::1', 'root', '2017-02-23 16:08:27', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(60, '::1', 'root', '2017-02-23 16:08:28', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete assignment\n    [2] => modules/assignment/assignment/delete_assignment.php\n    [3] => Delete Assignment\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 44\n)\n', '/smm/sysadmin/edit_user_links.php'),
(61, '::1', 'root', '2017-02-23 16:08:58', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(62, '::1', 'root', '2017-02-23 16:08:59', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add corrective\n    [2] => modules/add_corrective.php\n    [3] => Add Corrective\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 45\n)\n', '/smm/sysadmin/edit_user_links.php'),
(63, '::1', 'root', '2017-02-23 16:09:03', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(64, '::1', 'root', '2017-02-23 16:09:03', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit corrective\n    [2] => modules/edit_corrective.php\n    [3] => Edit Corrective\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 46\n)\n', '/smm/sysadmin/edit_user_links.php'),
(65, '::1', 'root', '2017-02-23 16:09:08', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(66, '::1', 'root', '2017-02-23 16:09:08', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View corrective\n    [2] => modules/listview_corrective.php\n    [3] => Corrective\n    [4] => \n    [5] => 5\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 47\n)\n', '/smm/sysadmin/edit_user_links.php'),
(67, '::1', 'root', '2017-02-23 16:09:11', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(68, '::1', 'root', '2017-02-23 16:09:12', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete corrective\n    [2] => modules/delete_corrective.php\n    [3] => Delete Corrective\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 48\n)\n', '/smm/sysadmin/edit_user_links.php'),
(69, '::1', 'root', '2017-02-23 16:15:57', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(70, '::1', 'root', '2017-02-23 16:15:57', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add disposal\n    [2] => modules/add_disposal.php\n    [3] => Add Disposal\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 49\n)\n', '/smm/sysadmin/edit_user_links.php'),
(71, '::1', 'root', '2017-02-23 16:16:02', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(72, '::1', 'root', '2017-02-23 16:16:02', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit disposal\n    [2] => modules/edit_disposal.php\n    [3] => Edit Disposal\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 50\n)\n', '/smm/sysadmin/edit_user_links.php'),
(73, '::1', 'root', '2017-02-23 16:16:09', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(74, '::1', 'root', '2017-02-23 16:16:09', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View disposal\n    [2] => modules/listview_disposal.php\n    [3] => Disposal\n    [4] => \n    [5] => 3\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 51\n)\n', '/smm/sysadmin/edit_user_links.php'),
(75, '::1', 'root', '2017-02-23 16:16:14', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(76, '::1', 'root', '2017-02-23 16:16:14', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete disposal\n    [2] => modules/delete_disposal.php\n    [3] => Delete Disposal\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 52\n)\n', '/smm/sysadmin/edit_user_links.php'),
(77, '::1', 'root', '2017-02-23 16:16:29', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(78, '::1', 'root', '2017-02-23 16:16:29', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add employee\n    [2] => modules/add_employee.php\n    [3] => Add Employee\n    [4] => \n    [5] => 4\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 53\n)\n', '/smm/sysadmin/edit_user_links.php'),
(79, '::1', 'root', '2017-02-23 16:16:35', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(80, '::1', 'root', '2017-02-23 16:16:36', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit employee\n    [2] => modules/edit_employee.php\n    [3] => Edit Employee\n    [4] => \n    [5] => 4\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 54\n)\n', '/smm/sysadmin/edit_user_links.php'),
(81, '::1', 'root', '2017-02-23 16:16:40', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(82, '::1', 'root', '2017-02-23 16:16:40', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View employee\n    [2] => modules/listview_employee.php\n    [3] => Employee\n    [4] => \n    [5] => 4\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 55\n)\n', '/smm/sysadmin/edit_user_links.php'),
(83, '::1', 'root', '2017-02-23 16:16:44', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(84, '::1', 'root', '2017-02-23 16:16:44', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete employee\n    [2] => modules/delete_employee.php\n    [3] => Delete Employee\n    [4] => \n    [5] => 4\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 56\n)\n', '/smm/sysadmin/edit_user_links.php'),
(85, '::1', 'root', '2017-02-23 16:17:10', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(86, '::1', 'root', '2017-02-23 16:17:10', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add equipment\n    [2] => modules/add_equipment.php\n    [3] => Add Equipment\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 57\n)\n', '/smm/sysadmin/edit_user_links.php'),
(87, '::1', 'root', '2017-02-23 16:17:17', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(88, '::1', 'root', '2017-02-23 16:17:18', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit equipment\n    [2] => modules/edit_equipment.php\n    [3] => Edit Equipment\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 58\n)\n', '/smm/sysadmin/edit_user_links.php'),
(89, '::1', 'root', '2017-02-23 16:17:29', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(90, '::1', 'root', '2017-02-23 16:17:29', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View equipment\n    [2] => modules/listview_equipment.php\n    [3] => Equipment\n    [4] => \n    [5] => 5\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 59\n)\n', '/smm/sysadmin/edit_user_links.php'),
(91, '::1', 'root', '2017-02-23 16:17:35', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(92, '::1', 'root', '2017-02-23 16:17:35', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete equipment\n    [2] => modules/delete_equipment.php\n    [3] => Delete Equipment\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 60\n)\n', '/smm/sysadmin/edit_user_links.php'),
(93, '::1', 'root', '2017-02-23 16:17:41', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(94, '::1', 'root', '2017-02-23 16:17:41', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View equipment\n    [2] => modules/listview_equipment.php\n    [3] => Equipment\n    [4] => \n    [5] => 3\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 59\n)\n', '/smm/sysadmin/edit_user_links.php'),
(95, '::1', 'root', '2017-02-23 16:18:07', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(96, '::1', 'root', '2017-02-23 16:18:07', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add preventive\n    [2] => modules/add_preventive.php\n    [3] => Add Preventive\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 61\n)\n', '/smm/sysadmin/edit_user_links.php'),
(97, '::1', 'root', '2017-02-23 16:18:12', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(98, '::1', 'root', '2017-02-23 16:18:12', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit preventive\n    [2] => modules/edit_preventive.php\n    [3] => Edit Preventive\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 62\n)\n', '/smm/sysadmin/edit_user_links.php'),
(99, '::1', 'root', '2017-02-23 16:18:16', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(100, '::1', 'root', '2017-02-23 16:18:16', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View preventive\n    [2] => modules/listview_preventive.php\n    [3] => Preventive\n    [4] => \n    [5] => 5\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 63\n)\n', '/smm/sysadmin/edit_user_links.php'),
(101, '::1', 'root', '2017-02-23 16:18:20', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(102, '::1', 'root', '2017-02-23 16:18:20', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete preventive\n    [2] => modules/delete_preventive.php\n    [3] => Delete Preventive\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 64\n)\n', '/smm/sysadmin/edit_user_links.php'),
(103, '::1', 'root', '2017-02-23 16:18:36', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(104, '::1', 'root', '2017-02-23 16:18:36', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add purchase data\n    [2] => modules/add_purchase_data.php\n    [3] => Add Purchase Data\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 65\n)\n', '/smm/sysadmin/edit_user_links.php'),
(105, '::1', 'root', '2017-02-23 16:18:42', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(106, '::1', 'root', '2017-02-23 16:18:42', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit purchase data\n    [2] => modules/edit_purchase_data.php\n    [3] => Edit Purchase Data\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 66\n)\n', '/smm/sysadmin/edit_user_links.php'),
(107, '::1', 'root', '2017-02-23 16:18:46', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(108, '::1', 'root', '2017-02-23 16:18:46', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View purchase data\n    [2] => modules/listview_purchase_data.php\n    [3] => Purchase Data\n    [4] => \n    [5] => 3\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 67\n)\n', '/smm/sysadmin/edit_user_links.php'),
(109, '::1', 'root', '2017-02-23 16:18:50', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(110, '::1', 'root', '2017-02-23 16:18:50', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete purchase data\n    [2] => modules/delete_purchase_data.php\n    [3] => Delete Purchase Data\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 68\n)\n', '/smm/sysadmin/edit_user_links.php'),
(111, '::1', 'root', '2017-02-23 16:19:04', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(112, '::1', 'root', '2017-02-23 16:19:04', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add warranty\n    [2] => modules/add_warranty.php\n    [3] => Add Warranty\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 69\n)\n', '/smm/sysadmin/edit_user_links.php'),
(113, '::1', 'root', '2017-02-23 16:19:08', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(114, '::1', 'root', '2017-02-23 16:19:08', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit warranty\n    [2] => modules/edit_warranty.php\n    [3] => Edit Warranty\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 70\n)\n', '/smm/sysadmin/edit_user_links.php'),
(115, '::1', 'root', '2017-02-23 16:19:12', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(116, '::1', 'root', '2017-02-23 16:19:12', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View warranty\n    [2] => modules/listview_warranty.php\n    [3] => Warranty\n    [4] => \n    [5] => 3\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 71\n)\n', '/smm/sysadmin/edit_user_links.php'),
(117, '::1', 'root', '2017-02-23 16:19:16', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(118, '::1', 'root', '2017-02-23 16:19:16', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete warranty\n    [2] => modules/delete_warranty.php\n    [3] => Delete Warranty\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 72\n)\n', '/smm/sysadmin/edit_user_links.php'),
(119, '::1', 'root', '2017-02-23 16:20:02', 'Pressed submit button', '/smm/modules/add_disposal.php'),
(120, '::1', 'root', '2017-02-23 16:20:02', 'Query Executed: INSERT INTO disposal(id, method, remarks, date, equipment_id) VALUES(?,?,?,?,?)\r\nArray\n(\n    [0] => isssi\n    [1] => \n    [2] => Disassemble mouse\n    [3] => Difficulty: Easy\n    [4] => 2014-02-20\n    [5] => 1\n)\n', '/smm/modules/add_disposal.php'),
(121, '::1', 'root', '2017-02-23 16:20:43', 'Query executed: UPDATE user SET skin_id=''9'' WHERE username=''root''', '/smm/change_skin.php'),
(122, '::1', 'root', '2017-02-23 16:20:45', 'Query executed: UPDATE user SET skin_id=''2'' WHERE username=''root''', '/smm/change_skin.php'),
(123, '::1', 'root', '2017-02-23 16:20:55', 'Query executed: UPDATE user SET skin_id=''3'' WHERE username=''root''', '/smm/change_skin.php'),
(124, '::1', 'root', '2017-02-23 16:21:02', 'Query executed: UPDATE user SET skin_id=''10'' WHERE username=''root''', '/smm/change_skin.php'),
(125, '::1', 'root', '2017-02-23 16:21:13', 'Query executed: UPDATE user SET skin_id=''8'' WHERE username=''root''', '/smm/change_skin.php'),
(126, '::1', 'root', '2017-02-23 16:21:19', 'Query executed: UPDATE user SET skin_id=''6'' WHERE username=''root''', '/smm/change_skin.php'),
(127, '::1', 'root', '2017-02-23 16:21:22', 'Query executed: UPDATE user SET skin_id=''11'' WHERE username=''root''', '/smm/change_skin.php'),
(128, '::1', 'root', '2017-02-23 16:21:27', 'Query executed: UPDATE user SET skin_id=''6'' WHERE username=''root''', '/smm/change_skin.php'),
(129, '::1', 'root', '2017-02-23 16:21:39', 'Query executed: UPDATE user SET skin_id=''1'' WHERE username=''root''', '/smm/change_skin.php'),
(130, '::1', 'root', '2017-02-23 16:21:42', 'Query executed: UPDATE user SET skin_id=''6'' WHERE username=''root''', '/smm/change_skin.php'),
(131, '::1', 'root', '2017-02-23 16:21:45', 'Query executed: UPDATE user SET skin_id=''7'' WHERE username=''root''', '/smm/change_skin.php'),
(132, '::1', 'root', '2017-02-23 16:21:48', 'Query executed: UPDATE user SET skin_id=''8'' WHERE username=''root''', '/smm/change_skin.php'),
(133, '::1', 'root', '2017-02-23 16:21:53', 'Query executed: UPDATE user SET skin_id=''4'' WHERE username=''root''', '/smm/change_skin.php'),
(134, '::1', 'root', '2017-02-23 16:21:57', 'Query executed: UPDATE user SET skin_id=''11'' WHERE username=''root''', '/smm/change_skin.php'),
(135, '::1', 'root', '2017-02-23 16:22:00', 'Query executed: UPDATE user SET skin_id=''6'' WHERE username=''root''', '/smm/change_skin.php'),
(136, '::1', 'root', '2017-02-23 16:32:06', 'Pressed submit button', '/smm/modules/add_disposal.php'),
(137, '::1', 'root', '2017-02-23 16:32:06', 'Query Executed: INSERT INTO disposal(id, method, remarks, date, equipment_id) VALUES(?,?,?,?,?)\r\nArray\n(\n    [0] => isssi\n    [1] => \n    [2] => Disassemble Laptop; Extract usable parts\n    [3] => Total Cost of the remaining parts: 450\n    [4] => 2017-02-07\n    [5] => 2\n)\n', '/smm/modules/add_disposal.php'),
(138, '::1', 'root', '2017-02-23 16:33:44', 'Logged out', '/smm/end.php'),
(139, '::1', 'root', '2017-02-23 16:34:50', 'Logged in', '/smm/login.php'),
(140, '::1', 'root', '2017-02-27 09:52:43', 'Logged in', '/smm/login.php'),
(141, '::1', 'root', '2017-02-27 09:53:22', 'Query executed: DELETE FROM user_role_links WHERE role_id=''1''', '/smm/sysadmin/role_permissions.php'),
(142, '::1', 'root', '2017-02-27 09:53:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''37'')', '/smm/sysadmin/role_permissions.php'),
(143, '::1', 'root', '2017-02-27 09:53:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''41'')', '/smm/sysadmin/role_permissions.php'),
(144, '::1', 'root', '2017-02-27 09:53:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''33'')', '/smm/sysadmin/role_permissions.php'),
(145, '::1', 'root', '2017-02-27 09:53:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''45'')', '/smm/sysadmin/role_permissions.php'),
(146, '::1', 'root', '2017-02-27 09:53:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''73'')', '/smm/sysadmin/role_permissions.php'),
(147, '::1', 'root', '2017-02-27 09:53:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''49'')', '/smm/sysadmin/role_permissions.php'),
(148, '::1', 'root', '2017-02-27 09:53:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''53'')', '/smm/sysadmin/role_permissions.php'),
(149, '::1', 'root', '2017-02-27 09:53:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''57'')', '/smm/sysadmin/role_permissions.php'),
(150, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''4'')', '/smm/sysadmin/role_permissions.php'),
(151, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''61'')', '/smm/sysadmin/role_permissions.php'),
(152, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''77'')', '/smm/sysadmin/role_permissions.php'),
(153, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''65'')', '/smm/sysadmin/role_permissions.php'),
(154, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''81'')', '/smm/sysadmin/role_permissions.php'),
(155, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''16'')', '/smm/sysadmin/role_permissions.php'),
(156, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''28'')', '/smm/sysadmin/role_permissions.php'),
(157, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''8'')', '/smm/sysadmin/role_permissions.php'),
(158, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''20'')', '/smm/sysadmin/role_permissions.php'),
(159, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''24'')', '/smm/sysadmin/role_permissions.php'),
(160, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''12'')', '/smm/sysadmin/role_permissions.php'),
(161, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''69'')', '/smm/sysadmin/role_permissions.php'),
(162, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''39'')', '/smm/sysadmin/role_permissions.php'),
(163, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''43'')', '/smm/sysadmin/role_permissions.php'),
(164, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''35'')', '/smm/sysadmin/role_permissions.php'),
(165, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''47'')', '/smm/sysadmin/role_permissions.php'),
(166, '::1', 'root', '2017-02-27 09:53:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''75'')', '/smm/sysadmin/role_permissions.php'),
(167, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''40'')', '/smm/sysadmin/role_permissions.php'),
(168, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''44'')', '/smm/sysadmin/role_permissions.php'),
(169, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''36'')', '/smm/sysadmin/role_permissions.php'),
(170, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''48'')', '/smm/sysadmin/role_permissions.php'),
(171, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''76'')', '/smm/sysadmin/role_permissions.php'),
(172, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''52'')', '/smm/sysadmin/role_permissions.php'),
(173, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''56'')', '/smm/sysadmin/role_permissions.php'),
(174, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''60'')', '/smm/sysadmin/role_permissions.php'),
(175, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''7'')', '/smm/sysadmin/role_permissions.php'),
(176, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''64'')', '/smm/sysadmin/role_permissions.php'),
(177, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''80'')', '/smm/sysadmin/role_permissions.php'),
(178, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''68'')', '/smm/sysadmin/role_permissions.php'),
(179, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''84'')', '/smm/sysadmin/role_permissions.php'),
(180, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''19'')', '/smm/sysadmin/role_permissions.php'),
(181, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''31'')', '/smm/sysadmin/role_permissions.php'),
(182, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''11'')', '/smm/sysadmin/role_permissions.php'),
(183, '::1', 'root', '2017-02-27 09:53:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''23'')', '/smm/sysadmin/role_permissions.php'),
(184, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''27'')', '/smm/sysadmin/role_permissions.php'),
(185, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''15'')', '/smm/sysadmin/role_permissions.php'),
(186, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''72'')', '/smm/sysadmin/role_permissions.php'),
(187, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''51'')', '/smm/sysadmin/role_permissions.php'),
(188, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''38'')', '/smm/sysadmin/role_permissions.php'),
(189, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''42'')', '/smm/sysadmin/role_permissions.php'),
(190, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''34'')', '/smm/sysadmin/role_permissions.php'),
(191, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''46'')', '/smm/sysadmin/role_permissions.php'),
(192, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''74'')', '/smm/sysadmin/role_permissions.php'),
(193, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''50'')', '/smm/sysadmin/role_permissions.php'),
(194, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''54'')', '/smm/sysadmin/role_permissions.php'),
(195, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''58'')', '/smm/sysadmin/role_permissions.php'),
(196, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''5'')', '/smm/sysadmin/role_permissions.php'),
(197, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''62'')', '/smm/sysadmin/role_permissions.php'),
(198, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''78'')', '/smm/sysadmin/role_permissions.php'),
(199, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''66'')', '/smm/sysadmin/role_permissions.php'),
(200, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''82'')', '/smm/sysadmin/role_permissions.php'),
(201, '::1', 'root', '2017-02-27 09:53:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''17'')', '/smm/sysadmin/role_permissions.php'),
(202, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''29'')', '/smm/sysadmin/role_permissions.php'),
(203, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''9'')', '/smm/sysadmin/role_permissions.php'),
(204, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''21'')', '/smm/sysadmin/role_permissions.php'),
(205, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''25'')', '/smm/sysadmin/role_permissions.php'),
(206, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''13'')', '/smm/sysadmin/role_permissions.php'),
(207, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''70'')', '/smm/sysadmin/role_permissions.php'),
(208, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''55'')', '/smm/sysadmin/role_permissions.php'),
(209, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''59'')', '/smm/sysadmin/role_permissions.php'),
(210, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''1'')', '/smm/sysadmin/role_permissions.php'),
(211, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''6'')', '/smm/sysadmin/role_permissions.php'),
(212, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''63'')', '/smm/sysadmin/role_permissions.php'),
(213, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''79'')', '/smm/sysadmin/role_permissions.php'),
(214, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''67'')', '/smm/sysadmin/role_permissions.php'),
(215, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''83'')', '/smm/sysadmin/role_permissions.php'),
(216, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''32'')', '/smm/sysadmin/role_permissions.php'),
(217, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''3'')', '/smm/sysadmin/role_permissions.php'),
(218, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''2'')', '/smm/sysadmin/role_permissions.php');
INSERT INTO `system_log` (`entry_id`, `ip_address`, `user`, `datetime`, `action`, `module`) VALUES
(219, '::1', 'root', '2017-02-27 09:53:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''18'')', '/smm/sysadmin/role_permissions.php'),
(220, '::1', 'root', '2017-02-27 09:53:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''30'')', '/smm/sysadmin/role_permissions.php'),
(221, '::1', 'root', '2017-02-27 09:53:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''10'')', '/smm/sysadmin/role_permissions.php'),
(222, '::1', 'root', '2017-02-27 09:53:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''22'')', '/smm/sysadmin/role_permissions.php'),
(223, '::1', 'root', '2017-02-27 09:53:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''26'')', '/smm/sysadmin/role_permissions.php'),
(224, '::1', 'root', '2017-02-27 09:53:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''14'')', '/smm/sysadmin/role_permissions.php'),
(225, '::1', 'root', '2017-02-27 09:53:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''71'')', '/smm/sysadmin/role_permissions.php'),
(226, '::1', 'root', '2017-02-27 09:53:33', 'Query executed: DELETE FROM user_passport WHERE username IN (''root'')', '/smm/sysadmin/role_permissions_cascade.php'),
(227, '::1', 'root', '2017-02-27 09:53:33', 'Query executed: INSERT `user_passport` SELECT ''root'', `link_id` FROM user_role_links WHERE role_id=''1''', '/smm/sysadmin/role_permissions_cascade.php'),
(228, '::1', 'root', '2017-02-27 09:53:35', 'Pressed cancel button', '/smm/sysadmin/role_permissions_cascade.php'),
(229, '::1', 'root', '2017-02-27 09:59:29', 'Logged in', '/smm/login.php'),
(230, '::1', 'root', '2017-02-27 10:01:09', 'Logged in', '/smm/login.php'),
(231, '::1', 'root', '2017-02-27 10:04:24', 'Logged in', '/smm/login.php'),
(232, '::1', 'root', '2017-02-27 10:06:55', 'Logged in', '/smm/login.php'),
(233, '::1', 'root', '2017-02-27 10:07:40', 'Pressed submit button', '/smm/modules/add_corrective.php'),
(234, '::1', 'root', '2017-02-27 15:40:08', 'Logged in', '/smm/login.php'),
(235, '::1', 'root', '2017-03-02 14:58:17', 'Logged in', '/smm/login.php'),
(236, '::1', 'root', '2017-03-02 14:59:08', 'Pressed submit button', '/smm/modules/add_corrective.php'),
(237, '::1', 'root', '2017-03-02 16:02:19', 'Logged in', '/smm/login.php'),
(238, '::1', 'root', '2017-03-06 15:31:57', 'Logged in', '/smm/login.php'),
(239, '::1', 'root', '2017-03-06 15:44:39', 'Logged in', '/smm/login.php'),
(240, '::1', 'root', '2017-03-06 15:48:48', 'Logged in', '/smm/login.php'),
(241, '::1', 'root', '2017-03-06 17:01:18', 'Logged in', '/smm/login.php'),
(242, '::1', 'root', '2017-03-06 17:23:18', 'Pressed cancel button', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(243, '::1', 'root', '2017-03-06 20:14:40', 'Pressed submit button', '/smm/modules/maintenance/corrective/add_corrective.php'),
(244, '::1', 'root', '2017-03-06 20:14:40', 'Query Executed: INSERT INTO corrective(id, start_date, end_date, time, reason, status, service_provider, cost, equipment_id) VALUES(?,?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssssdi\n    [1] => \n    [2] => 2017-03-06\n    [3] => 2017-03-06\n    [4] => 7:30\n    [5] => Hello\n    [6] => No progress\n    [7] => ASUS\n    [8] => 450\n    [9] => 1\n)\n', '/smm/modules/maintenance/corrective/add_corrective.php'),
(245, '::1', 'root', '2017-03-06 20:14:41', 'Query Executed: INSERT INTO corrective_document(id, document, remarks, corrective_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => issi\n    [1] => \n    [2] => change_skin.php\n    [3] => SS\n    [4] => 1\n)\n', '/smm/modules/maintenance/corrective/add_corrective.php'),
(246, '::1', 'root', '2017-03-06 20:14:41', 'Query Executed: INSERT INTO corrective_document(id, document, remarks, corrective_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => issi\n    [1] => \n    [2] => change_skin.php\n    [3] => SS\n    [4] => 1\n)\n', '/smm/modules/maintenance/corrective/add_corrective.php'),
(247, '::1', 'root', '2017-03-06 20:15:01', 'Pressed submit button', '/smm/modules/maintenance/corrective/edit_corrective.php'),
(248, '::1', 'root', '2017-03-06 20:15:01', 'Query Executed: DELETE FROM corrective_document WHERE corrective_id = ?\r\nArray\n(\n    [0] => i\n    [1] => \n)\n', '/smm/modules/maintenance/corrective/edit_corrective.php'),
(249, '::1', 'root', '2017-03-06 20:15:01', 'Query Executed: INSERT INTO corrective_document(id, document, remarks, corrective_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => issi\n    [1] => \n    [2] => download_csv_tmp_store.php\n    [3] => SS\n    [4] => 1\n)\n', '/smm/modules/maintenance/corrective/edit_corrective.php'),
(250, '::1', 'root', '2017-03-06 20:15:01', 'Query Executed: INSERT INTO corrective_document(id, document, remarks, corrective_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => issi\n    [1] => \n    [2] => change_skin.php\n    [3] => SS\n    [4] => 1\n)\n', '/smm/modules/maintenance/corrective/edit_corrective.php'),
(251, '::1', 'root', '2017-03-06 20:15:01', 'Query Executed: UPDATE corrective SET start_date = ?, end_date = ?, time = ?, reason = ?, status = ?, service_provider = ?, cost = ?, equipment_id = ? WHERE id = ?\r\nArray\n(\n    [0] => ssssssdii\n    [1] => 2017-03-06\n    [2] => 2017-03-06\n    [3] => 7:30\n    [4] => Hello\n    [5] => No progress\n    [6] => ASUS\n    [7] => 450\n    [8] => 1\n    [9] => 1\n)\n', '/smm/modules/maintenance/corrective/edit_corrective.php'),
(252, '::1', 'root', '2017-03-08 13:21:17', 'Logged in', '/smm/login.php'),
(253, '::1', 'root', '2017-03-09 12:29:22', 'Logged in', '/smm/login.php'),
(254, '::1', 'root', '2017-03-09 12:34:07', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(255, '::1', 'root', '2017-03-09 12:34:07', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add preventive\n    [2] => modules/maintenance/preventive/add_preventive.php\n    [3] => Add Preventive\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 65\n)\n', '/smm/sysadmin/edit_user_links.php'),
(256, '::1', 'root', '2017-03-09 12:34:17', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(257, '::1', 'root', '2017-03-09 12:34:17', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit preventive\n    [2] => modules/maintenance/preventive/edit_preventive.php\n    [3] => Edit Preventive\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 66\n)\n', '/smm/sysadmin/edit_user_links.php'),
(258, '::1', 'root', '2017-03-09 12:34:24', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(259, '::1', 'root', '2017-03-09 12:34:24', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View preventive\n    [2] => modules/maintenance/preventive/listview_preventive.php\n    [3] => Preventive\n    [4] => \n    [5] => 5\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 67\n)\n', '/smm/sysadmin/edit_user_links.php'),
(260, '::1', 'root', '2017-03-09 12:34:32', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(261, '::1', 'root', '2017-03-09 12:34:32', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete preventive\n    [2] => modules/maintenance/preventive/delete_preventive.php\n    [3] => Delete Preventive\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 68\n)\n', '/smm/sysadmin/edit_user_links.php'),
(262, '::1', 'root', '2017-03-09 12:34:42', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(263, '::1', 'root', '2017-03-09 12:34:42', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add preventive history\n    [2] => modules/maintenance/preventive_history/add_preventive_history.php\n    [3] => Add Preventive History\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 69\n)\n', '/smm/sysadmin/edit_user_links.php'),
(264, '::1', 'root', '2017-03-09 12:34:51', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(265, '::1', 'root', '2017-03-09 12:34:52', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit preventive history\n    [2] => modules/maintenance/preventive_history/edit_preventive_history.php\n    [3] => Edit Preventive History\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 70\n)\n', '/smm/sysadmin/edit_user_links.php'),
(266, '::1', 'root', '2017-03-09 12:35:02', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(267, '::1', 'root', '2017-03-09 12:35:02', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View preventive history\n    [2] => modules/maintenance/preventive_history/listview_preventive_history.php\n    [3] => Preventive History\n    [4] => \n    [5] => 5\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 71\n)\n', '/smm/sysadmin/edit_user_links.php'),
(268, '::1', 'root', '2017-03-09 12:35:10', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(269, '::1', 'root', '2017-03-09 12:35:10', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete preventive history\n    [2] => modules/maintenance/preventive_history/delete_preventive_history.php\n    [3] => Delete Preventive History\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 72\n)\n', '/smm/sysadmin/edit_user_links.php'),
(270, '::1', 'root', '2017-03-09 12:39:11', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(271, '::1', 'root', '2017-03-09 12:39:11', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add corrective\n    [2] => modules/maintenance/corrective/add_corrective.php\n    [3] => Add Corrective\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 45\n)\n', '/smm/sysadmin/edit_user_links.php'),
(272, '::1', 'root', '2017-03-09 12:39:21', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(273, '::1', 'root', '2017-03-09 12:39:21', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit corrective\n    [2] => modules/maintenance/corrective/edit_corrective.php\n    [3] => Edit Corrective\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 46\n)\n', '/smm/sysadmin/edit_user_links.php'),
(274, '::1', 'root', '2017-03-09 12:39:35', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(275, '::1', 'root', '2017-03-09 12:39:35', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View corrective\n    [2] => modules/maintenance/corrective/listview_corrective.php\n    [3] => Corrective\n    [4] => \n    [5] => 5\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 47\n)\n', '/smm/sysadmin/edit_user_links.php'),
(276, '::1', 'root', '2017-03-09 12:39:43', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(277, '::1', 'root', '2017-03-09 12:39:43', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete corrective\n    [2] => modules/maintenance/corrective/delete_corrective.php\n    [3] => Delete Corrective\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 48\n)\n', '/smm/sysadmin/edit_user_links.php'),
(278, '::1', 'root', '2017-03-09 12:40:26', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(279, '::1', 'root', '2017-03-09 12:40:26', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add corrective document\n    [2] => modules/maintenance/corrective_document/add_corrective_document.php\n    [3] => Add Corrective Document\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 49\n)\n', '/smm/sysadmin/edit_user_links.php'),
(280, '::1', 'root', '2017-03-09 12:43:51', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(281, '::1', 'root', '2017-03-09 12:43:51', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit corrective document\n    [2] => modules/maintenance/corrective_document/edit_corrective_document.php\n    [3] => Edit Corrective Document\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 50\n)\n', '/smm/sysadmin/edit_user_links.php'),
(282, '::1', 'root', '2017-03-09 12:43:59', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(283, '::1', 'root', '2017-03-09 12:43:59', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View corrective document\n    [2] => modules/maintenance/corrective_document/listview_corrective_document.php\n    [3] => Corrective Document\n    [4] => \n    [5] => 5\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 51\n)\n', '/smm/sysadmin/edit_user_links.php'),
(284, '::1', 'root', '2017-03-09 12:44:05', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(285, '::1', 'root', '2017-03-09 12:44:06', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete corrective document\n    [2] => modules/maintenance/corrective_document/delete_corrective_document.php\n    [3] => Delete Corrective Document\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 52\n)\n', '/smm/sysadmin/edit_user_links.php'),
(286, '::1', 'root', '2017-03-09 15:34:22', 'Pressed submit button', '/smm/modules/maintenance/corrective_document/edit_corrective_document.php'),
(287, '::1', 'root', '2017-03-09 15:34:42', 'Pressed submit button', '/smm/modules/maintenance/corrective_document/edit_corrective_document.php'),
(288, '::1', 'root', '2017-03-09 15:36:20', 'Pressed cancel button', '/smm/modules/maintenance/corrective_document/edit_corrective_document.php'),
(289, '::1', 'root', '2017-03-09 15:37:11', 'Pressed submit button', '/smm/modules/maintenance/corrective/add_corrective.php'),
(290, '::1', 'root', '2017-03-09 15:37:11', 'Query Executed: INSERT INTO corrective(id, start_date, end_date, time, reason, status, service_provider, cost, equipment_id) VALUES(?,?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssssdi\n    [1] => \n    [2] => 2017-03-09\n    [3] => 2017-03-09\n    [4] => 2\n    [5] => 123\n    [6] => Ongoing\n    [7] => ASSUS\n    [8] => 134\n    [9] => 1\n)\n', '/smm/modules/maintenance/corrective/add_corrective.php'),
(291, '::1', 'root', '2017-03-09 15:37:12', 'Query Executed: INSERT INTO corrective_document(id, document, remarks, corrective_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => issi\n    [1] => \n    [2] => 25.pdf\n    [3] => 123\n    [4] => 2\n)\n', '/smm/modules/maintenance/corrective/add_corrective.php'),
(292, '::1', 'root', '2017-03-09 15:38:03', 'Pressed submit button', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(293, '::1', 'root', '2017-03-09 15:38:03', 'Query Executed: INSERT INTO purchase_data(id, purchase_date, receive_date, receiver, person, location, contact, equiment_id) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssssi\n    [1] => \n    [2] => 2017-03-09\n    [3] => 2017-03-09\n    [4] => 12\n    [5] => 12\n    [6] => 12\n    [7] => 01929418283\n    [8] => 1\n)\n', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(294, '::1', 'root', '2017-03-09 15:38:03', 'Query Executed: INSERT INTO purchase_data_document(id, document, remarks, purchase_data_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => issi\n    [1] => \n    [2] => 14-dube.pdf\n    [3] => LIR\n    [4] => 1\n)\n', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(295, '::1', 'root', '2017-03-09 15:40:41', 'Pressed cancel button', '/smm/modules/maintenance/preventive_history/add_preventive_history.php'),
(296, '::1', 'root', '2017-03-09 15:41:13', 'Pressed submit button', '/smm/sysadmin/add_user_passport_groups.php'),
(297, '::1', 'root', '2017-03-09 15:41:13', 'Query Executed: INSERT INTO user_passport_groups(passport_group_id, passport_group, priority, icon) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => isis\n    [1] => \n    [2] => Assignment\n    [3] => 0\n    [4] => blue_folder3.png\n)\n', '/smm/sysadmin/add_user_passport_groups.php'),
(298, '::1', 'root', '2017-03-09 15:41:32', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(299, '::1', 'root', '2017-03-09 15:41:32', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add assignee\n    [2] => modules/staff/assignee/add_assignee.php\n    [3] => Add Assignee\n    [4] => \n    [5] => 6\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 37\n)\n', '/smm/sysadmin/edit_user_links.php'),
(300, '::1', 'root', '2017-03-09 15:41:38', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(301, '::1', 'root', '2017-03-09 15:41:38', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit assignee\n    [2] => modules/staff/assignee/edit_assignee.php\n    [3] => Edit Assignee\n    [4] => \n    [5] => 6\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 38\n)\n', '/smm/sysadmin/edit_user_links.php'),
(302, '::1', 'root', '2017-03-09 15:41:48', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(303, '::1', 'root', '2017-03-09 15:41:48', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View assignee\n    [2] => modules/staff/assignee/listview_assignee.php\n    [3] => Assignee\n    [4] => \n    [5] => 6\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 39\n)\n', '/smm/sysadmin/edit_user_links.php'),
(304, '::1', 'root', '2017-03-09 15:41:55', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(305, '::1', 'root', '2017-03-09 15:41:55', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete assignee\n    [2] => modules/staff/assignee/delete_assignee.php\n    [3] => Delete Assignee\n    [4] => \n    [5] => 6\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 40\n)\n', '/smm/sysadmin/edit_user_links.php'),
(306, '::1', 'root', '2017-03-09 15:42:02', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(307, '::1', 'root', '2017-03-09 15:42:02', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add assignment\n    [2] => modules/equipment/assignment/add_assignment.php\n    [3] => Add Assignment\n    [4] => \n    [5] => 6\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 41\n)\n', '/smm/sysadmin/edit_user_links.php'),
(308, '::1', 'root', '2017-03-09 15:42:10', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(309, '::1', 'root', '2017-03-09 15:42:10', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit assignment\n    [2] => modules/equipment/assignment/edit_assignment.php\n    [3] => Edit Assignment\n    [4] => \n    [5] => 6\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 42\n)\n', '/smm/sysadmin/edit_user_links.php'),
(310, '::1', 'root', '2017-03-09 15:42:19', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(311, '::1', 'root', '2017-03-09 15:42:19', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View assignment\n    [2] => modules/equipment/assignment/listview_assignment.php\n    [3] => Assignment\n    [4] => \n    [5] => 6\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 43\n)\n', '/smm/sysadmin/edit_user_links.php'),
(312, '::1', 'root', '2017-03-09 15:42:26', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(313, '::1', 'root', '2017-03-09 15:42:27', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete assignment\n    [2] => modules/equipment/assignment/delete_assignment.php\n    [3] => Delete Assignment\n    [4] => \n    [5] => 6\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 44\n)\n', '/smm/sysadmin/edit_user_links.php'),
(314, '::1', 'root', '2017-03-09 15:45:42', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(315, '::1', 'root', '2017-03-09 15:45:42', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add disposal\n    [2] => modules/equipment/disposal/add_disposal.php\n    [3] => Add Disposal\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 53\n)\n', '/smm/sysadmin/edit_user_links.php'),
(316, '::1', 'root', '2017-03-09 15:45:47', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(317, '::1', 'root', '2017-03-09 15:45:47', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit disposal\n    [2] => modules/equipment/disposal/edit_disposal.php\n    [3] => Edit Disposal\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 54\n)\n', '/smm/sysadmin/edit_user_links.php'),
(318, '::1', 'root', '2017-03-09 15:45:53', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(319, '::1', 'root', '2017-03-09 15:45:53', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View disposal\n    [2] => modules/equipment/disposal/listview_disposal.php\n    [3] => Disposal\n    [4] => \n    [5] => 3\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 55\n)\n', '/smm/sysadmin/edit_user_links.php'),
(320, '::1', 'root', '2017-03-09 15:46:04', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(321, '::1', 'root', '2017-03-09 15:46:04', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete disposal\n    [2] => modules/equipment/disposal/delete_disposal.php\n    [3] => Delete Disposal\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 56\n)\n', '/smm/sysadmin/edit_user_links.php'),
(322, '::1', 'root', '2017-03-09 15:49:52', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(323, '::1', 'root', '2017-03-09 15:49:52', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add equipment\n    [2] => modules/equipment/equipment/add_equipment.php\n    [3] => Add Equipment\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 61\n)\n', '/smm/sysadmin/edit_user_links.php'),
(324, '::1', 'root', '2017-03-09 15:49:58', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(325, '::1', 'root', '2017-03-09 15:49:58', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit equipment\n    [2] => modules/equipment/equipment/edit_equipment.php\n    [3] => Edit Equipment\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 62\n)\n', '/smm/sysadmin/edit_user_links.php'),
(326, '::1', 'root', '2017-03-09 15:50:04', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(327, '::1', 'root', '2017-03-09 15:50:04', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View equipment\n    [2] => modules/equipment/equipment/listview_equipment.php\n    [3] => Equipment\n    [4] => \n    [5] => 3\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 63\n)\n', '/smm/sysadmin/edit_user_links.php'),
(328, '::1', 'root', '2017-03-09 15:50:14', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(329, '::1', 'root', '2017-03-09 15:50:14', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete equipment\n    [2] => modules/equipment/equipment/delete_equipment.php\n    [3] => Delete Equipment\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 64\n)\n', '/smm/sysadmin/edit_user_links.php'),
(330, '::1', 'root', '2017-03-09 15:50:21', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(331, '::1', 'root', '2017-03-09 15:50:21', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add purchase data\n    [2] => modules/equipment/purchase_data/add_purchase_data.php\n    [3] => Add Purchase Data\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 73\n)\n', '/smm/sysadmin/edit_user_links.php'),
(332, '::1', 'root', '2017-03-09 15:50:26', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(333, '::1', 'root', '2017-03-09 15:50:27', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit purchase data\n    [2] => modules/equipment/purchase_data/edit_purchase_data.php\n    [3] => Edit Purchase Data\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 74\n)\n', '/smm/sysadmin/edit_user_links.php'),
(334, '::1', 'root', '2017-03-09 15:50:34', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(335, '::1', 'root', '2017-03-09 15:50:35', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View purchase data\n    [2] => modules/equipment/purchase_data/listview_purchase_data.php\n    [3] => Purchase Data\n    [4] => \n    [5] => 3\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 75\n)\n', '/smm/sysadmin/edit_user_links.php'),
(336, '::1', 'root', '2017-03-09 15:50:41', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(337, '::1', 'root', '2017-03-09 15:50:41', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete purchase data\n    [2] => modules/equipment/purchase_data/delete_purchase_data.php\n    [3] => Delete Purchase Data\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 76\n)\n', '/smm/sysadmin/edit_user_links.php'),
(338, '::1', 'root', '2017-03-09 15:50:47', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(339, '::1', 'root', '2017-03-09 15:50:48', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add purchase data document\n    [2] => modules/equipment/purchase_data_document/add_purchase_data_document.php\n    [3] => Add Purchase Data Document\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 77\n)\n', '/smm/sysadmin/edit_user_links.php'),
(340, '::1', 'root', '2017-03-09 15:50:53', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(341, '::1', 'root', '2017-03-09 15:50:53', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit purchase data document\n    [2] => modules/equipment/purchase_data_document/edit_purchase_data_document.php\n    [3] => Edit Purchase Data Document\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 78\n)\n', '/smm/sysadmin/edit_user_links.php'),
(342, '::1', 'root', '2017-03-09 15:51:02', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(343, '::1', 'root', '2017-03-09 15:51:02', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View purchase data document\n    [2] => modules/equipment/purchase_data_document/listview_purchase_data_document.php\n    [3] => Purchase Data Document\n    [4] => \n    [5] => 3\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 79\n)\n', '/smm/sysadmin/edit_user_links.php'),
(344, '::1', 'root', '2017-03-09 15:51:09', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(345, '::1', 'root', '2017-03-09 15:51:09', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete purchase data document\n    [2] => modules/equipment/purchase_data_document/delete_purchase_data_document.php\n    [3] => Delete Purchase Data Document\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 80\n)\n', '/smm/sysadmin/edit_user_links.php'),
(346, '::1', 'root', '2017-03-09 15:51:14', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(347, '::1', 'root', '2017-03-09 15:51:14', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add warranty\n    [2] => modules/equipment/warranty/add_warranty.php\n    [3] => Add Warranty\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 81\n)\n', '/smm/sysadmin/edit_user_links.php'),
(348, '::1', 'root', '2017-03-09 15:51:19', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(349, '::1', 'root', '2017-03-09 15:51:19', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit warranty\n    [2] => modules/equipment/warranty/edit_warranty.php\n    [3] => Edit Warranty\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 82\n)\n', '/smm/sysadmin/edit_user_links.php'),
(350, '::1', 'root', '2017-03-09 15:51:23', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(351, '::1', 'root', '2017-03-09 15:51:23', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View warranty\n    [2] => modules/equipment/warranty/listview_warranty.php\n    [3] => Warranty\n    [4] => \n    [5] => 3\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 83\n)\n', '/smm/sysadmin/edit_user_links.php'),
(352, '::1', 'root', '2017-03-09 15:51:28', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(353, '::1', 'root', '2017-03-09 15:51:28', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete warranty\n    [2] => modules/equipment/warranty/delete_warranty.php\n    [3] => Delete Warranty\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 84\n)\n', '/smm/sysadmin/edit_user_links.php'),
(354, '::1', 'root', '2017-03-09 15:52:45', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(355, '::1', 'root', '2017-03-09 15:52:45', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add employee\n    [2] => modules/staff/employee/add_employee.php\n    [3] => Add Employee\n    [4] => \n    [5] => 4\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 57\n)\n', '/smm/sysadmin/edit_user_links.php'),
(356, '::1', 'root', '2017-03-09 15:52:49', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(357, '::1', 'root', '2017-03-09 15:52:49', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit employee\n    [2] => modules/staff/employee/edit_employee.php\n    [3] => Edit Employee\n    [4] => \n    [5] => 4\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 58\n)\n', '/smm/sysadmin/edit_user_links.php'),
(358, '::1', 'root', '2017-03-09 15:52:53', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(359, '::1', 'root', '2017-03-09 15:52:53', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View employee\n    [2] => modules/staff/employee/listview_employee.php\n    [3] => Employee\n    [4] => \n    [5] => 4\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 59\n)\n', '/smm/sysadmin/edit_user_links.php'),
(360, '::1', 'root', '2017-03-09 15:52:56', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(361, '::1', 'root', '2017-03-09 15:52:57', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete employee\n    [2] => modules/staff/employee/delete_employee.php\n    [3] => Delete Employee\n    [4] => \n    [5] => 4\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 60\n)\n', '/smm/sysadmin/edit_user_links.php'),
(362, '::1', 'root', '2017-03-09 15:53:25', 'Pressed cancel button', '/smm/sysadmin/add_user_passport_groups.php'),
(363, '::1', 'root', '2017-03-09 15:53:30', 'Pressed submit button', '/smm/sysadmin/edit_user_passport_groups.php'),
(364, '::1', 'root', '2017-03-09 15:53:30', 'Query Executed: UPDATE user_passport_groups SET passport_group = ?, priority = ?, icon = ? WHERE passport_group_id = ?\r\nArray\n(\n    [0] => sisi\n    [1] => Assignment\n    [2] => 4\n    [3] => blue_folder3.png\n    [4] => 6\n)\n', '/smm/sysadmin/edit_user_passport_groups.php'),
(365, '::1', 'root', '2017-03-09 15:57:07', 'Pressed cancel button', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(366, '::1', 'root', '2017-03-09 16:02:59', 'Logged out', '/smm/end.php'),
(367, '::1', 'root', '2017-03-09 16:03:03', 'Logged in', '/smm/login.php'),
(368, '::1', 'root', '2017-03-13 14:58:30', 'Logged in', '/smm/login.php'),
(369, '::1', 'root', '2017-03-13 15:03:22', 'Query executed: DELETE FROM user_role_links WHERE role_id=''1''', '/smm/sysadmin/role_permissions.php'),
(370, '::1', 'root', '2017-03-13 15:03:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''37'')', '/smm/sysadmin/role_permissions.php'),
(371, '::1', 'root', '2017-03-13 15:03:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''41'')', '/smm/sysadmin/role_permissions.php'),
(372, '::1', 'root', '2017-03-13 15:03:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''33'')', '/smm/sysadmin/role_permissions.php'),
(373, '::1', 'root', '2017-03-13 15:03:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''45'')', '/smm/sysadmin/role_permissions.php'),
(374, '::1', 'root', '2017-03-13 15:03:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''49'')', '/smm/sysadmin/role_permissions.php'),
(375, '::1', 'root', '2017-03-13 15:03:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''53'')', '/smm/sysadmin/role_permissions.php'),
(376, '::1', 'root', '2017-03-13 15:03:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''57'')', '/smm/sysadmin/role_permissions.php'),
(377, '::1', 'root', '2017-03-13 15:03:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''61'')', '/smm/sysadmin/role_permissions.php'),
(378, '::1', 'root', '2017-03-13 15:03:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''85'')', '/smm/sysadmin/role_permissions.php'),
(379, '::1', 'root', '2017-03-13 15:03:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''4'')', '/smm/sysadmin/role_permissions.php'),
(380, '::1', 'root', '2017-03-13 15:03:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''65'')', '/smm/sysadmin/role_permissions.php'),
(381, '::1', 'root', '2017-03-13 15:03:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''69'')', '/smm/sysadmin/role_permissions.php'),
(382, '::1', 'root', '2017-03-13 15:03:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''73'')', '/smm/sysadmin/role_permissions.php'),
(383, '::1', 'root', '2017-03-13 15:03:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''77'')', '/smm/sysadmin/role_permissions.php'),
(384, '::1', 'root', '2017-03-13 15:03:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''16'')', '/smm/sysadmin/role_permissions.php'),
(385, '::1', 'root', '2017-03-13 15:03:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''28'')', '/smm/sysadmin/role_permissions.php'),
(386, '::1', 'root', '2017-03-13 15:03:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''8'')', '/smm/sysadmin/role_permissions.php'),
(387, '::1', 'root', '2017-03-13 15:03:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''20'')', '/smm/sysadmin/role_permissions.php'),
(388, '::1', 'root', '2017-03-13 15:03:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''24'')', '/smm/sysadmin/role_permissions.php'),
(389, '::1', 'root', '2017-03-13 15:03:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''12'')', '/smm/sysadmin/role_permissions.php'),
(390, '::1', 'root', '2017-03-13 15:03:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''81'')', '/smm/sysadmin/role_permissions.php'),
(391, '::1', 'root', '2017-03-13 15:03:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''39'')', '/smm/sysadmin/role_permissions.php'),
(392, '::1', 'root', '2017-03-13 15:03:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''43'')', '/smm/sysadmin/role_permissions.php'),
(393, '::1', 'root', '2017-03-13 15:03:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''35'')', '/smm/sysadmin/role_permissions.php'),
(394, '::1', 'root', '2017-03-13 15:03:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''47'')', '/smm/sysadmin/role_permissions.php'),
(395, '::1', 'root', '2017-03-13 15:03:23', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''51'')', '/smm/sysadmin/role_permissions.php'),
(396, '::1', 'root', '2017-03-13 15:03:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''40'')', '/smm/sysadmin/role_permissions.php'),
(397, '::1', 'root', '2017-03-13 15:03:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''44'')', '/smm/sysadmin/role_permissions.php'),
(398, '::1', 'root', '2017-03-13 15:03:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''36'')', '/smm/sysadmin/role_permissions.php'),
(399, '::1', 'root', '2017-03-13 15:03:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''48'')', '/smm/sysadmin/role_permissions.php'),
(400, '::1', 'root', '2017-03-13 15:03:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''52'')', '/smm/sysadmin/role_permissions.php'),
(401, '::1', 'root', '2017-03-13 15:03:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''56'')', '/smm/sysadmin/role_permissions.php'),
(402, '::1', 'root', '2017-03-13 15:03:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''60'')', '/smm/sysadmin/role_permissions.php'),
(403, '::1', 'root', '2017-03-13 15:03:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''64'')', '/smm/sysadmin/role_permissions.php'),
(404, '::1', 'root', '2017-03-13 15:03:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''88'')', '/smm/sysadmin/role_permissions.php'),
(405, '::1', 'root', '2017-03-13 15:03:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''7'')', '/smm/sysadmin/role_permissions.php'),
(406, '::1', 'root', '2017-03-13 15:03:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''68'')', '/smm/sysadmin/role_permissions.php'),
(407, '::1', 'root', '2017-03-13 15:03:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''72'')', '/smm/sysadmin/role_permissions.php'),
(408, '::1', 'root', '2017-03-13 15:03:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''76'')', '/smm/sysadmin/role_permissions.php'),
(409, '::1', 'root', '2017-03-13 15:03:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''80'')', '/smm/sysadmin/role_permissions.php'),
(410, '::1', 'root', '2017-03-13 15:03:24', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''19'')', '/smm/sysadmin/role_permissions.php'),
(411, '::1', 'root', '2017-03-13 15:03:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''31'')', '/smm/sysadmin/role_permissions.php'),
(412, '::1', 'root', '2017-03-13 15:03:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''11'')', '/smm/sysadmin/role_permissions.php'),
(413, '::1', 'root', '2017-03-13 15:03:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''23'')', '/smm/sysadmin/role_permissions.php'),
(414, '::1', 'root', '2017-03-13 15:03:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''27'')', '/smm/sysadmin/role_permissions.php'),
(415, '::1', 'root', '2017-03-13 15:03:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''15'')', '/smm/sysadmin/role_permissions.php'),
(416, '::1', 'root', '2017-03-13 15:03:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''84'')', '/smm/sysadmin/role_permissions.php'),
(417, '::1', 'root', '2017-03-13 15:03:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''55'')', '/smm/sysadmin/role_permissions.php'),
(418, '::1', 'root', '2017-03-13 15:03:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''38'')', '/smm/sysadmin/role_permissions.php'),
(419, '::1', 'root', '2017-03-13 15:03:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''42'')', '/smm/sysadmin/role_permissions.php'),
(420, '::1', 'root', '2017-03-13 15:03:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''34'')', '/smm/sysadmin/role_permissions.php'),
(421, '::1', 'root', '2017-03-13 15:03:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''46'')', '/smm/sysadmin/role_permissions.php');
INSERT INTO `system_log` (`entry_id`, `ip_address`, `user`, `datetime`, `action`, `module`) VALUES
(422, '::1', 'root', '2017-03-13 15:03:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''50'')', '/smm/sysadmin/role_permissions.php'),
(423, '::1', 'root', '2017-03-13 15:03:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''54'')', '/smm/sysadmin/role_permissions.php'),
(424, '::1', 'root', '2017-03-13 15:03:25', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''58'')', '/smm/sysadmin/role_permissions.php'),
(425, '::1', 'root', '2017-03-13 15:03:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''62'')', '/smm/sysadmin/role_permissions.php'),
(426, '::1', 'root', '2017-03-13 15:03:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''86'')', '/smm/sysadmin/role_permissions.php'),
(427, '::1', 'root', '2017-03-13 15:03:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''5'')', '/smm/sysadmin/role_permissions.php'),
(428, '::1', 'root', '2017-03-13 15:03:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''66'')', '/smm/sysadmin/role_permissions.php'),
(429, '::1', 'root', '2017-03-13 15:03:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''70'')', '/smm/sysadmin/role_permissions.php'),
(430, '::1', 'root', '2017-03-13 15:03:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''74'')', '/smm/sysadmin/role_permissions.php'),
(431, '::1', 'root', '2017-03-13 15:03:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''78'')', '/smm/sysadmin/role_permissions.php'),
(432, '::1', 'root', '2017-03-13 15:03:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''17'')', '/smm/sysadmin/role_permissions.php'),
(433, '::1', 'root', '2017-03-13 15:03:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''29'')', '/smm/sysadmin/role_permissions.php'),
(434, '::1', 'root', '2017-03-13 15:03:26', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''9'')', '/smm/sysadmin/role_permissions.php'),
(435, '::1', 'root', '2017-03-13 15:03:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''21'')', '/smm/sysadmin/role_permissions.php'),
(436, '::1', 'root', '2017-03-13 15:03:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''25'')', '/smm/sysadmin/role_permissions.php'),
(437, '::1', 'root', '2017-03-13 15:03:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''13'')', '/smm/sysadmin/role_permissions.php'),
(438, '::1', 'root', '2017-03-13 15:03:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''82'')', '/smm/sysadmin/role_permissions.php'),
(439, '::1', 'root', '2017-03-13 15:03:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''59'')', '/smm/sysadmin/role_permissions.php'),
(440, '::1', 'root', '2017-03-13 15:03:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''63'')', '/smm/sysadmin/role_permissions.php'),
(441, '::1', 'root', '2017-03-13 15:03:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''87'')', '/smm/sysadmin/role_permissions.php'),
(442, '::1', 'root', '2017-03-13 15:03:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''1'')', '/smm/sysadmin/role_permissions.php'),
(443, '::1', 'root', '2017-03-13 15:03:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''6'')', '/smm/sysadmin/role_permissions.php'),
(444, '::1', 'root', '2017-03-13 15:03:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''67'')', '/smm/sysadmin/role_permissions.php'),
(445, '::1', 'root', '2017-03-13 15:03:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''71'')', '/smm/sysadmin/role_permissions.php'),
(446, '::1', 'root', '2017-03-13 15:03:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''75'')', '/smm/sysadmin/role_permissions.php'),
(447, '::1', 'root', '2017-03-13 15:03:27', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''79'')', '/smm/sysadmin/role_permissions.php'),
(448, '::1', 'root', '2017-03-13 15:03:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''32'')', '/smm/sysadmin/role_permissions.php'),
(449, '::1', 'root', '2017-03-13 15:03:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''3'')', '/smm/sysadmin/role_permissions.php'),
(450, '::1', 'root', '2017-03-13 15:03:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''2'')', '/smm/sysadmin/role_permissions.php'),
(451, '::1', 'root', '2017-03-13 15:03:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''18'')', '/smm/sysadmin/role_permissions.php'),
(452, '::1', 'root', '2017-03-13 15:03:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''30'')', '/smm/sysadmin/role_permissions.php'),
(453, '::1', 'root', '2017-03-13 15:03:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''10'')', '/smm/sysadmin/role_permissions.php'),
(454, '::1', 'root', '2017-03-13 15:03:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''22'')', '/smm/sysadmin/role_permissions.php'),
(455, '::1', 'root', '2017-03-13 15:03:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''26'')', '/smm/sysadmin/role_permissions.php'),
(456, '::1', 'root', '2017-03-13 15:03:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''14'')', '/smm/sysadmin/role_permissions.php'),
(457, '::1', 'root', '2017-03-13 15:03:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''83'')', '/smm/sysadmin/role_permissions.php'),
(458, '::1', 'root', '2017-03-13 15:03:46', 'Query executed: DELETE FROM user_passport WHERE username IN (''root'')', '/smm/sysadmin/role_permissions_cascade.php'),
(459, '::1', 'root', '2017-03-13 15:03:46', 'Query executed: INSERT `user_passport` SELECT ''root'', `link_id` FROM user_role_links WHERE role_id=''1''', '/smm/sysadmin/role_permissions_cascade.php'),
(460, '::1', 'root', '2017-03-13 15:03:47', 'Pressed cancel button', '/smm/sysadmin/role_permissions_cascade.php'),
(461, '::1', 'root', '2017-03-13 15:05:57', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(462, '::1', 'root', '2017-03-13 15:05:57', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add longetivity\n    [2] => modules/equipment/longetivity/add_longetivity.php\n    [3] => Add Longetivity\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 85\n)\n', '/smm/sysadmin/edit_user_links.php'),
(463, '::1', 'root', '2017-03-13 15:06:04', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(464, '::1', 'root', '2017-03-13 15:06:04', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit longetivity\n    [2] => modules/equipment/longetivity/edit_longetivity.php\n    [3] => Edit Longetivity\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 86\n)\n', '/smm/sysadmin/edit_user_links.php'),
(465, '::1', 'root', '2017-03-13 15:06:10', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(466, '::1', 'root', '2017-03-13 15:06:10', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View longetivity\n    [2] => modules/equipment/longetivity/listview_longetivity.php\n    [3] => Longetivity\n    [4] => \n    [5] => 3\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 87\n)\n', '/smm/sysadmin/edit_user_links.php'),
(467, '::1', 'root', '2017-03-13 15:06:15', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(468, '::1', 'root', '2017-03-13 15:06:16', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete longetivity\n    [2] => modules/equipment/longetivity/delete_longetivity.php\n    [3] => Delete Longetivity\n    [4] => \n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 88\n)\n', '/smm/sysadmin/edit_user_links.php'),
(469, '::1', 'root', '2017-03-13 15:35:01', 'Pressed submit button', '/smm/modules/equipment/longetivity/add_longetivity.php'),
(470, '::1', 'root', '2017-03-13 15:35:07', 'Pressed submit button', '/smm/modules/equipment/longetivity/add_longetivity.php'),
(471, '::1', 'root', '2017-03-13 15:35:11', 'Pressed cancel button', '/smm/modules/equipment/longetivity/add_longetivity.php'),
(472, '::1', 'root', '2017-03-13 15:42:37', 'Pressed cancel button', '/smm/modules/equipment/longetivity/add_longetivity.php'),
(473, '::1', 'root', '2017-03-13 16:45:32', 'Pressed cancel button', '/smm/modules/equipment/longetivity/add_longetivity.php'),
(474, '::1', 'root', '2017-03-13 16:58:09', 'Pressed cancel button', '/smm/modules/equipment/longetivity/add_longetivity.php'),
(475, '::1', 'root', '2017-03-13 17:06:03', 'Logged in', '/smm/login.php'),
(476, '::1', 'root', '2017-03-13 17:10:04', 'Pressed submit button', '/smm/modules/staff/assignee/add_assignee.php'),
(477, '::1', 'root', '2017-03-13 17:10:04', 'Query Executed: INSERT INTO assignee(id, rooms, location, deployDate, employee_id) VALUES(?,?,?,?,?)\r\nArray\n(\n    [0] => isssi\n    [1] => \n    [2] => 1010\n    [3] => 10th Floor\n    [4] => 2017-03-13\n    [5] => 1\n)\n', '/smm/modules/staff/assignee/add_assignee.php'),
(478, '::1', 'root', '2017-03-13 17:11:29', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(479, '::1', 'root', '2017-03-13 17:11:30', 'Query Executed: INSERT INTO disposal(id, method, remarks, remove_date, dispose_date, equipment_id, assignee_id) VALUES(?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssii\n    [1] => \n    [2] => Destroy\n    [3] => X\n    [4] => 2017-03-13\n    [5] => 2017-03-13\n    [6] => 2\n    [7] => 1\n)\n', '/smm/modules/equipment/disposal/add_disposal.php'),
(480, '::1', 'root', '2017-03-13 17:11:45', 'Pressed submit button', '/smm/modules/equipment/disposal/reporter_disposal.php'),
(481, '::1', 'root', '2017-03-13 17:12:16', 'Query Executed: DELETE FROM cobalt_reporter WHERE module_name = ? AND report_name = ?\r\nArray\n(\n    [0] => ss\n    [1] => DISPOSAL_REPORT_CUSTOM\n    [2] => ASD\n)\n', '/smm/modules/equipment/disposal/reporter_disposal.php'),
(482, '::1', 'root', '2017-03-13 17:12:16', 'Query Executed: INSERT INTO cobalt_reporter(`module_name`,\n                            `report_name`,\n                            `username`,\n                            `show_field`,\n                            `operator`,\n                            `text_field`,\n                            `sum_field`,\n                            `count_field`,\n                            `group_field1`,\n                            `group_field2`,\n                            `group_field3`) VALUES(?,?,?,?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => sssssssssss\n    [1] => DISPOSAL_REPORT_CUSTOM\n    [2] => ASD\n    [3] => root\n    [4] => a:17:{i:0;s:2:"ID";i:1;s:6:"Method";i:2;s:7:"Remarks";i:3;s:11:"Remove Date";i:4;s:12:"Dispose Date";i:5;s:17:"[Equipment Id] ID";i:6;s:19:"[Equipment Id] Name";i:7;s:19:"[Equipment Id] Type";i:8;s:20:"[Equipment Id] Brand";i:9;s:26:"[Equipment Id] Description";i:10;s:23:"[Equipment Id] Function";i:11;s:20:"[Equipment Id] Price";i:12;s:21:"[Equipment Id] Rating";i:13;s:16:"[Assignee Id] ID";i:14;s:19:"[Assignee Id] Rooms";i:15;s:22:"[Assignee Id] Location";i:16;s:25:"[Assignee Id] Deploy Date";}\n    [5] => a:17:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";i:4;s:0:"";i:5;s:0:"";i:6;s:0:"";i:7;s:0:"";i:8;s:0:"";i:9;s:0:"";i:10;s:0:"";i:11;s:0:"";i:12;s:0:"";i:13;s:0:"";i:14;s:0:"";i:15;s:0:"";i:16;s:0:"";}\n    [6] => a:17:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";i:4;s:0:"";i:5;s:0:"";i:6;s:0:"";i:7;s:0:"";i:8;s:0:"";i:9;s:0:"";i:10;s:0:"";i:11;s:0:"";i:12;s:0:"";i:13;s:0:"";i:14;s:0:"";i:15;s:0:"";i:16;s:0:"";}\n    [7] => a:1:{i:0;s:11:"Remove Date";}\n    [8] => \n    [9] => \n    [10] => \n    [11] => \n)\n', '/smm/modules/equipment/disposal/reporter_disposal.php'),
(483, '::1', 'root', '2017-03-13 17:12:28', 'Pressed submit button', '/smm/modules/equipment/disposal/reporter_disposal.php'),
(484, '::1', 'root', '2017-03-16 15:38:55', 'Logged in', '/smm/login.php'),
(485, '::1', 'root', '2017-03-16 15:41:05', 'Query executed: UPDATE user SET skin_id=''2'' WHERE username=''root''', '/smm/change_skin.php'),
(486, '::1', 'root', '2017-03-16 15:41:09', 'Query executed: UPDATE user SET skin_id=''5'' WHERE username=''root''', '/smm/change_skin.php'),
(487, '::1', 'root', '2017-03-16 15:41:17', 'Query executed: UPDATE user SET skin_id=''10'' WHERE username=''root''', '/smm/change_skin.php'),
(488, '::1', 'root', '2017-03-16 15:41:22', 'Query executed: UPDATE user SET skin_id=''7'' WHERE username=''root''', '/smm/change_skin.php'),
(489, '::1', 'root', '2017-03-16 15:41:25', 'Query executed: UPDATE user SET skin_id=''6'' WHERE username=''root''', '/smm/change_skin.php'),
(490, '::1', 'root', '2017-03-16 16:13:46', 'Pressed submit button', '/smm/modules/staff/assignee/add_assignee.php'),
(491, '::1', 'root', '2017-03-16 16:13:46', 'Query Executed: INSERT INTO assignee(id, rooms, location, deployDate, employee_id) VALUES(?,?,?,?,?)\r\nArray\n(\n    [0] => isssi\n    [1] => \n    [2] => 316\n    [3] => 3rd Floor - LAB\n    [4] => 2017-03-16\n    [5] => 1\n)\n', '/smm/modules/staff/assignee/add_assignee.php'),
(492, '::1', 'root', '2017-03-16 16:14:45', 'Pressed submit button', '/smm/modules/equipment/assignment/add_assignment.php'),
(493, '::1', 'root', '2017-03-16 16:14:45', 'Query Executed: INSERT INTO assignment(id, name, equipment_id, assignee_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => isii\n    [1] => \n    [2] => ada\n    [3] => 1\n    [4] => 1\n)\n', '/smm/modules/equipment/assignment/add_assignment.php'),
(494, '::1', 'root', '2017-03-16 16:16:59', 'Pressed cancel button', '/smm/modules/maintenance/preventive_history/add_preventive_history.php'),
(495, '::1', 'root', '2017-03-16 16:17:42', 'Pressed submit button', '/smm/modules/maintenance/preventive_history/add_preventive_history.php'),
(496, '::1', 'root', '2017-03-16 16:17:42', 'Query Executed: INSERT INTO preventive_history(id, time, state, equipment_id, employee_id) VALUES(?,?,?,?,?)\r\nArray\n(\n    [0] => issii\n    [1] => \n    [2] => 4:30\n    [3] => Functional\n    [4] => 1\n    [5] => 2\n)\n', '/smm/modules/maintenance/preventive_history/add_preventive_history.php'),
(497, '::1', 'root', '2017-03-21 10:59:29', 'Logged in', '/smm/login.php'),
(498, '::1', 'root', '2017-03-21 11:03:27', 'Pressed submit button', '/smm/sysadmin/add_user_links.php'),
(499, '::1', 'root', '2017-03-21 11:03:27', 'Query Executed: INSERT INTO user_links(link_id, name, target, descriptive_title, description, passport_group_id, show_in_tasklist, status, icon, priority) VALUES(?,?,?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssisssi\n    [1] => \n    [2] => sample\n    [3] => modules/reports/sample.php\n    [4] => Sample\n    [5] => X\n    [6] => 5\n    [7] => Yes\n    [8] => On\n    [9] => form3.png\n    [10] => 1\n)\n', '/smm/sysadmin/add_user_links.php'),
(500, '::1', 'root', '2017-03-21 11:03:48', 'Query executed: DELETE FROM user_role_links WHERE role_id=''1''', '/smm/sysadmin/role_permissions.php'),
(501, '::1', 'root', '2017-03-21 11:03:49', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''37'')', '/smm/sysadmin/role_permissions.php'),
(502, '::1', 'root', '2017-03-21 11:03:49', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''41'')', '/smm/sysadmin/role_permissions.php'),
(503, '::1', 'root', '2017-03-21 11:03:49', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''33'')', '/smm/sysadmin/role_permissions.php'),
(504, '::1', 'root', '2017-03-21 11:03:49', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''45'')', '/smm/sysadmin/role_permissions.php'),
(505, '::1', 'root', '2017-03-21 11:03:49', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''49'')', '/smm/sysadmin/role_permissions.php'),
(506, '::1', 'root', '2017-03-21 11:03:49', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''53'')', '/smm/sysadmin/role_permissions.php'),
(507, '::1', 'root', '2017-03-21 11:03:49', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''57'')', '/smm/sysadmin/role_permissions.php'),
(508, '::1', 'root', '2017-03-21 11:03:49', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''61'')', '/smm/sysadmin/role_permissions.php'),
(509, '::1', 'root', '2017-03-21 11:03:49', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''4'')', '/smm/sysadmin/role_permissions.php'),
(510, '::1', 'root', '2017-03-21 11:03:49', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''65'')', '/smm/sysadmin/role_permissions.php'),
(511, '::1', 'root', '2017-03-21 11:03:49', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''69'')', '/smm/sysadmin/role_permissions.php'),
(512, '::1', 'root', '2017-03-21 11:03:49', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''73'')', '/smm/sysadmin/role_permissions.php'),
(513, '::1', 'root', '2017-03-21 11:03:49', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''77'')', '/smm/sysadmin/role_permissions.php'),
(514, '::1', 'root', '2017-03-21 11:03:50', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''16'')', '/smm/sysadmin/role_permissions.php'),
(515, '::1', 'root', '2017-03-21 11:03:50', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''28'')', '/smm/sysadmin/role_permissions.php'),
(516, '::1', 'root', '2017-03-21 11:03:50', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''8'')', '/smm/sysadmin/role_permissions.php'),
(517, '::1', 'root', '2017-03-21 11:03:50', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''20'')', '/smm/sysadmin/role_permissions.php'),
(518, '::1', 'root', '2017-03-21 11:03:50', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''24'')', '/smm/sysadmin/role_permissions.php'),
(519, '::1', 'root', '2017-03-21 11:03:50', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''12'')', '/smm/sysadmin/role_permissions.php'),
(520, '::1', 'root', '2017-03-21 11:03:50', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''81'')', '/smm/sysadmin/role_permissions.php'),
(521, '::1', 'root', '2017-03-21 11:03:50', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''39'')', '/smm/sysadmin/role_permissions.php'),
(522, '::1', 'root', '2017-03-21 11:03:50', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''43'')', '/smm/sysadmin/role_permissions.php'),
(523, '::1', 'root', '2017-03-21 11:03:50', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''35'')', '/smm/sysadmin/role_permissions.php'),
(524, '::1', 'root', '2017-03-21 11:03:50', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''47'')', '/smm/sysadmin/role_permissions.php'),
(525, '::1', 'root', '2017-03-21 11:03:50', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''51'')', '/smm/sysadmin/role_permissions.php'),
(526, '::1', 'root', '2017-03-21 11:03:51', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''40'')', '/smm/sysadmin/role_permissions.php'),
(527, '::1', 'root', '2017-03-21 11:03:51', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''44'')', '/smm/sysadmin/role_permissions.php'),
(528, '::1', 'root', '2017-03-21 11:03:51', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''36'')', '/smm/sysadmin/role_permissions.php'),
(529, '::1', 'root', '2017-03-21 11:03:51', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''48'')', '/smm/sysadmin/role_permissions.php'),
(530, '::1', 'root', '2017-03-21 11:03:51', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''52'')', '/smm/sysadmin/role_permissions.php'),
(531, '::1', 'root', '2017-03-21 11:03:51', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''56'')', '/smm/sysadmin/role_permissions.php'),
(532, '::1', 'root', '2017-03-21 11:03:51', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''60'')', '/smm/sysadmin/role_permissions.php'),
(533, '::1', 'root', '2017-03-21 11:03:51', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''64'')', '/smm/sysadmin/role_permissions.php'),
(534, '::1', 'root', '2017-03-21 11:03:51', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''7'')', '/smm/sysadmin/role_permissions.php'),
(535, '::1', 'root', '2017-03-21 11:03:51', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''68'')', '/smm/sysadmin/role_permissions.php'),
(536, '::1', 'root', '2017-03-21 11:03:51', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''72'')', '/smm/sysadmin/role_permissions.php'),
(537, '::1', 'root', '2017-03-21 11:03:51', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''76'')', '/smm/sysadmin/role_permissions.php'),
(538, '::1', 'root', '2017-03-21 11:03:51', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''80'')', '/smm/sysadmin/role_permissions.php'),
(539, '::1', 'root', '2017-03-21 11:03:52', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''19'')', '/smm/sysadmin/role_permissions.php'),
(540, '::1', 'root', '2017-03-21 11:03:52', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''31'')', '/smm/sysadmin/role_permissions.php'),
(541, '::1', 'root', '2017-03-21 11:03:52', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''11'')', '/smm/sysadmin/role_permissions.php'),
(542, '::1', 'root', '2017-03-21 11:03:52', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''23'')', '/smm/sysadmin/role_permissions.php'),
(543, '::1', 'root', '2017-03-21 11:03:52', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''27'')', '/smm/sysadmin/role_permissions.php'),
(544, '::1', 'root', '2017-03-21 11:03:52', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''15'')', '/smm/sysadmin/role_permissions.php'),
(545, '::1', 'root', '2017-03-21 11:03:52', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''55'')', '/smm/sysadmin/role_permissions.php'),
(546, '::1', 'root', '2017-03-21 11:03:52', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''38'')', '/smm/sysadmin/role_permissions.php'),
(547, '::1', 'root', '2017-03-21 11:03:52', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''42'')', '/smm/sysadmin/role_permissions.php'),
(548, '::1', 'root', '2017-03-21 11:03:52', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''34'')', '/smm/sysadmin/role_permissions.php'),
(549, '::1', 'root', '2017-03-21 11:03:52', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''46'')', '/smm/sysadmin/role_permissions.php'),
(550, '::1', 'root', '2017-03-21 11:03:52', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''50'')', '/smm/sysadmin/role_permissions.php'),
(551, '::1', 'root', '2017-03-21 11:03:52', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''54'')', '/smm/sysadmin/role_permissions.php'),
(552, '::1', 'root', '2017-03-21 11:03:52', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''58'')', '/smm/sysadmin/role_permissions.php'),
(553, '::1', 'root', '2017-03-21 11:03:53', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''62'')', '/smm/sysadmin/role_permissions.php'),
(554, '::1', 'root', '2017-03-21 11:03:53', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''5'')', '/smm/sysadmin/role_permissions.php'),
(555, '::1', 'root', '2017-03-21 11:03:53', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''66'')', '/smm/sysadmin/role_permissions.php'),
(556, '::1', 'root', '2017-03-21 11:03:53', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''70'')', '/smm/sysadmin/role_permissions.php'),
(557, '::1', 'root', '2017-03-21 11:03:53', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''74'')', '/smm/sysadmin/role_permissions.php'),
(558, '::1', 'root', '2017-03-21 11:03:53', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''78'')', '/smm/sysadmin/role_permissions.php'),
(559, '::1', 'root', '2017-03-21 11:03:53', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''17'')', '/smm/sysadmin/role_permissions.php'),
(560, '::1', 'root', '2017-03-21 11:03:53', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''29'')', '/smm/sysadmin/role_permissions.php'),
(561, '::1', 'root', '2017-03-21 11:03:53', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''9'')', '/smm/sysadmin/role_permissions.php'),
(562, '::1', 'root', '2017-03-21 11:03:53', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''21'')', '/smm/sysadmin/role_permissions.php'),
(563, '::1', 'root', '2017-03-21 11:03:53', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''25'')', '/smm/sysadmin/role_permissions.php'),
(564, '::1', 'root', '2017-03-21 11:03:53', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''13'')', '/smm/sysadmin/role_permissions.php'),
(565, '::1', 'root', '2017-03-21 11:03:53', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''82'')', '/smm/sysadmin/role_permissions.php'),
(566, '::1', 'root', '2017-03-21 11:03:54', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''59'')', '/smm/sysadmin/role_permissions.php'),
(567, '::1', 'root', '2017-03-21 11:03:54', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''63'')', '/smm/sysadmin/role_permissions.php'),
(568, '::1', 'root', '2017-03-21 11:03:54', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''1'')', '/smm/sysadmin/role_permissions.php'),
(569, '::1', 'root', '2017-03-21 11:03:54', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''6'')', '/smm/sysadmin/role_permissions.php'),
(570, '::1', 'root', '2017-03-21 11:03:54', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''67'')', '/smm/sysadmin/role_permissions.php'),
(571, '::1', 'root', '2017-03-21 11:03:54', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''71'')', '/smm/sysadmin/role_permissions.php'),
(572, '::1', 'root', '2017-03-21 11:03:54', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''75'')', '/smm/sysadmin/role_permissions.php'),
(573, '::1', 'root', '2017-03-21 11:03:54', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''79'')', '/smm/sysadmin/role_permissions.php'),
(574, '::1', 'root', '2017-03-21 11:03:54', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''32'')', '/smm/sysadmin/role_permissions.php'),
(575, '::1', 'root', '2017-03-21 11:03:54', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''84'')', '/smm/sysadmin/role_permissions.php'),
(576, '::1', 'root', '2017-03-21 11:03:54', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''3'')', '/smm/sysadmin/role_permissions.php'),
(577, '::1', 'root', '2017-03-21 11:03:54', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''2'')', '/smm/sysadmin/role_permissions.php'),
(578, '::1', 'root', '2017-03-21 11:03:54', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''18'')', '/smm/sysadmin/role_permissions.php'),
(579, '::1', 'root', '2017-03-21 11:03:54', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''30'')', '/smm/sysadmin/role_permissions.php'),
(580, '::1', 'root', '2017-03-21 11:03:55', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''10'')', '/smm/sysadmin/role_permissions.php'),
(581, '::1', 'root', '2017-03-21 11:03:55', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''22'')', '/smm/sysadmin/role_permissions.php'),
(582, '::1', 'root', '2017-03-21 11:03:55', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''26'')', '/smm/sysadmin/role_permissions.php'),
(583, '::1', 'root', '2017-03-21 11:03:55', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''14'')', '/smm/sysadmin/role_permissions.php'),
(584, '::1', 'root', '2017-03-21 11:03:55', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''83'')', '/smm/sysadmin/role_permissions.php'),
(585, '::1', 'root', '2017-03-21 11:04:02', 'Query executed: DELETE FROM user_passport WHERE username IN (''root'')', '/smm/sysadmin/role_permissions_cascade.php'),
(586, '::1', 'root', '2017-03-21 11:04:02', 'Query executed: INSERT `user_passport` SELECT ''root'', `link_id` FROM user_role_links WHERE role_id=''1''', '/smm/sysadmin/role_permissions_cascade.php'),
(587, '::1', 'root', '2017-03-21 11:04:04', 'Pressed cancel button', '/smm/sysadmin/role_permissions_cascade.php'),
(588, '::1', 'root', '2017-03-21 11:24:03', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(589, '::1', 'root', '2017-03-21 11:25:41', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(590, '::1', 'root', '2017-03-21 11:26:15', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(591, '::1', 'root', '2017-03-21 11:26:30', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(592, '::1', 'root', '2017-03-21 11:26:47', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(593, '::1', 'root', '2017-03-21 11:26:56', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(594, '::1', 'root', '2017-03-21 11:28:00', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(595, '::1', 'root', '2017-03-21 14:31:22', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(596, '::1', 'root', '2017-03-23 15:36:41', 'Logged in', '/smm/login.php'),
(597, '::1', 'root', '2017-03-23 15:36:45', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(598, '::1', 'root', '2017-03-23 15:49:11', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(599, '::1', 'root', '2017-03-23 15:50:30', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(600, '::1', 'root', '2017-03-23 15:50:43', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(601, '::1', 'root', '2017-03-23 15:51:41', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(602, '::1', 'root', '2017-03-23 15:52:08', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(603, '::1', 'root', '2017-03-23 15:53:15', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(604, '::1', 'root', '2017-03-23 15:54:06', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(605, '::1', 'root', '2017-03-23 15:55:12', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(606, '::1', 'root', '2017-03-23 15:56:54', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(607, '::1', 'root', '2017-03-23 15:56:57', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(608, '::1', 'root', '2017-03-23 16:23:08', 'Pressed cancel button', '/smm/modules/equipment/purchase_data_document/edit_purchase_data_document.php'),
(609, '::1', 'root', '2017-03-23 16:30:25', 'Pressed cancel button', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(610, '::1', 'root', '2017-03-23 16:31:03', 'Pressed submit button', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(611, '::1', 'root', '2017-03-23 16:31:03', 'Query Executed: INSERT INTO purchase_data(id, purchase_date, receive_date, receiver, person, location, contact, equiment_id) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssssi\n    [1] => \n    [2] => 2017-03-23\n    [3] => 2017-03-23\n    [4] => Alvin\n    [5] => Adrian\n    [6] => X\n    [7] => 01920321212\n    [8] => 3\n)\n', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(612, '::1', 'root', '2017-03-23 16:31:03', 'Query Executed: INSERT INTO purchase_data_document(id, document, remarks, purchase_data_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => issi\n    [1] => \n    [2] => 3157ce727f44575c451d7b05532cd033e618dd90FinalsAnswer2.docx\n    [3] => X\n    [4] => 2\n)\n', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(613, '::1', 'root', '2017-03-23 16:31:03', 'Query Executed: INSERT INTO purchase_data_document(id, document, remarks, purchase_data_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => issi\n    [1] => \n    [2] => 585adf679476a67a179c6d88bf1cadb78174064eFeb20part2.pptx\n    [3] => X\n    [4] => 2\n)\n', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(614, '::1', 'root', '2017-03-23 16:31:03', 'Query Executed: INSERT INTO purchase_data_document(id, document, remarks, purchase_data_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => issi\n    [1] => \n    [2] => dd11d2df68d25bac7dfd5e8b9e9f7c1cc9e146bcFeb20part1.pptx\n    [3] => xX\n    [4] => 2\n)\n', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(615, '::1', 'root', '2017-03-24 20:56:43', 'Logged in', '/smm/login.php'),
(616, '::1', 'root', '2017-03-24 20:57:37', 'Pressed submit button', '/smm/sysadmin/add_user_links.php'),
(617, '::1', 'root', '2017-03-24 20:58:27', 'Pressed submit button', '/smm/sysadmin/add_user_links.php'),
(618, '::1', 'root', '2017-03-24 20:58:27', 'Query Executed: INSERT INTO user_links(link_id, name, target, descriptive_title, description, passport_group_id, show_in_tasklist, status, icon, priority) VALUES(?,?,?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssisssi\n    [1] => \n    [2] => Report\n    [3] => \\modules\\reports\\report.php\n    [4] => Reports\n    [5] => X\n    [6] => 3\n    [7] => Yes\n    [8] => On\n    [9] => form3.png\n    [10] => 1\n)\n', '/smm/sysadmin/add_user_links.php'),
(619, '::1', 'root', '2017-03-24 20:59:00', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(620, '::1', 'root', '2017-03-24 20:59:00', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Report\n    [2] => modules/reports/report.php\n    [3] => Reports\n    [4] => X\n    [5] => 3\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 1\n    [10] => 85\n)\n', '/smm/sysadmin/edit_user_links.php'),
(621, '::1', 'root', '2017-03-24 20:59:17', 'Query executed: DELETE FROM user_role_links WHERE role_id=''1''', '/smm/sysadmin/role_permissions.php'),
(622, '::1', 'root', '2017-03-24 20:59:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''37'')', '/smm/sysadmin/role_permissions.php'),
(623, '::1', 'root', '2017-03-24 20:59:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''41'')', '/smm/sysadmin/role_permissions.php'),
(624, '::1', 'root', '2017-03-24 20:59:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''33'')', '/smm/sysadmin/role_permissions.php'),
(625, '::1', 'root', '2017-03-24 20:59:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''45'')', '/smm/sysadmin/role_permissions.php'),
(626, '::1', 'root', '2017-03-24 20:59:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''49'')', '/smm/sysadmin/role_permissions.php'),
(627, '::1', 'root', '2017-03-24 20:59:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''53'')', '/smm/sysadmin/role_permissions.php'),
(628, '::1', 'root', '2017-03-24 20:59:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''57'')', '/smm/sysadmin/role_permissions.php'),
(629, '::1', 'root', '2017-03-24 20:59:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''61'')', '/smm/sysadmin/role_permissions.php'),
(630, '::1', 'root', '2017-03-24 20:59:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''4'')', '/smm/sysadmin/role_permissions.php'),
(631, '::1', 'root', '2017-03-24 20:59:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''65'')', '/smm/sysadmin/role_permissions.php'),
(632, '::1', 'root', '2017-03-24 20:59:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''69'')', '/smm/sysadmin/role_permissions.php'),
(633, '::1', 'root', '2017-03-24 20:59:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''73'')', '/smm/sysadmin/role_permissions.php'),
(634, '::1', 'root', '2017-03-24 20:59:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''77'')', '/smm/sysadmin/role_permissions.php'),
(635, '::1', 'root', '2017-03-24 20:59:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''16'')', '/smm/sysadmin/role_permissions.php'),
(636, '::1', 'root', '2017-03-24 20:59:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''28'')', '/smm/sysadmin/role_permissions.php'),
(637, '::1', 'root', '2017-03-24 20:59:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''8'')', '/smm/sysadmin/role_permissions.php'),
(638, '::1', 'root', '2017-03-24 20:59:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''20'')', '/smm/sysadmin/role_permissions.php'),
(639, '::1', 'root', '2017-03-24 20:59:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''24'')', '/smm/sysadmin/role_permissions.php'),
(640, '::1', 'root', '2017-03-24 20:59:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''12'')', '/smm/sysadmin/role_permissions.php'),
(641, '::1', 'root', '2017-03-24 20:59:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''81'')', '/smm/sysadmin/role_permissions.php'),
(642, '::1', 'root', '2017-03-24 20:59:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''39'')', '/smm/sysadmin/role_permissions.php'),
(643, '::1', 'root', '2017-03-24 20:59:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''43'')', '/smm/sysadmin/role_permissions.php'),
(644, '::1', 'root', '2017-03-24 20:59:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''35'')', '/smm/sysadmin/role_permissions.php'),
(645, '::1', 'root', '2017-03-24 20:59:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''47'')', '/smm/sysadmin/role_permissions.php'),
(646, '::1', 'root', '2017-03-24 20:59:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''51'')', '/smm/sysadmin/role_permissions.php'),
(647, '::1', 'root', '2017-03-24 20:59:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''40'')', '/smm/sysadmin/role_permissions.php'),
(648, '::1', 'root', '2017-03-24 20:59:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''44'')', '/smm/sysadmin/role_permissions.php'),
(649, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''36'')', '/smm/sysadmin/role_permissions.php'),
(650, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''48'')', '/smm/sysadmin/role_permissions.php'),
(651, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''52'')', '/smm/sysadmin/role_permissions.php'),
(652, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''56'')', '/smm/sysadmin/role_permissions.php'),
(653, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''60'')', '/smm/sysadmin/role_permissions.php'),
(654, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''64'')', '/smm/sysadmin/role_permissions.php'),
(655, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''7'')', '/smm/sysadmin/role_permissions.php'),
(656, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''68'')', '/smm/sysadmin/role_permissions.php'),
(657, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''72'')', '/smm/sysadmin/role_permissions.php'),
(658, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''76'')', '/smm/sysadmin/role_permissions.php'),
(659, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''80'')', '/smm/sysadmin/role_permissions.php'),
(660, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''19'')', '/smm/sysadmin/role_permissions.php'),
(661, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''31'')', '/smm/sysadmin/role_permissions.php'),
(662, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''11'')', '/smm/sysadmin/role_permissions.php'),
(663, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''23'')', '/smm/sysadmin/role_permissions.php'),
(664, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''27'')', '/smm/sysadmin/role_permissions.php'),
(665, '::1', 'root', '2017-03-24 20:59:19', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''15'')', '/smm/sysadmin/role_permissions.php'),
(666, '::1', 'root', '2017-03-24 20:59:20', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''55'')', '/smm/sysadmin/role_permissions.php'),
(667, '::1', 'root', '2017-03-24 20:59:20', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''38'')', '/smm/sysadmin/role_permissions.php'),
(668, '::1', 'root', '2017-03-24 20:59:20', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''42'')', '/smm/sysadmin/role_permissions.php'),
(669, '::1', 'root', '2017-03-24 20:59:20', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''34'')', '/smm/sysadmin/role_permissions.php'),
(670, '::1', 'root', '2017-03-24 20:59:20', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''46'')', '/smm/sysadmin/role_permissions.php'),
(671, '::1', 'root', '2017-03-24 20:59:20', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''50'')', '/smm/sysadmin/role_permissions.php'),
(672, '::1', 'root', '2017-03-24 20:59:20', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''54'')', '/smm/sysadmin/role_permissions.php'),
(673, '::1', 'root', '2017-03-24 20:59:20', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''58'')', '/smm/sysadmin/role_permissions.php'),
(674, '::1', 'root', '2017-03-24 20:59:20', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''62'')', '/smm/sysadmin/role_permissions.php'),
(675, '::1', 'root', '2017-03-24 20:59:20', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''5'')', '/smm/sysadmin/role_permissions.php'),
(676, '::1', 'root', '2017-03-24 20:59:20', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''66'')', '/smm/sysadmin/role_permissions.php'),
(677, '::1', 'root', '2017-03-24 20:59:20', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''70'')', '/smm/sysadmin/role_permissions.php'),
(678, '::1', 'root', '2017-03-24 20:59:20', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''74'')', '/smm/sysadmin/role_permissions.php'),
(679, '::1', 'root', '2017-03-24 20:59:20', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''78'')', '/smm/sysadmin/role_permissions.php'),
(680, '::1', 'root', '2017-03-24 20:59:20', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''17'')', '/smm/sysadmin/role_permissions.php'),
(681, '::1', 'root', '2017-03-24 20:59:21', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''29'')', '/smm/sysadmin/role_permissions.php'),
(682, '::1', 'root', '2017-03-24 20:59:21', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''9'')', '/smm/sysadmin/role_permissions.php'),
(683, '::1', 'root', '2017-03-24 20:59:21', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''21'')', '/smm/sysadmin/role_permissions.php'),
(684, '::1', 'root', '2017-03-24 20:59:21', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''25'')', '/smm/sysadmin/role_permissions.php'),
(685, '::1', 'root', '2017-03-24 20:59:21', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''13'')', '/smm/sysadmin/role_permissions.php'),
(686, '::1', 'root', '2017-03-24 20:59:21', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''82'')', '/smm/sysadmin/role_permissions.php'),
(687, '::1', 'root', '2017-03-24 20:59:21', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''59'')', '/smm/sysadmin/role_permissions.php'),
(688, '::1', 'root', '2017-03-24 20:59:21', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''63'')', '/smm/sysadmin/role_permissions.php'),
(689, '::1', 'root', '2017-03-24 20:59:21', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''1'')', '/smm/sysadmin/role_permissions.php'),
(690, '::1', 'root', '2017-03-24 20:59:21', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''6'')', '/smm/sysadmin/role_permissions.php'),
(691, '::1', 'root', '2017-03-24 20:59:21', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''67'')', '/smm/sysadmin/role_permissions.php'),
(692, '::1', 'root', '2017-03-24 20:59:21', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''71'')', '/smm/sysadmin/role_permissions.php'),
(693, '::1', 'root', '2017-03-24 20:59:21', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''75'')', '/smm/sysadmin/role_permissions.php'),
(694, '::1', 'root', '2017-03-24 20:59:21', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''79'')', '/smm/sysadmin/role_permissions.php'),
(695, '::1', 'root', '2017-03-24 20:59:21', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''85'')', '/smm/sysadmin/role_permissions.php'),
(696, '::1', 'root', '2017-03-24 20:59:21', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''32'')', '/smm/sysadmin/role_permissions.php'),
(697, '::1', 'root', '2017-03-24 20:59:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''84'')', '/smm/sysadmin/role_permissions.php'),
(698, '::1', 'root', '2017-03-24 20:59:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''3'')', '/smm/sysadmin/role_permissions.php'),
(699, '::1', 'root', '2017-03-24 20:59:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''2'')', '/smm/sysadmin/role_permissions.php');
INSERT INTO `system_log` (`entry_id`, `ip_address`, `user`, `datetime`, `action`, `module`) VALUES
(700, '::1', 'root', '2017-03-24 20:59:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''18'')', '/smm/sysadmin/role_permissions.php'),
(701, '::1', 'root', '2017-03-24 20:59:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''30'')', '/smm/sysadmin/role_permissions.php'),
(702, '::1', 'root', '2017-03-24 20:59:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''10'')', '/smm/sysadmin/role_permissions.php'),
(703, '::1', 'root', '2017-03-24 20:59:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''22'')', '/smm/sysadmin/role_permissions.php'),
(704, '::1', 'root', '2017-03-24 20:59:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''26'')', '/smm/sysadmin/role_permissions.php'),
(705, '::1', 'root', '2017-03-24 20:59:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''14'')', '/smm/sysadmin/role_permissions.php'),
(706, '::1', 'root', '2017-03-24 20:59:22', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''83'')', '/smm/sysadmin/role_permissions.php'),
(707, '::1', 'root', '2017-03-24 20:59:32', 'Query executed: DELETE FROM user_passport WHERE username IN (''root'')', '/smm/sysadmin/role_permissions_cascade.php'),
(708, '::1', 'root', '2017-03-24 20:59:32', 'Query executed: INSERT `user_passport` SELECT ''root'', `link_id` FROM user_role_links WHERE role_id=''1''', '/smm/sysadmin/role_permissions_cascade.php'),
(709, '::1', 'root', '2017-03-24 20:59:33', 'Pressed cancel button', '/smm/sysadmin/role_permissions_cascade.php'),
(710, '::1', 'root', '2017-03-24 21:02:35', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(711, '::1', 'root', '2017-03-24 21:06:02', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(712, '::1', 'root', '2017-03-24 21:39:39', 'Logged in', '/smm/login.php'),
(713, '::1', 'root', '2017-03-24 21:48:28', 'Query executed: DELETE FROM user_role_links WHERE role_id=''1''', '/smm/sysadmin/role_permissions.php'),
(714, '::1', 'root', '2017-03-24 21:48:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''33'')', '/smm/sysadmin/role_permissions.php'),
(715, '::1', 'root', '2017-03-24 21:48:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''86'')', '/smm/sysadmin/role_permissions.php'),
(716, '::1', 'root', '2017-03-24 21:48:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''90'')', '/smm/sysadmin/role_permissions.php'),
(717, '::1', 'root', '2017-03-24 21:48:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''53'')', '/smm/sysadmin/role_permissions.php'),
(718, '::1', 'root', '2017-03-24 21:48:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''57'')', '/smm/sysadmin/role_permissions.php'),
(719, '::1', 'root', '2017-03-24 21:48:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''61'')', '/smm/sysadmin/role_permissions.php'),
(720, '::1', 'root', '2017-03-24 21:48:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''94'')', '/smm/sysadmin/role_permissions.php'),
(721, '::1', 'root', '2017-03-24 21:48:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''98'')', '/smm/sysadmin/role_permissions.php'),
(722, '::1', 'root', '2017-03-24 21:48:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''4'')', '/smm/sysadmin/role_permissions.php'),
(723, '::1', 'root', '2017-03-24 21:48:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''73'')', '/smm/sysadmin/role_permissions.php'),
(724, '::1', 'root', '2017-03-24 21:48:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''77'')', '/smm/sysadmin/role_permissions.php'),
(725, '::1', 'root', '2017-03-24 21:48:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''16'')', '/smm/sysadmin/role_permissions.php'),
(726, '::1', 'root', '2017-03-24 21:48:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''28'')', '/smm/sysadmin/role_permissions.php'),
(727, '::1', 'root', '2017-03-24 21:48:28', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''8'')', '/smm/sysadmin/role_permissions.php'),
(728, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''20'')', '/smm/sysadmin/role_permissions.php'),
(729, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''24'')', '/smm/sysadmin/role_permissions.php'),
(730, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''12'')', '/smm/sysadmin/role_permissions.php'),
(731, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''81'')', '/smm/sysadmin/role_permissions.php'),
(732, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''35'')', '/smm/sysadmin/role_permissions.php'),
(733, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''51'')', '/smm/sysadmin/role_permissions.php'),
(734, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''36'')', '/smm/sysadmin/role_permissions.php'),
(735, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''52'')', '/smm/sysadmin/role_permissions.php'),
(736, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''89'')', '/smm/sysadmin/role_permissions.php'),
(737, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''93'')', '/smm/sysadmin/role_permissions.php'),
(738, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''56'')', '/smm/sysadmin/role_permissions.php'),
(739, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''60'')', '/smm/sysadmin/role_permissions.php'),
(740, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''64'')', '/smm/sysadmin/role_permissions.php'),
(741, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''97'')', '/smm/sysadmin/role_permissions.php'),
(742, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''101'')', '/smm/sysadmin/role_permissions.php'),
(743, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''7'')', '/smm/sysadmin/role_permissions.php'),
(744, '::1', 'root', '2017-03-24 21:48:29', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''76'')', '/smm/sysadmin/role_permissions.php'),
(745, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''80'')', '/smm/sysadmin/role_permissions.php'),
(746, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''19'')', '/smm/sysadmin/role_permissions.php'),
(747, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''31'')', '/smm/sysadmin/role_permissions.php'),
(748, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''11'')', '/smm/sysadmin/role_permissions.php'),
(749, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''23'')', '/smm/sysadmin/role_permissions.php'),
(750, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''27'')', '/smm/sysadmin/role_permissions.php'),
(751, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''15'')', '/smm/sysadmin/role_permissions.php'),
(752, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''88'')', '/smm/sysadmin/role_permissions.php'),
(753, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''92'')', '/smm/sysadmin/role_permissions.php'),
(754, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''55'')', '/smm/sysadmin/role_permissions.php'),
(755, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''34'')', '/smm/sysadmin/role_permissions.php'),
(756, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''87'')', '/smm/sysadmin/role_permissions.php'),
(757, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''91'')', '/smm/sysadmin/role_permissions.php'),
(758, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''54'')', '/smm/sysadmin/role_permissions.php'),
(759, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''58'')', '/smm/sysadmin/role_permissions.php'),
(760, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''62'')', '/smm/sysadmin/role_permissions.php'),
(761, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''95'')', '/smm/sysadmin/role_permissions.php'),
(762, '::1', 'root', '2017-03-24 21:48:30', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''99'')', '/smm/sysadmin/role_permissions.php'),
(763, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''5'')', '/smm/sysadmin/role_permissions.php'),
(764, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''74'')', '/smm/sysadmin/role_permissions.php'),
(765, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''78'')', '/smm/sysadmin/role_permissions.php'),
(766, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''17'')', '/smm/sysadmin/role_permissions.php'),
(767, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''29'')', '/smm/sysadmin/role_permissions.php'),
(768, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''9'')', '/smm/sysadmin/role_permissions.php'),
(769, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''21'')', '/smm/sysadmin/role_permissions.php'),
(770, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''25'')', '/smm/sysadmin/role_permissions.php'),
(771, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''13'')', '/smm/sysadmin/role_permissions.php'),
(772, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''82'')', '/smm/sysadmin/role_permissions.php'),
(773, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''59'')', '/smm/sysadmin/role_permissions.php'),
(774, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''63'')', '/smm/sysadmin/role_permissions.php'),
(775, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''96'')', '/smm/sysadmin/role_permissions.php'),
(776, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''100'')', '/smm/sysadmin/role_permissions.php'),
(777, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''1'')', '/smm/sysadmin/role_permissions.php'),
(778, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''6'')', '/smm/sysadmin/role_permissions.php'),
(779, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''75'')', '/smm/sysadmin/role_permissions.php'),
(780, '::1', 'root', '2017-03-24 21:48:31', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''79'')', '/smm/sysadmin/role_permissions.php'),
(781, '::1', 'root', '2017-03-24 21:48:32', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''85'')', '/smm/sysadmin/role_permissions.php'),
(782, '::1', 'root', '2017-03-24 21:48:32', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''32'')', '/smm/sysadmin/role_permissions.php'),
(783, '::1', 'root', '2017-03-24 21:48:32', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''84'')', '/smm/sysadmin/role_permissions.php'),
(784, '::1', 'root', '2017-03-24 21:48:32', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''3'')', '/smm/sysadmin/role_permissions.php'),
(785, '::1', 'root', '2017-03-24 21:48:32', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''2'')', '/smm/sysadmin/role_permissions.php'),
(786, '::1', 'root', '2017-03-24 21:48:32', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''18'')', '/smm/sysadmin/role_permissions.php'),
(787, '::1', 'root', '2017-03-24 21:48:32', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''30'')', '/smm/sysadmin/role_permissions.php'),
(788, '::1', 'root', '2017-03-24 21:48:32', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''10'')', '/smm/sysadmin/role_permissions.php'),
(789, '::1', 'root', '2017-03-24 21:48:32', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''22'')', '/smm/sysadmin/role_permissions.php'),
(790, '::1', 'root', '2017-03-24 21:48:32', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''26'')', '/smm/sysadmin/role_permissions.php'),
(791, '::1', 'root', '2017-03-24 21:48:32', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''14'')', '/smm/sysadmin/role_permissions.php'),
(792, '::1', 'root', '2017-03-24 21:48:32', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''83'')', '/smm/sysadmin/role_permissions.php'),
(793, '::1', 'root', '2017-03-24 21:49:36', 'Query executed: DELETE FROM user_passport WHERE username IN (''root'')', '/smm/sysadmin/role_permissions_cascade.php'),
(794, '::1', 'root', '2017-03-24 21:49:36', 'Query executed: INSERT `user_passport` SELECT ''root'', `link_id` FROM user_role_links WHERE role_id=''1''', '/smm/sysadmin/role_permissions_cascade.php'),
(795, '::1', 'root', '2017-03-24 21:49:37', 'Pressed cancel button', '/smm/sysadmin/role_permissions_cascade.php'),
(796, '::1', 'root', '2017-03-24 21:58:14', 'Query executed: DELETE FROM user_role_links WHERE role_id=''1''', '/smm/sysadmin/role_permissions.php'),
(797, '::1', 'root', '2017-03-24 21:58:14', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''33'')', '/smm/sysadmin/role_permissions.php'),
(798, '::1', 'root', '2017-03-24 21:58:14', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''86'')', '/smm/sysadmin/role_permissions.php'),
(799, '::1', 'root', '2017-03-24 21:58:14', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''102'')', '/smm/sysadmin/role_permissions.php'),
(800, '::1', 'root', '2017-03-24 21:58:14', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''53'')', '/smm/sysadmin/role_permissions.php'),
(801, '::1', 'root', '2017-03-24 21:58:14', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''57'')', '/smm/sysadmin/role_permissions.php'),
(802, '::1', 'root', '2017-03-24 21:58:14', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''61'')', '/smm/sysadmin/role_permissions.php'),
(803, '::1', 'root', '2017-03-24 21:58:14', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''94'')', '/smm/sysadmin/role_permissions.php'),
(804, '::1', 'root', '2017-03-24 21:58:14', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''98'')', '/smm/sysadmin/role_permissions.php'),
(805, '::1', 'root', '2017-03-24 21:58:14', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''4'')', '/smm/sysadmin/role_permissions.php'),
(806, '::1', 'root', '2017-03-24 21:58:14', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''73'')', '/smm/sysadmin/role_permissions.php'),
(807, '::1', 'root', '2017-03-24 21:58:14', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''77'')', '/smm/sysadmin/role_permissions.php'),
(808, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''16'')', '/smm/sysadmin/role_permissions.php'),
(809, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''28'')', '/smm/sysadmin/role_permissions.php'),
(810, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''8'')', '/smm/sysadmin/role_permissions.php'),
(811, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''20'')', '/smm/sysadmin/role_permissions.php'),
(812, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''24'')', '/smm/sysadmin/role_permissions.php'),
(813, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''12'')', '/smm/sysadmin/role_permissions.php'),
(814, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''81'')', '/smm/sysadmin/role_permissions.php'),
(815, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''35'')', '/smm/sysadmin/role_permissions.php'),
(816, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''36'')', '/smm/sysadmin/role_permissions.php'),
(817, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''89'')', '/smm/sysadmin/role_permissions.php'),
(818, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''105'')', '/smm/sysadmin/role_permissions.php'),
(819, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''56'')', '/smm/sysadmin/role_permissions.php'),
(820, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''60'')', '/smm/sysadmin/role_permissions.php'),
(821, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''64'')', '/smm/sysadmin/role_permissions.php'),
(822, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''97'')', '/smm/sysadmin/role_permissions.php'),
(823, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''101'')', '/smm/sysadmin/role_permissions.php'),
(824, '::1', 'root', '2017-03-24 21:58:15', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''7'')', '/smm/sysadmin/role_permissions.php'),
(825, '::1', 'root', '2017-03-24 21:58:16', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''76'')', '/smm/sysadmin/role_permissions.php'),
(826, '::1', 'root', '2017-03-24 21:58:16', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''80'')', '/smm/sysadmin/role_permissions.php'),
(827, '::1', 'root', '2017-03-24 21:58:16', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''19'')', '/smm/sysadmin/role_permissions.php'),
(828, '::1', 'root', '2017-03-24 21:58:16', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''31'')', '/smm/sysadmin/role_permissions.php'),
(829, '::1', 'root', '2017-03-24 21:58:16', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''11'')', '/smm/sysadmin/role_permissions.php'),
(830, '::1', 'root', '2017-03-24 21:58:16', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''23'')', '/smm/sysadmin/role_permissions.php'),
(831, '::1', 'root', '2017-03-24 21:58:16', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''27'')', '/smm/sysadmin/role_permissions.php'),
(832, '::1', 'root', '2017-03-24 21:58:16', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''15'')', '/smm/sysadmin/role_permissions.php'),
(833, '::1', 'root', '2017-03-24 21:58:16', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''88'')', '/smm/sysadmin/role_permissions.php'),
(834, '::1', 'root', '2017-03-24 21:58:16', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''104'')', '/smm/sysadmin/role_permissions.php'),
(835, '::1', 'root', '2017-03-24 21:58:16', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''55'')', '/smm/sysadmin/role_permissions.php'),
(836, '::1', 'root', '2017-03-24 21:58:16', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''34'')', '/smm/sysadmin/role_permissions.php'),
(837, '::1', 'root', '2017-03-24 21:58:16', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''87'')', '/smm/sysadmin/role_permissions.php'),
(838, '::1', 'root', '2017-03-24 21:58:16', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''103'')', '/smm/sysadmin/role_permissions.php'),
(839, '::1', 'root', '2017-03-24 21:58:16', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''54'')', '/smm/sysadmin/role_permissions.php'),
(840, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''58'')', '/smm/sysadmin/role_permissions.php'),
(841, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''62'')', '/smm/sysadmin/role_permissions.php'),
(842, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''95'')', '/smm/sysadmin/role_permissions.php'),
(843, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''99'')', '/smm/sysadmin/role_permissions.php'),
(844, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''5'')', '/smm/sysadmin/role_permissions.php'),
(845, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''74'')', '/smm/sysadmin/role_permissions.php'),
(846, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''78'')', '/smm/sysadmin/role_permissions.php'),
(847, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''17'')', '/smm/sysadmin/role_permissions.php'),
(848, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''29'')', '/smm/sysadmin/role_permissions.php'),
(849, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''9'')', '/smm/sysadmin/role_permissions.php'),
(850, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''21'')', '/smm/sysadmin/role_permissions.php'),
(851, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''25'')', '/smm/sysadmin/role_permissions.php'),
(852, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''13'')', '/smm/sysadmin/role_permissions.php'),
(853, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''82'')', '/smm/sysadmin/role_permissions.php'),
(854, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''59'')', '/smm/sysadmin/role_permissions.php'),
(855, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''63'')', '/smm/sysadmin/role_permissions.php'),
(856, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''96'')', '/smm/sysadmin/role_permissions.php'),
(857, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''100'')', '/smm/sysadmin/role_permissions.php'),
(858, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''1'')', '/smm/sysadmin/role_permissions.php'),
(859, '::1', 'root', '2017-03-24 21:58:17', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''6'')', '/smm/sysadmin/role_permissions.php'),
(860, '::1', 'root', '2017-03-24 21:58:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''75'')', '/smm/sysadmin/role_permissions.php'),
(861, '::1', 'root', '2017-03-24 21:58:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''79'')', '/smm/sysadmin/role_permissions.php'),
(862, '::1', 'root', '2017-03-24 21:58:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''85'')', '/smm/sysadmin/role_permissions.php'),
(863, '::1', 'root', '2017-03-24 21:58:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''32'')', '/smm/sysadmin/role_permissions.php'),
(864, '::1', 'root', '2017-03-24 21:58:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''84'')', '/smm/sysadmin/role_permissions.php'),
(865, '::1', 'root', '2017-03-24 21:58:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''3'')', '/smm/sysadmin/role_permissions.php'),
(866, '::1', 'root', '2017-03-24 21:58:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''2'')', '/smm/sysadmin/role_permissions.php'),
(867, '::1', 'root', '2017-03-24 21:58:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''18'')', '/smm/sysadmin/role_permissions.php'),
(868, '::1', 'root', '2017-03-24 21:58:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''30'')', '/smm/sysadmin/role_permissions.php'),
(869, '::1', 'root', '2017-03-24 21:58:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''10'')', '/smm/sysadmin/role_permissions.php'),
(870, '::1', 'root', '2017-03-24 21:58:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''22'')', '/smm/sysadmin/role_permissions.php'),
(871, '::1', 'root', '2017-03-24 21:58:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''26'')', '/smm/sysadmin/role_permissions.php'),
(872, '::1', 'root', '2017-03-24 21:58:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''14'')', '/smm/sysadmin/role_permissions.php'),
(873, '::1', 'root', '2017-03-24 21:58:18', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''83'')', '/smm/sysadmin/role_permissions.php'),
(874, '::1', 'root', '2017-03-24 21:58:39', 'Query executed: DELETE FROM user_passport WHERE username IN (''root'')', '/smm/sysadmin/role_permissions_cascade.php'),
(875, '::1', 'root', '2017-03-24 21:58:39', 'Query executed: INSERT `user_passport` SELECT ''root'', `link_id` FROM user_role_links WHERE role_id=''1''', '/smm/sysadmin/role_permissions_cascade.php'),
(876, '::1', 'root', '2017-03-24 21:58:41', 'Pressed cancel button', '/smm/sysadmin/role_permissions_cascade.php'),
(877, '::1', 'root', '2017-03-27 15:57:37', 'Logged in', '/smm/login.php'),
(878, '::1', 'root', '2017-03-27 17:19:01', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(879, '::1', 'root', '2017-03-29 07:58:00', 'Logged in', '/smm/login.php'),
(880, '::1', 'root', '2017-03-29 08:20:43', 'Query executed: SELECT `name` FROM `equipment` WHERE `name` = brand', '/smm/modules/reports/report_brand_type.php'),
(881, '::1', 'root', '2017-03-29 08:25:00', 'Query executed: SELECT `brand` FROM `equipment` WHERE `brand` = "ASUS"', '/smm/modules/reports/report_brand_type.php'),
(882, '::1', 'root', '2017-03-29 08:26:05', 'Query executed: SELECT `brand` FROM `equipment` WHERE `brand` = "asus"', '/smm/modules/reports/report_brand_type.php'),
(883, '::1', 'root', '2017-03-29 13:10:26', 'Logged in', '/smm/login.php'),
(884, '::1', 'root', '2017-03-29 13:14:49', 'Query executed: SELECT `brand` FROM `equipment` WHERE `brand` ="ASUS"', '/smm/modules/reports/report_brand_type.php'),
(885, '::1', 'root', '2017-03-29 13:15:20', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="ASUS"', '/smm/modules/reports/report_brand_type.php'),
(886, '::1', 'root', '2017-03-29 13:18:34', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="ASUS"', '/smm/modules/reports/report_brand_type.php'),
(887, '::1', 'root', '2017-03-29 13:18:37', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(888, '::1', 'root', '2017-03-29 13:18:38', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(889, '::1', 'root', '2017-03-29 13:18:43', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(890, '::1', 'root', '2017-03-29 13:18:44', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(891, '::1', 'root', '2017-03-29 13:18:44', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(892, '::1', 'root', '2017-03-29 13:19:12', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="ASUS"', '/smm/modules/reports/report_brand_type.php'),
(893, '::1', 'root', '2017-03-30 06:05:50', 'Logged in', '/smm/login.php'),
(894, '::1', 'root', '2017-03-30 06:05:59', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="ASUS"', '/smm/modules/reports/report_brand_type.php'),
(895, '::1', 'root', '2017-03-30 06:06:17', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="ASUS"', '/smm/modules/reports/report_brand_type.php'),
(896, '::1', 'root', '2017-03-30 06:10:08', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(897, '::1', 'root', '2017-03-30 06:10:19', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="WALIS"', '/smm/modules/reports/report_brand_type.php'),
(898, '::1', 'root', '2017-03-30 06:10:21', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(899, '::1', 'root', '2017-03-30 06:10:45', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="Asus"', '/smm/modules/reports/report_brand_type.php'),
(900, '::1', 'root', '2017-03-30 06:10:47', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(901, '::1', 'root', '2017-03-30 06:11:46', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(902, '::1', 'root', '2017-03-30 06:11:47', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(903, '::1', 'root', '2017-03-30 06:11:47', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(904, '::1', 'root', '2017-03-30 06:11:47', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(905, '::1', 'root', '2017-03-30 06:11:48', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(906, '::1', 'root', '2017-03-30 15:35:52', 'Logged in', '/smm/login.php'),
(907, '::1', 'root', '2017-03-30 15:36:10', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="ASUS"', '/smm/modules/reports/report_brand_type.php'),
(908, '::1', 'root', '2017-03-30 15:36:13', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(909, '::1', 'root', '2017-03-30 15:36:27', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="ksjsjsk"', '/smm/modules/reports/report_brand_type.php'),
(910, '::1', 'root', '2017-03-30 15:36:31', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(911, '::1', 'root', '2017-03-30 15:36:46', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(912, '::1', 'root', '2017-03-30 15:40:08', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="BAGUIO"', '/smm/modules/reports/report_brand_type.php'),
(913, '::1', 'root', '2017-03-30 15:46:18', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(914, '::1', 'root', '2017-03-30 15:46:21', 'Query executed: SELECT * FROM `equipment` WHERE `type` =""', '/smm/modules/reports/report_type_type.php'),
(915, '::1', 'root', '2017-03-30 15:46:25', 'Query executed: SELECT * FROM `equipment` WHERE `type` =""', '/smm/modules/reports/report_type_type.php'),
(916, '::1', 'root', '2017-03-30 15:46:26', 'Query executed: SELECT * FROM `equipment` WHERE `type` =""', '/smm/modules/reports/report_type_type.php'),
(917, '::1', 'root', '2017-03-30 16:07:18', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(918, '::1', 'root', '2017-03-30 16:08:19', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(919, '::1', 'root', '2017-03-30 16:08:38', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="ASUS"', '/smm/modules/reports/report_brand_type.php'),
(920, '::1', 'root', '2017-03-30 16:12:01', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(921, '::1', 'root', '2017-03-30 16:12:52', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(922, '::1', 'root', '2017-03-30 16:13:25', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="BAGUIO"', '/smm/modules/reports/report_brand_type.php'),
(923, '::1', 'root', '2017-03-30 16:13:42', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(924, '::1', 'root', '2017-03-30 16:13:46', 'Query executed: SELECT * FROM `equipment` WHERE `type` =""', '/smm/modules/reports/report_type_type.php'),
(925, '::1', 'root', '2017-03-30 16:13:49', 'Query executed: SELECT * FROM `equipment` WHERE `type` =""', '/smm/modules/reports/report_type_type.php'),
(926, '::1', 'root', '2017-03-30 16:13:50', 'Query executed: SELECT * FROM `equipment` WHERE `type` =""', '/smm/modules/reports/report_type_type.php'),
(927, '::1', 'root', '2017-03-30 16:13:50', 'Query executed: SELECT * FROM `equipment` WHERE `type` =""', '/smm/modules/reports/report_type_type.php'),
(928, '::1', 'root', '2017-03-30 16:13:51', 'Query executed: SELECT * FROM `equipment` WHERE `type` =""', '/smm/modules/reports/report_type_type.php'),
(929, '::1', 'root', '2017-03-30 16:13:52', 'Query executed: SELECT * FROM `equipment` WHERE `type` =""', '/smm/modules/reports/report_type_type.php'),
(930, '::1', 'root', '2017-03-30 16:14:10', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(931, '::1', 'root', '2017-03-30 16:14:12', 'Query executed: SELECT * FROM `equipment` WHERE `type` =""', '/smm/modules/reports/report_type_type.php'),
(932, '::1', 'root', '2017-03-30 16:14:57', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="ASUS"', '/smm/modules/reports/report_brand_type.php'),
(933, '::1', 'root', '2017-03-30 16:15:02', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(934, '::1', 'root', '2017-03-30 16:19:02', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(935, '::1', 'root', '2017-03-30 16:19:03', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(936, '::1', 'root', '2017-03-30 16:19:38', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="BAGUIO"', '/smm/modules/reports/report_brand_type.php'),
(937, '::1', 'root', '2017-03-30 16:19:41', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(938, '::1', 'root', '2017-03-30 16:26:06', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="BAGUIO"', '/smm/modules/reports/report_brand_type.php'),
(939, '::1', 'root', '2017-03-30 16:26:08', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(940, '::1', 'root', '2017-03-30 16:26:23', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="BAGUIO"', '/smm/modules/reports/report_brand_type.php'),
(941, '::1', 'root', '2017-03-30 16:26:44', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="BAGUIO"', '/smm/modules/reports/report_brand_type.php'),
(942, '::1', 'root', '2017-03-30 16:27:31', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(943, '::1', 'root', '2017-03-30 16:27:33', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(944, '::1', 'root', '2017-03-30 16:27:40', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="BAGUIO"', '/smm/modules/reports/report_brand_type.php'),
(945, '::1', 'root', '2017-03-30 16:27:40', 'Query executed: SELECT * FROM `equipment` WHERE `brand` =""', '/smm/modules/reports/report_brand_type.php'),
(946, '::1', 'root', '2017-03-30 16:29:15', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="BAGUIO"', '/smm/modules/reports/report_brand_type.php'),
(947, '::1', 'root', '2017-03-30 16:34:06', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="BAGUIO"', '/smm/modules/reports/report_brand_type.php'),
(948, '::1', 'root', '2017-03-30 16:34:39', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="BAGUIO"', '/smm/modules/reports/report_brand_type.php'),
(949, '::1', 'root', '2017-03-30 16:34:59', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(950, '::1', 'root', '2017-03-30 16:37:35', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(951, '::1', 'root', '2017-03-30 16:37:37', 'Query executed: SELECT * FROM `equipment` WHERE `type` =""', '/smm/modules/reports/report_type_type.php'),
(952, '::1', 'root', '2017-03-30 16:39:16', 'Query executed: SELECT * FROM `equipment` WHERE `type` =""', '/smm/modules/reports/report_type_type.php'),
(953, '::1', 'root', '2017-03-30 16:41:42', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(954, '::1', 'root', '2017-03-30 16:42:57', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(955, '::1', 'root', '2017-03-30 16:44:14', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(956, '::1', 'root', '2017-03-30 16:45:02', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(957, '::1', 'root', '2017-03-30 16:46:01', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(958, '::1', 'root', '2017-03-30 16:46:14', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(959, '::1', 'root', '2017-03-30 16:46:32', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(960, '::1', 'root', '2017-03-30 16:47:10', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(961, '::1', 'root', '2017-03-30 16:47:23', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(962, '::1', 'root', '2017-03-30 16:49:17', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(963, '::1', 'root', '2017-03-30 16:49:48', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(964, '::1', 'root', '2017-03-30 16:50:05', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(965, '::1', 'root', '2017-03-30 16:50:15', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(966, '::1', 'root', '2017-03-30 16:50:44', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(967, '::1', 'root', '2017-03-30 16:50:53', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(968, '::1', 'root', '2017-03-30 16:51:17', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(969, '::1', 'root', '2017-03-30 16:51:27', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(970, '::1', 'root', '2017-03-30 16:51:39', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(971, '::1', 'root', '2017-03-30 17:04:46', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="BAGUIO"', '/smm/modules/reports/report_brand_type.php'),
(972, '::1', 'root', '2017-03-30 17:15:46', 'Logged in', '/smm/login.php'),
(973, '::1', 'root', '2017-03-30 17:16:54', 'Pressed cancel button', '/smm/modules/equipment/deploy_equipment/add_deploy_equipment.php'),
(974, '::1', 'root', '2017-03-30 17:17:02', 'Pressed cancel button', '/smm/modules/equipment/deploy_equipment/add_deploy_equipment.php'),
(975, '::1', 'root', '2017-04-03 14:53:27', 'Logged in', '/smm/login.php'),
(976, '::1', 'root', '2017-04-03 14:53:39', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(977, '::1', 'root', '2017-04-03 14:55:05', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(978, '::1', 'root', '2017-04-03 14:55:06', 'Query executed: SELECT * FROM `equipment` WHERE `type` =""', '/smm/modules/reports/report_type_type.php'),
(979, '::1', 'root', '2017-04-03 14:55:08', 'Query executed: SELECT * FROM `equipment` WHERE `type` =""', '/smm/modules/reports/report_type_type.php'),
(980, '::1', 'root', '2017-04-03 14:55:17', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="Elephant"', '/smm/modules/reports/report_brand_type.php'),
(981, '::1', 'root', '2017-04-03 14:58:26', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(982, '::1', 'root', '2017-04-03 14:58:35', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="Elephant"', '/smm/modules/reports/report_brand_type.php'),
(983, '::1', 'root', '2017-04-03 15:04:29', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(984, '::1', 'root', '2017-04-03 15:17:14', 'Query executed: SELECT * FROM `equipment` WHERE `price` ="40"', '/smm/modules/reports/report_price_type.php'),
(985, '::1', 'root', '2017-04-03 15:18:14', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="10"', '/smm/modules/reports/report_price_type.php'),
(986, '::1', 'root', '2017-04-03 15:18:36', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="120"', '/smm/modules/reports/report_price_type.php'),
(987, '::1', 'root', '2017-04-03 15:23:09', 'Pressed cancel button', '/smm/modules/equipment/disposal/add_disposal.php'),
(988, '::1', 'root', '2017-04-03 15:23:30', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="140000"', '/smm/modules/reports/report_price_type.php'),
(989, '::1', 'root', '2017-04-03 15:24:19', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="Elephant"', '/smm/modules/reports/report_brand_type.php'),
(990, '::1', 'root', '2017-04-03 15:41:06', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="1600"', '/smm/modules/reports/report_price_type.php'),
(991, '::1', 'root', '2017-04-03 15:41:19', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(992, '::1', 'root', '2017-04-03 15:43:39', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="Elephant"', '/smm/modules/reports/report_brand_type.php'),
(993, '::1', 'root', '2017-04-03 15:43:49', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(994, '::1', 'root', '2017-04-03 15:45:02', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(995, '::1', 'root', '2017-04-03 15:47:50', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="Elephant"', '/smm/modules/reports/report_brand_type.php'),
(996, '::1', 'root', '2017-04-03 15:47:59', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(997, '::1', 'root', '2017-04-03 15:48:21', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(998, '::1', 'root', '2017-04-03 15:48:32', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="Elephant"', '/smm/modules/reports/report_brand_type.php'),
(999, '::1', 'root', '2017-04-03 15:48:52', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="10"', '/smm/modules/reports/report_price_type.php'),
(1000, '::1', 'root', '2017-04-03 16:05:59', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="50"', '/smm/modules/reports/report_price_type.php'),
(1001, '::1', 'root', '2017-04-03 16:06:06', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="10"', '/smm/modules/reports/report_price_type.php'),
(1002, '::1', 'root', '2017-04-03 16:06:36', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="56"', '/smm/modules/reports/report_price_type.php'),
(1003, '::1', 'root', '2017-04-03 16:06:48', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Laptop"', '/smm/modules/reports/report_type_type.php'),
(1004, '::1', 'root', '2017-04-04 09:30:01', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="10"', '/smm/modules/reports/report_price_type.php'),
(1005, '::1', 'root', '2017-04-05 08:41:57', 'Logged in', '/smm/login.php'),
(1006, '::1', 'root', '2017-04-05 08:42:23', 'Pressed submit button', '/smm/modules/equipment/equipment/add_equipment.php'),
(1007, '::1', 'root', '2017-04-05 08:42:23', 'Query Executed: INSERT INTO equipment(id, name, type, brand, description, function, price, rating) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => isssssdi\n    [1] => \n    [2] => asd\n    [3] => Mouse\n    [4] => BAN\n    [5] => X\n    [6] => C\n    [7] => 850\n    [8] => 10\n)\n', '/smm/modules/equipment/equipment/add_equipment.php'),
(1008, '::1', 'root', '2017-04-05 09:56:14', 'Logged in', '/smm/login.php'),
(1009, '::1', 'root', '2017-04-05 09:56:32', 'Pressed cancel button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1010, '::1', 'root', '2017-04-05 10:18:30', 'Query executed: SELECT * FROM `employee`', '/smm/modules/reports/sample.php'),
(1011, '::1', 'root', '2017-04-05 10:20:08', 'Pressed cancel button', '/smm/modules/maintenance/maintenance_document/add_maintenance_document.php'),
(1012, '::1', 'root', '2017-04-05 10:24:35', 'Pressed submit button', '/smm/modules/maintenance/maintenance/add_maintenance.php'),
(1013, '::1', 'root', '2017-04-05 10:29:04', 'Pressed submit button', '/smm/modules/maintenance/maintenance/add_maintenance.php');
INSERT INTO `system_log` (`entry_id`, `ip_address`, `user`, `datetime`, `action`, `module`) VALUES
(1014, '::1', 'root', '2017-04-05 10:30:01', 'Pressed submit button', '/smm/modules/maintenance/maintenance/add_maintenance.php'),
(1015, '::1', 'root', '2017-04-05 10:33:34', 'Logged in', '/smm/login.php'),
(1016, '::1', 'root', '2017-04-05 10:33:53', 'Pressed submit button', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(1017, '::1', 'root', '2017-04-05 10:34:11', 'Pressed submit button', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(1018, '::1', 'root', '2017-04-05 10:34:30', 'Pressed submit button', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(1019, '::1', 'root', '2017-04-05 10:34:30', 'Query Executed: INSERT INTO purchase_data(id, purchase_date, receive_date, receiver, person, location, contact, equiment_id) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssssi\n    [1] => \n    [2] => 2017-04-05\n    [3] => 2017-04-05\n    [4] => X\n    [5] => X\n    [6] => X\n    [7] => 0129391203\n    [8] => 2\n)\n', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(1020, '::1', 'root', '2017-04-05 10:34:30', 'Query Executed: INSERT INTO purchase_data_document(id, document, remarks, purchase_data_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => issi\n    [1] => \n    [2] => 187c995f6a056a2bf544ff5d0306ec2e3cd94dfeAFFIDAVIT-stripiceGULLE.doc\n    [3] => X\n    [4] => 3\n)\n', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(1021, '::1', 'root', '2017-04-05 10:40:02', 'Pressed submit button', '/smm/modules/maintenance/maintenance/add_maintenance.php'),
(1022, '::1', 'root', '2017-04-05 10:44:22', 'Pressed submit button', '/smm/modules/maintenance/maintenance/add_maintenance.php'),
(1023, '::1', 'root', '2017-04-05 10:46:26', 'Pressed submit button', '/smm/modules/maintenance/maintenance/add_maintenance.php'),
(1024, '::1', 'root', '2017-04-05 10:52:24', 'Pressed submit button', '/smm/modules/maintenance/maintenance/add_maintenance.php'),
(1025, '::1', 'root', '2017-04-05 10:52:25', 'Query Executed: INSERT INTO maintenance(id, type, start_date, end_date, time, state, reason, status, service_provider, cost, equipment_id, employee_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssssssdii\n    [1] => \n    [2] => Corrective\n    [3] => 2017-04-05\n    [4] => 2017-04-05\n    [5] => 5:30\n    [6] => Functional\n    [7] => X\n    [8] => No progress\n    [9] => a\n    [10] => 59\n    [11] => 4\n    [12] => 1\n)\n', '/smm/modules/maintenance/maintenance/add_maintenance.php'),
(1026, '::1', 'root', '2017-04-05 10:52:25', 'Query Executed: INSERT INTO maintenance_document(id, document, remarks, maintenance_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => issi\n    [1] => \n    [2] => 0eab0169a0e008b14f0d79e77a8b670cb5d71ea5Install.txt\n    [3] => x\n    [4] => 3\n)\n', '/smm/modules/maintenance/maintenance/add_maintenance.php'),
(1027, '::1', 'root', '2017-04-05 10:54:05', 'Pressed submit button', '/smm/modules/maintenance/maintenance/add_maintenance.php'),
(1028, '::1', 'root', '2017-04-05 10:54:06', 'Query Executed: INSERT INTO maintenance(id, type, start_date, end_date, time, state, reason, status, service_provider, cost, equipment_id, employee_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssssssdii\n    [1] => \n    [2] => Preventive\n    [3] => 2017-04-05\n    [4] => 2017-04-05\n    [5] => 5:30\n    [6] => Functional\n    [7] => A\n    [8] => No progress\n    [9] => X\n    [10] => 46\n    [11] => 4\n    [12] => 1\n)\n', '/smm/modules/maintenance/maintenance/add_maintenance.php'),
(1029, '::1', 'root', '2017-04-05 10:54:06', 'Query Executed: INSERT INTO maintenance_document(id, document, remarks, maintenance_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => issi\n    [1] => \n    [2] => a9b63503af308cfaedf21152beda097c5e6f296b00- Introduction and Character Information.pdf\n    [3] => S\n    [4] => 4\n)\n', '/smm/modules/maintenance/maintenance/add_maintenance.php'),
(1030, '::1', 'root', '2017-04-05 11:12:59', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1031, '::1', 'root', '2017-04-05 11:12:59', 'Query executed: SELECT `deploy_id` FROM `deploy_equipment` WHERE `equipment_id` ="2"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1032, '::1', 'root', '2017-04-05 11:30:45', 'Logged in', '/smm/login.php'),
(1033, '::1', 'root', '2017-04-05 11:35:06', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1034, '::1', 'root', '2017-04-05 11:35:06', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="2"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1035, '::1', 'root', '2017-04-05 11:35:58', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1036, '::1', 'root', '2017-04-05 11:35:58', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="1"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1037, '::1', 'root', '2017-04-05 11:36:45', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1038, '::1', 'root', '2017-04-05 11:36:45', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="1"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1039, '::1', 'root', '2017-04-05 11:37:21', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1040, '::1', 'root', '2017-04-05 11:37:21', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="1"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1041, '::1', 'root', '2017-04-05 11:42:46', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1042, '::1', 'root', '2017-04-05 11:43:26', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1043, '::1', 'root', '2017-04-05 11:43:27', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="1"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1044, '::1', 'root', '2017-04-05 11:43:27', 'Query Executed: INSERT INTO disposal(id, method, remarks, remove_date, dispose_date, days, equipment_id, deploy_id) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssiii\n    [1] => \n    [2] => A\n    [3] => A\n    [4] => 2017-04-05\n    [5] => 2017-04-05\n    [6] => \n    [7] => 3\n    [8] => 1\n)\n', '/smm/modules/equipment/disposal/add_disposal.php'),
(1045, '::1', 'root', '2017-04-05 11:45:36', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1046, '::1', 'root', '2017-04-05 11:45:36', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="1"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1047, '::1', 'root', '2017-04-05 11:45:36', 'Query Executed: INSERT INTO disposal(id, method, remarks, remove_date, dispose_date, days, equipment_id, deploy_id) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssiii\n    [1] => \n    [2] => DSA\n    [3] => DAS\n    [4] => 2017-04-05\n    [5] => 2017-04-05\n    [6] => 1\n    [7] => 2\n    [8] => 1\n)\n', '/smm/modules/equipment/disposal/add_disposal.php'),
(1048, '::1', 'root', '2017-04-05 16:03:32', 'Logged in', '/smm/login.php'),
(1049, '::1', 'root', '2017-04-05 16:06:16', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1050, '::1', 'root', '2017-04-05 16:06:16', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="1"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1051, '::1', 'root', '2017-04-05 16:06:16', 'Query Executed: INSERT INTO disposal(id, method, remarks, remove_date, dispose_date, days, equipment_id, deploy_id) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssiii\n    [1] => \n    [2] => ASD\n    [3] => ASDA\n    [4] => 2017-04-05\n    [5] => 2017-04-05\n    [6] => \n    [7] => 2\n    [8] => 1\n)\n', '/smm/modules/equipment/disposal/add_disposal.php'),
(1052, '::1', 'root', '2017-04-05 16:09:29', 'Pressed delete button', '/smm/modules/equipment/disposal/delete_disposal.php'),
(1053, '::1', 'root', '2017-04-05 16:09:30', 'Query Executed: DELETE FROM disposal WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 6\n)\n', '/smm/modules/equipment/disposal/delete_disposal.php'),
(1054, '::1', 'root', '2017-04-05 16:09:33', 'Pressed delete button', '/smm/modules/equipment/disposal/delete_disposal.php'),
(1055, '::1', 'root', '2017-04-05 16:09:33', 'Query Executed: DELETE FROM disposal WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 5\n)\n', '/smm/modules/equipment/disposal/delete_disposal.php'),
(1056, '::1', 'root', '2017-04-05 16:09:43', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1057, '::1', 'root', '2017-04-05 16:09:43', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="2"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1058, '::1', 'root', '2017-04-05 16:15:06', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1059, '::1', 'root', '2017-04-05 16:15:06', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="1"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1060, '::1', 'root', '2017-04-05 16:15:29', 'Pressed submit button', '/smm/modules/equipment/disposal/edit_disposal.php'),
(1061, '::1', 'root', '2017-04-05 16:15:30', 'Query Executed: UPDATE disposal SET method = ?, remarks = ?, remove_date = ?, dispose_date = ?, days = ?, equipment_id = ?, deploy_id = ? WHERE id = ?\r\nArray\n(\n    [0] => ssssiiii\n    [1] => A\n    [2] => A\n    [3] => 2017-04-05\n    [4] => 2017-04-05\n    [5] => 0\n    [6] => 3\n    [7] => 1\n    [8] => 4\n)\n', '/smm/modules/equipment/disposal/edit_disposal.php'),
(1062, '::1', 'root', '2017-04-05 16:15:39', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1063, '::1', 'root', '2017-04-05 16:15:39', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="2"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1064, '::1', 'root', '2017-04-05 16:18:08', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1065, '::1', 'root', '2017-04-05 16:18:08', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="2"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1066, '::1', 'root', '2017-04-05 16:21:35', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1067, '::1', 'root', '2017-04-05 16:21:35', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="1"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1068, '::1', 'root', '2017-04-05 16:23:20', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1069, '::1', 'root', '2017-04-05 16:23:20', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="1"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1070, '::1', 'root', '2017-04-05 16:25:29', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1071, '::1', 'root', '2017-04-05 16:25:29', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="1"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1072, '::1', 'root', '2017-04-05 16:28:12', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1073, '::1', 'root', '2017-04-05 16:28:12', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="1"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1074, '::1', 'root', '2017-04-05 16:29:10', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1075, '::1', 'root', '2017-04-05 16:29:10', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="1"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1076, '::1', 'root', '2017-04-05 16:31:10', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1077, '::1', 'root', '2017-04-05 16:31:10', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="1"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1078, '::1', 'root', '2017-04-05 16:33:56', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1079, '::1', 'root', '2017-04-05 16:33:56', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="2"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1080, '::1', 'root', '2017-04-05 16:33:56', 'Query Executed: INSERT INTO disposal(id, method, remarks, remove_date, dispose_date, days, equipment_id, deploy_id) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssiii\n    [1] => \n    [2] => S\n    [3] => A\n    [4] => 2017-04-05\n    [5] => 2017-04-05\n    [6] => 1.1574074074074E-5\n    [7] => 2\n    [8] => 2\n)\n', '/smm/modules/equipment/disposal/add_disposal.php'),
(1081, '::1', 'root', '2017-04-05 16:34:44', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1082, '::1', 'root', '2017-04-05 16:34:44', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="1"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1083, '::1', 'root', '2017-04-05 16:34:44', 'Query Executed: INSERT INTO disposal(id, method, remarks, remove_date, dispose_date, days, equipment_id, deploy_id) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssiii\n    [1] => \n    [2] => S\n    [3] => A\n    [4] => 2017-04-05\n    [5] => 2017-04-05\n    [6] => 1.1574074074074E-5\n    [7] => 1\n    [8] => 1\n)\n', '/smm/modules/equipment/disposal/add_disposal.php'),
(1084, '::1', 'root', '2017-04-05 16:35:52', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1085, '::1', 'root', '2017-04-05 16:35:52', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="1"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1086, '::1', 'root', '2017-04-05 17:49:20', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1087, '::1', 'root', '2017-04-05 17:49:20', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="2"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1088, '::1', 'root', '2017-04-05 18:17:13', 'Pressed submit button', '/smm/modules/equipment/equipment/add_equipment.php'),
(1089, '::1', 'root', '2017-04-05 18:17:14', 'Query Executed: INSERT INTO equipment(id, name, type, brand, description, function, price, rating) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => isssssdi\n    [1] => \n    [2] => WALIS\n    [3] => broom\n    [4] => BAGUIOIO\n    [5] => X\n    [6] => To sweep dust\n    [7] => 100\n    [8] => 5\n)\n', '/smm/modules/equipment/equipment/add_equipment.php'),
(1090, '::1', 'root', '2017-04-05 18:18:23', 'Pressed submit button', '/smm/modules/equipment/equipment/add_equipment.php'),
(1091, '::1', 'root', '2017-04-05 18:18:23', 'Query Executed: INSERT INTO equipment(id, name, type, brand, description, function, price, rating) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => isssssdi\n    [1] => \n    [2] => Kingston FAKE\n    [3] => USB\n    [4] => Kingston\n    [5] => X\n    [6] => X\n    [7] => 100\n    [8] => 6\n)\n', '/smm/modules/equipment/equipment/add_equipment.php'),
(1092, '::1', 'root', '2017-04-05 20:58:40', 'Logged in', '/smm/login.php'),
(1093, '::1', 'root', '2017-04-05 20:59:21', 'Pressed cancel button', '/smm/sysadmin/delete_user_links.php'),
(1094, '::1', 'root', '2017-04-05 20:59:26', 'Pressed delete button', '/smm/sysadmin/delete_user_links.php'),
(1095, '::1', 'root', '2017-04-05 20:59:26', 'Query Executed: DELETE FROM user_links WHERE link_id = ?\r\nArray\n(\n    [0] => i\n    [1] => 84\n)\n', '/smm/sysadmin/delete_user_links.php'),
(1096, '::1', 'root', '2017-04-05 20:59:42', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(1097, '::1', 'root', '2017-04-05 20:59:42', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add maintenance\n    [2] => modules/maintenance/maintenance/add_maintenance.php\n    [3] => Add Maintenance\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 94\n)\n', '/smm/sysadmin/edit_user_links.php'),
(1098, '::1', 'root', '2017-04-05 20:59:55', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(1099, '::1', 'root', '2017-04-05 20:59:55', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit maintenance\n    [2] => modules/maintenance/maintenance/edit_maintenance.php\n    [3] => Edit Maintenance\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 95\n)\n', '/smm/sysadmin/edit_user_links.php'),
(1100, '::1', 'root', '2017-04-05 21:00:14', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(1101, '::1', 'root', '2017-04-05 21:00:14', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View maintenance\n    [2] => modules/maintenance/maintenance/listview_maintenance.php\n    [3] => Maintenance\n    [4] => \n    [5] => 5\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 96\n)\n', '/smm/sysadmin/edit_user_links.php'),
(1102, '::1', 'root', '2017-04-05 21:00:26', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(1103, '::1', 'root', '2017-04-05 21:00:26', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete maintenance\n    [2] => modules/maintenance/maintenance/delete_maintenance.php\n    [3] => Delete Maintenance\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 97\n)\n', '/smm/sysadmin/edit_user_links.php'),
(1104, '::1', 'root', '2017-04-05 21:00:37', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(1105, '::1', 'root', '2017-04-05 21:00:38', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Add maintenance document\n    [2] => modules/maintenance/maintenance_document/add_maintenance_document.php\n    [3] => Add Maintenance Document\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 98\n)\n', '/smm/sysadmin/edit_user_links.php'),
(1106, '::1', 'root', '2017-04-05 21:00:55', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(1107, '::1', 'root', '2017-04-05 21:00:56', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Edit maintenance document\n    [2] => modules/maintenance/maintenance_document/edit_maintenance_document.php\n    [3] => Edit Maintenance Document\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 99\n)\n', '/smm/sysadmin/edit_user_links.php'),
(1108, '::1', 'root', '2017-04-05 21:01:04', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(1109, '::1', 'root', '2017-04-05 21:01:05', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => View maintenance document\n    [2] => modules/maintenance/maintenance_document/listview_maintenance_document.php\n    [3] => Maintenance Document\n    [4] => \n    [5] => 5\n    [6] => Yes\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 100\n)\n', '/smm/sysadmin/edit_user_links.php'),
(1110, '::1', 'root', '2017-04-05 21:01:13', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(1111, '::1', 'root', '2017-04-05 21:01:13', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete maintenance document\n    [2] => modules/maintenance/maintenance_document/delete_maintenance_document.php\n    [3] => Delete Maintenance Document\n    [4] => \n    [5] => 5\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 0\n    [10] => 101\n)\n', '/smm/sysadmin/edit_user_links.php'),
(1112, '::1', 'root', '2017-04-06 02:33:21', 'Pressed submit button', '/smm/modules/equipment/equipment/add_equipment.php'),
(1113, '::1', 'root', '2017-04-06 02:33:21', 'Query Executed: INSERT INTO equipment(id, name, type, brand, description, function, price, rating) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => isssssdi\n    [1] => \n    [2] => ASKDO\n    [3] => Keyboard\n    [4] => ASKOO\n    [5] => Typing\n    [6] => Typing\n    [7] => 860\n    [8] => 9\n)\n', '/smm/modules/equipment/equipment/add_equipment.php'),
(1114, '::1', 'root', '2017-04-06 02:39:23', 'Pressed submit button', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(1115, '::1', 'root', '2017-04-06 02:39:23', 'Query Executed: INSERT INTO purchase_data(id, purchase_date, receive_date, receiver, person, location, contact, equiment_id) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssssi\n    [1] => \n    [2] => 2017-04-06\n    [3] => 2017-04-06\n    [4] => Jojo Castillo\n    [5] => Octagon\n    [6] => X\n    [7] => 0129391203\n    [8] => 7\n)\n', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(1116, '::1', 'root', '2017-04-06 02:39:23', 'Query Executed: INSERT INTO purchase_data_document(id, document, remarks, purchase_data_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => issi\n    [1] => \n    [2] => 0dbf8b2776d0bc44b67e7937dd32cf37c2822723AFFIDAVIT-stripiceGULLE.doc\n    [3] => AS\n    [4] => 4\n)\n', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(1117, '::1', 'root', '2017-04-06 02:44:51', 'Pressed submit button', '/smm/modules/equipment/warranty/add_warranty.php'),
(1118, '::1', 'root', '2017-04-06 02:44:51', 'Query Executed: INSERT INTO warranty(id, start_date, end_date, assigned, copy, purchase_id, equipment_id) VALUES(?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssii\n    [1] => \n    [2] => 2017-04-06\n    [3] => 2017-04-06\n    [4] => JOJO\n    [5] => 6338fdb967ef2fa5818948e2d134ce9accf9e871AFFIDAVIT-stripiceGULLE.doc\n    [6] => 4\n    [7] => 7\n)\n', '/smm/modules/equipment/warranty/add_warranty.php'),
(1119, '::1', 'root', '2017-04-06 02:54:25', 'Pressed cancel button', '/smm/modules/equipment/deploy_equipment/add_deploy_equipment.php'),
(1120, '::1', 'root', '2017-04-06 02:55:36', 'Pressed submit button', '/smm/modules/equipment/deploy_equipment/add_deploy_equipment.php'),
(1121, '::1', 'root', '2017-04-06 02:55:37', 'Query Executed: INSERT INTO deploy_equipment(id, equipment_id, deploy_id) VALUES(?,?,?)\r\nArray\n(\n    [0] => iii\n    [1] => \n    [2] => 4\n    [3] => 2\n)\n', '/smm/modules/equipment/deploy_equipment/add_deploy_equipment.php'),
(1122, '::1', 'root', '2017-04-06 02:56:43', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(1123, '::1', 'root', '2017-04-06 02:58:13', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Mouse"', '/smm/modules/reports/report_type_type.php'),
(1124, '::1', 'root', '2017-04-06 02:58:37', 'Query executed: SELECT * FROM `equipment` WHERE `type` ="Broom"', '/smm/modules/reports/report_type_type.php'),
(1125, '::1', 'root', '2017-04-06 02:58:50', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="BAGUIO"', '/smm/modules/reports/report_brand_type.php'),
(1126, '::1', 'root', '2017-04-06 02:59:12', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="90"', '/smm/modules/reports/report_price_type.php'),
(1127, '::1', 'root', '2017-04-06 03:01:18', 'Pressed cancel button', '/smm/modules/maintenance/maintenance_document/add_maintenance_document.php'),
(1128, '::1', 'root', '2017-04-06 08:42:20', 'Logged in', '/smm/login.php'),
(1129, '::1', 'root', '2017-04-06 08:59:04', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="100"', '/smm/modules/reports/report_price_type.php'),
(1130, '::1', 'root', '2017-04-06 09:02:26', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="100" ORDER BY `price` DESC ', '/smm/modules/reports/report_price_type.php'),
(1131, '::1', 'root', '2017-04-06 09:02:53', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="199" ORDER BY `price` ASC ', '/smm/modules/reports/report_price_type.php'),
(1132, '::1', 'root', '2017-04-06 12:41:10', 'Logged in', '/smm/login.php'),
(1133, '::1', 'root', '2017-04-06 14:37:41', 'Logged in', '/smm/login.php'),
(1134, '::1', 'root', '2017-04-06 14:38:54', 'Query executed: SELECT * FROM `equipment` WHERE `rating` >="10" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1135, '::1', 'root', '2017-04-06 14:41:11', 'Query executed: SELECT * FROM `equipment` WHERE `rating` >="10" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1136, '::1', 'root', '2017-04-06 14:41:36', 'Query executed: SELECT * FROM `equipment` WHERE `rating` >="1" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1137, '::1', 'root', '2017-04-06 15:01:19', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1138, '::1', 'root', '2017-04-06 15:01:19', 'Query executed: SELECT `deployDate` FROM `deploy` WHERE `id` ="1"', '/smm/modules/equipment/disposal/add_disposal.php'),
(1139, '::1', 'root', '2017-04-06 15:02:56', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1140, '::1', 'root', '2017-04-06 15:08:10', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="BAGUIO"', '/smm/modules/reports/report_brand_type.php'),
(1141, '::1', 'root', '2017-04-06 16:31:27', 'Logged in', '/smm/login.php'),
(1142, '::1', 'root', '2017-04-06 16:32:13', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="10" ORDER BY `price` ASC ', '/smm/modules/reports/report_price_type.php'),
(1143, '::1', 'root', '2017-04-06 16:32:56', 'Query executed: SELECT * FROM `equipment` WHERE `brand` ="Kingston"', '/smm/modules/reports/report_brand_type.php'),
(1144, '::1', 'root', '2017-04-06 16:34:02', 'Query executed: SELECT * FROM `equipment` WHERE `rating` >="4" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1145, '::1', 'root', '2017-04-06 16:34:54', 'Pressed submit button', '/smm/modules/equipment/equipment/add_equipment.php'),
(1146, '::1', 'root', '2017-04-06 16:34:55', 'Query Executed: INSERT INTO equipment(id, name, type, brand, description, function, price, rating) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => isssssdi\n    [1] => \n    [2] => DELL N4050\n    [3] => Laptop\n    [4] => DELL\n    [5] => Laptop\n    [6] => X\n    [7] => 24500\n    [8] => 7.5\n)\n', '/smm/modules/equipment/equipment/add_equipment.php'),
(1147, '::1', 'root', '2017-04-06 16:35:48', 'Pressed submit button', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(1148, '::1', 'root', '2017-04-06 16:35:49', 'Query Executed: INSERT INTO purchase_data(id, purchase_date, receive_date, receiver, person, location, contact, equiment_id) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssssi\n    [1] => \n    [2] => 2017-04-06\n    [3] => 2017-04-07\n    [4] => Adrian Tobias\n    [5] => OCTAGON\n    [6] => MOA\n    [7] => 0909090090\n    [8] => 8\n)\n', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(1149, '::1', 'root', '2017-04-06 16:35:49', 'Query Executed: INSERT INTO purchase_data_document(id, document, remarks, purchase_data_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => issi\n    [1] => \n    [2] => 268f40a6948c8e334c1d99adba731d7a239fdc63DFD 2.jpg\n    [3] => OR for Laptop\n    [4] => 5\n)\n', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(1150, '::1', 'root', '2017-04-06 16:36:16', 'Pressed submit button', '/smm/modules/equipment/warranty/add_warranty.php'),
(1151, '::1', 'root', '2017-04-06 16:36:23', 'Pressed submit button', '/smm/modules/equipment/warranty/add_warranty.php'),
(1152, '::1', 'root', '2017-04-06 16:36:23', 'Query Executed: INSERT INTO warranty(id, start_date, end_date, assigned, copy, purchase_id, equipment_id) VALUES(?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssii\n    [1] => \n    [2] => 2017-04-06\n    [3] => 2018-04-06\n    [4] => Adrian Tobias\n    [5] => 147c83fc992bd85c56ec3fd04926b0b7fcb80540A - 1.PNG\n    [6] => 5\n    [7] => 8\n)\n', '/smm/modules/equipment/warranty/add_warranty.php'),
(1153, '::1', 'root', '2017-04-06 16:36:53', 'Pressed submit button', '/smm/modules/equipment/deploy_equipment/add_deploy_equipment.php'),
(1154, '::1', 'root', '2017-04-06 16:36:53', 'Query Executed: INSERT INTO deploy_equipment(id, equipment_id, deploy_id) VALUES(?,?,?)\r\nArray\n(\n    [0] => iii\n    [1] => \n    [2] => 8\n    [3] => 2\n)\n', '/smm/modules/equipment/deploy_equipment/add_deploy_equipment.php'),
(1155, '::1', 'root', '2017-04-06 16:39:52', 'Pressed submit button', '/smm/modules/maintenance/maintenance/add_maintenance.php'),
(1156, '::1', 'root', '2017-04-09 08:52:40', 'Logged in', '/smm/login.php'),
(1157, '::1', 'root', '2017-04-09 08:52:51', 'Query executed: SELECT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy_equipment`.`deploy_id` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` WHERE `rating` >="1" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1158, '::1', 'root', '2017-04-09 08:53:33', 'Query executed: SELECT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy_equipment`.`deploy_id` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` WHERE `rating` >="4" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1159, '::1', 'root', '2017-04-09 08:53:53', 'Query executed: SELECT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy_equipment`.`deploy_id` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` WHERE `rating` >="10" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1160, '::1', 'root', '2017-04-09 08:55:20', 'Query executed: SELECT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy_equipment`.`deploy_id` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` WHERE `rating` >="1" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1161, '::1', 'root', '2017-04-09 08:55:50', 'Pressed submit button', '/smm/modules/equipment/deploy_equipment/add_deploy_equipment.php'),
(1162, '::1', 'root', '2017-04-09 08:55:51', 'Query Executed: INSERT INTO deploy_equipment(id, equipment_id, deploy_id) VALUES(?,?,?)\r\nArray\n(\n    [0] => iii\n    [1] => \n    [2] => 8\n    [3] => 1\n)\n', '/smm/modules/equipment/deploy_equipment/add_deploy_equipment.php'),
(1163, '::1', 'root', '2017-04-09 08:56:03', 'Query executed: SELECT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy_equipment`.`deploy_id` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` WHERE `rating` >="1" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1164, '::1', 'root', '2017-04-09 08:56:31', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy_equipment`.`deploy_id` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` WHERE `rating` >="1" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1165, '::1', 'root', '2017-04-09 08:59:40', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy`.`deployDate` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` WHERE `rating` >="1" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1166, '::1', 'root', '2017-04-09 09:02:06', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` WHERE `rating` >="1" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1167, '::1', 'root', '2017-04-09 09:02:39', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1168, '::1', 'root', '2017-04-09 09:02:56', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1169, '::1', 'root', '2017-04-09 09:03:13', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` WHERE `rating` >="1" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1170, '::1', 'root', '2017-04-09 09:03:46', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1171, '::1', 'root', '2017-04-09 09:03:50', 'Pressed delete button', '/smm/modules/equipment/disposal/delete_disposal.php'),
(1172, '::1', 'root', '2017-04-09 09:03:51', 'Query Executed: DELETE FROM disposal WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 4\n)\n', '/smm/modules/equipment/disposal/delete_disposal.php'),
(1173, '::1', 'root', '2017-04-09 09:03:54', 'Pressed delete button', '/smm/modules/equipment/disposal/delete_disposal.php'),
(1174, '::1', 'root', '2017-04-09 09:03:54', 'Query Executed: DELETE FROM disposal WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 3\n)\n', '/smm/modules/equipment/disposal/delete_disposal.php'),
(1175, '::1', 'root', '2017-04-09 09:03:57', 'Pressed delete button', '/smm/modules/equipment/disposal/delete_disposal.php'),
(1176, '::1', 'root', '2017-04-09 09:03:57', 'Query Executed: DELETE FROM disposal WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 2\n)\n', '/smm/modules/equipment/disposal/delete_disposal.php'),
(1177, '::1', 'root', '2017-04-09 09:04:02', 'Pressed delete button', '/smm/modules/equipment/disposal/delete_disposal.php'),
(1178, '::1', 'root', '2017-04-09 09:04:03', 'Query Executed: DELETE FROM disposal WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 1\n)\n', '/smm/modules/equipment/disposal/delete_disposal.php'),
(1179, '::1', 'root', '2017-04-09 09:04:19', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1180, '::1', 'root', '2017-04-09 09:05:05', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1181, '::1', 'root', '2017-04-09 09:05:05', 'Query Executed: INSERT INTO disposal(id, method, remarks, remove_date, dispose_date, days, equipment_id, deploy_id) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssiii\n    [1] => \n    [2] => ALSNDLKn\n    [3] => LKNASLKDN\n    [4] => 2017-04-09\n    [5] => 2017-04-09\n    [6] => \n    [7] => 5\n    [8] => 1\n)\n', '/smm/modules/equipment/disposal/add_disposal.php'),
(1182, '::1', 'root', '2017-04-09 09:05:13', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` WHERE `rating` >="1" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1183, '::1', 'root', '2017-04-09 09:18:12', 'Pressed delete button', '/smm/modules/equipment/disposal/delete_disposal.php'),
(1184, '::1', 'root', '2017-04-09 09:18:12', 'Query Executed: DELETE FROM disposal WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 5\n)\n', '/smm/modules/equipment/disposal/delete_disposal.php'),
(1185, '::1', 'root', '2017-04-09 09:18:20', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` WHERE `rating` >="1" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1186, '::1', 'root', '2017-04-09 09:25:47', 'Pressed cancel button', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1187, '::1', 'root', '2017-04-09 09:30:02', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `deploy`.`id` = `disposal`.`deploy_id` WHERE `rating` >="1" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1188, '::1', 'root', '2017-04-09 09:31:24', 'Pressed submit button', '/smm/modules/equipment/equipment/add_equipment.php'),
(1189, '::1', 'root', '2017-04-09 09:31:24', 'Query Executed: INSERT INTO equipment(id, name, type, brand, description, function, price, rating) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => isssssdi\n    [1] => \n    [2] => ADATA C008\n    [3] => USB\n    [4] => ADATA\n    [5] => USB\n    [6] => STORING FILES\n    [7] => 670\n    [8] => 8\n)\n', '/smm/modules/equipment/equipment/add_equipment.php'),
(1190, '::1', 'root', '2017-04-09 09:31:39', 'Pressed submit button', '/smm/modules/equipment/deploy_equipment/add_deploy_equipment.php'),
(1191, '::1', 'root', '2017-04-09 09:31:39', 'Query Executed: INSERT INTO deploy_equipment(id, equipment_id, deploy_id) VALUES(?,?,?)\r\nArray\n(\n    [0] => iii\n    [1] => \n    [2] => 9\n    [3] => 1\n)\n', '/smm/modules/equipment/deploy_equipment/add_deploy_equipment.php'),
(1192, '::1', 'root', '2017-04-09 09:32:22', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1193, '::1', 'root', '2017-04-09 09:32:22', 'Query Executed: INSERT INTO disposal(id, method, remarks, remove_date, dispose_date, days, equipment_id, deploy_id) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssiii\n    [1] => \n    [2] => X\n    [3] => X\n    [4] => 2017-04-09\n    [5] => 2017-04-09\n    [6] => \n    [7] => 9\n    [8] => 1\n)\n', '/smm/modules/equipment/disposal/add_disposal.php'),
(1194, '::1', 'root', '2017-04-09 09:32:39', 'Query executed: SELECT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `deploy`.`id` = `disposal`.`deploy_id` WHERE `rating` >="1" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1195, '::1', 'root', '2017-04-09 09:33:56', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `deploy`.`id` = `disposal`.`equipment_id` WHERE `rating` >="1" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1196, '::1', 'root', '2017-04-09 09:34:30', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` WHERE `rating` >="1" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1197, '::1', 'root', '2017-04-09 09:35:00', 'Pressed delete button', '/smm/modules/equipment/disposal/delete_disposal.php'),
(1198, '::1', 'root', '2017-04-09 09:35:00', 'Query Executed: DELETE FROM disposal WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 6\n)\n', '/smm/modules/equipment/disposal/delete_disposal.php'),
(1199, '::1', 'root', '2017-04-09 09:35:05', 'Pressed delete button', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1200, '::1', 'root', '2017-04-09 09:35:13', 'Pressed delete button', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1201, '::1', 'root', '2017-04-09 09:35:13', 'Query Executed: DELETE FROM purchase_data_document WHERE purchase_data_id = ?\r\nArray\n(\n    [0] => i\n    [1] => \n)\n', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1202, '::1', 'root', '2017-04-09 09:35:14', 'Query Executed: DELETE FROM purchase_data WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 1\n)\n', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1203, '::1', 'root', '2017-04-09 09:35:17', 'Pressed delete button', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1204, '::1', 'root', '2017-04-09 09:35:18', 'Query Executed: DELETE FROM purchase_data_document WHERE purchase_data_id = ?\r\nArray\n(\n    [0] => i\n    [1] => \n)\n', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1205, '::1', 'root', '2017-04-09 09:35:18', 'Query Executed: DELETE FROM purchase_data WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 2\n)\n', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1206, '::1', 'root', '2017-04-09 09:35:22', 'Pressed delete button', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1207, '::1', 'root', '2017-04-09 09:35:22', 'Query Executed: DELETE FROM purchase_data_document WHERE purchase_data_id = ?\r\nArray\n(\n    [0] => i\n    [1] => \n)\n', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1208, '::1', 'root', '2017-04-09 09:35:22', 'Query Executed: DELETE FROM purchase_data WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 3\n)\n', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1209, '::1', 'root', '2017-04-09 09:35:26', 'Pressed delete button', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1210, '::1', 'root', '2017-04-09 09:35:26', 'Query Executed: DELETE FROM purchase_data_document WHERE purchase_data_id = ?\r\nArray\n(\n    [0] => i\n    [1] => \n)\n', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1211, '::1', 'root', '2017-04-09 09:35:32', 'Pressed delete button', '/smm/modules/equipment/purchase_data_document/delete_purchase_data_document.php'),
(1212, '::1', 'root', '2017-04-09 09:35:32', 'Query Executed: DELETE FROM purchase_data_document WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 1\n)\n', '/smm/modules/equipment/purchase_data_document/delete_purchase_data_document.php'),
(1213, '::1', 'root', '2017-04-09 09:35:35', 'Pressed delete button', '/smm/modules/equipment/purchase_data_document/delete_purchase_data_document.php'),
(1214, '::1', 'root', '2017-04-09 09:35:35', 'Query Executed: DELETE FROM purchase_data_document WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 2\n)\n', '/smm/modules/equipment/purchase_data_document/delete_purchase_data_document.php'),
(1215, '::1', 'root', '2017-04-09 09:35:37', 'Pressed delete button', '/smm/modules/equipment/purchase_data_document/delete_purchase_data_document.php'),
(1216, '::1', 'root', '2017-04-09 09:35:37', 'Query Executed: DELETE FROM purchase_data_document WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 3\n)\n', '/smm/modules/equipment/purchase_data_document/delete_purchase_data_document.php'),
(1217, '::1', 'root', '2017-04-09 09:35:39', 'Pressed delete button', '/smm/modules/equipment/purchase_data_document/delete_purchase_data_document.php'),
(1218, '::1', 'root', '2017-04-09 09:35:40', 'Query Executed: DELETE FROM purchase_data_document WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 4\n)\n', '/smm/modules/equipment/purchase_data_document/delete_purchase_data_document.php'),
(1219, '::1', 'root', '2017-04-09 09:35:43', 'Pressed delete button', '/smm/modules/equipment/purchase_data_document/delete_purchase_data_document.php'),
(1220, '::1', 'root', '2017-04-09 09:35:43', 'Query Executed: DELETE FROM purchase_data_document WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 5\n)\n', '/smm/modules/equipment/purchase_data_document/delete_purchase_data_document.php'),
(1221, '::1', 'root', '2017-04-09 09:35:45', 'Pressed delete button', '/smm/modules/equipment/purchase_data_document/delete_purchase_data_document.php'),
(1222, '::1', 'root', '2017-04-09 09:35:45', 'Query Executed: DELETE FROM purchase_data_document WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 6\n)\n', '/smm/modules/equipment/purchase_data_document/delete_purchase_data_document.php'),
(1223, '::1', 'root', '2017-04-09 09:35:49', 'Pressed delete button', '/smm/modules/equipment/purchase_data_document/delete_purchase_data_document.php'),
(1224, '::1', 'root', '2017-04-09 09:35:49', 'Query Executed: DELETE FROM purchase_data_document WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 7\n)\n', '/smm/modules/equipment/purchase_data_document/delete_purchase_data_document.php'),
(1225, '::1', 'root', '2017-04-09 09:38:13', 'Pressed submit button', '/smm/sysadmin/add_user_links.php'),
(1226, '::1', 'root', '2017-04-09 09:38:13', 'Query Executed: INSERT INTO user_links(link_id, name, target, descriptive_title, description, passport_group_id, show_in_tasklist, status, icon, priority) VALUES(?,?,?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssisssi\n    [1] => \n    [2] => Delete warranty\n    [3] => modules/equipment/warranty/delete_warranty.php\n    [4] => Delete Warranty\n    [5] => X\n    [6] => 3\n    [7] => Yes\n    [8] => On\n    [9] => form3.png\n    [10] => 1\n)\n', '/smm/sysadmin/add_user_links.php'),
(1227, '::1', 'root', '2017-04-09 09:38:33', 'Query executed: DELETE FROM user_role_links WHERE role_id=''1''', '/smm/sysadmin/role_permissions.php'),
(1228, '::1', 'root', '2017-04-09 09:38:33', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''33'')', '/smm/sysadmin/role_permissions.php'),
(1229, '::1', 'root', '2017-04-09 09:38:33', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''86'')', '/smm/sysadmin/role_permissions.php'),
(1230, '::1', 'root', '2017-04-09 09:38:33', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''102'')', '/smm/sysadmin/role_permissions.php'),
(1231, '::1', 'root', '2017-04-09 09:38:33', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''53'')', '/smm/sysadmin/role_permissions.php'),
(1232, '::1', 'root', '2017-04-09 09:38:33', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''57'')', '/smm/sysadmin/role_permissions.php'),
(1233, '::1', 'root', '2017-04-09 09:38:33', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''61'')', '/smm/sysadmin/role_permissions.php'),
(1234, '::1', 'root', '2017-04-09 09:38:33', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''94'')', '/smm/sysadmin/role_permissions.php'),
(1235, '::1', 'root', '2017-04-09 09:38:34', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''98'')', '/smm/sysadmin/role_permissions.php'),
(1236, '::1', 'root', '2017-04-09 09:38:34', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''4'')', '/smm/sysadmin/role_permissions.php'),
(1237, '::1', 'root', '2017-04-09 09:38:34', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''73'')', '/smm/sysadmin/role_permissions.php'),
(1238, '::1', 'root', '2017-04-09 09:38:34', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''77'')', '/smm/sysadmin/role_permissions.php'),
(1239, '::1', 'root', '2017-04-09 09:38:34', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''16'')', '/smm/sysadmin/role_permissions.php'),
(1240, '::1', 'root', '2017-04-09 09:38:34', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''28'')', '/smm/sysadmin/role_permissions.php'),
(1241, '::1', 'root', '2017-04-09 09:38:34', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''8'')', '/smm/sysadmin/role_permissions.php'),
(1242, '::1', 'root', '2017-04-09 09:38:34', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''20'')', '/smm/sysadmin/role_permissions.php'),
(1243, '::1', 'root', '2017-04-09 09:38:34', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''24'')', '/smm/sysadmin/role_permissions.php');
INSERT INTO `system_log` (`entry_id`, `ip_address`, `user`, `datetime`, `action`, `module`) VALUES
(1244, '::1', 'root', '2017-04-09 09:38:34', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''12'')', '/smm/sysadmin/role_permissions.php'),
(1245, '::1', 'root', '2017-04-09 09:38:35', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''81'')', '/smm/sysadmin/role_permissions.php'),
(1246, '::1', 'root', '2017-04-09 09:38:35', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''35'')', '/smm/sysadmin/role_permissions.php'),
(1247, '::1', 'root', '2017-04-09 09:38:35', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''36'')', '/smm/sysadmin/role_permissions.php'),
(1248, '::1', 'root', '2017-04-09 09:38:35', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''89'')', '/smm/sysadmin/role_permissions.php'),
(1249, '::1', 'root', '2017-04-09 09:38:35', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''105'')', '/smm/sysadmin/role_permissions.php'),
(1250, '::1', 'root', '2017-04-09 09:38:35', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''56'')', '/smm/sysadmin/role_permissions.php'),
(1251, '::1', 'root', '2017-04-09 09:38:35', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''60'')', '/smm/sysadmin/role_permissions.php'),
(1252, '::1', 'root', '2017-04-09 09:38:35', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''64'')', '/smm/sysadmin/role_permissions.php'),
(1253, '::1', 'root', '2017-04-09 09:38:35', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''97'')', '/smm/sysadmin/role_permissions.php'),
(1254, '::1', 'root', '2017-04-09 09:38:35', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''101'')', '/smm/sysadmin/role_permissions.php'),
(1255, '::1', 'root', '2017-04-09 09:38:35', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''7'')', '/smm/sysadmin/role_permissions.php'),
(1256, '::1', 'root', '2017-04-09 09:38:36', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''76'')', '/smm/sysadmin/role_permissions.php'),
(1257, '::1', 'root', '2017-04-09 09:38:36', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''80'')', '/smm/sysadmin/role_permissions.php'),
(1258, '::1', 'root', '2017-04-09 09:38:36', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''19'')', '/smm/sysadmin/role_permissions.php'),
(1259, '::1', 'root', '2017-04-09 09:38:36', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''31'')', '/smm/sysadmin/role_permissions.php'),
(1260, '::1', 'root', '2017-04-09 09:38:36', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''11'')', '/smm/sysadmin/role_permissions.php'),
(1261, '::1', 'root', '2017-04-09 09:38:36', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''23'')', '/smm/sysadmin/role_permissions.php'),
(1262, '::1', 'root', '2017-04-09 09:38:36', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''27'')', '/smm/sysadmin/role_permissions.php'),
(1263, '::1', 'root', '2017-04-09 09:38:36', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''15'')', '/smm/sysadmin/role_permissions.php'),
(1264, '::1', 'root', '2017-04-09 09:38:36', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''106'')', '/smm/sysadmin/role_permissions.php'),
(1265, '::1', 'root', '2017-04-09 09:38:36', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''88'')', '/smm/sysadmin/role_permissions.php'),
(1266, '::1', 'root', '2017-04-09 09:38:37', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''104'')', '/smm/sysadmin/role_permissions.php'),
(1267, '::1', 'root', '2017-04-09 09:38:37', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''55'')', '/smm/sysadmin/role_permissions.php'),
(1268, '::1', 'root', '2017-04-09 09:38:37', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''34'')', '/smm/sysadmin/role_permissions.php'),
(1269, '::1', 'root', '2017-04-09 09:38:37', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''87'')', '/smm/sysadmin/role_permissions.php'),
(1270, '::1', 'root', '2017-04-09 09:38:37', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''103'')', '/smm/sysadmin/role_permissions.php'),
(1271, '::1', 'root', '2017-04-09 09:38:37', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''54'')', '/smm/sysadmin/role_permissions.php'),
(1272, '::1', 'root', '2017-04-09 09:38:37', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''58'')', '/smm/sysadmin/role_permissions.php'),
(1273, '::1', 'root', '2017-04-09 09:38:37', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''62'')', '/smm/sysadmin/role_permissions.php'),
(1274, '::1', 'root', '2017-04-09 09:38:38', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''95'')', '/smm/sysadmin/role_permissions.php'),
(1275, '::1', 'root', '2017-04-09 09:38:38', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''99'')', '/smm/sysadmin/role_permissions.php'),
(1276, '::1', 'root', '2017-04-09 09:38:38', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''5'')', '/smm/sysadmin/role_permissions.php'),
(1277, '::1', 'root', '2017-04-09 09:38:38', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''74'')', '/smm/sysadmin/role_permissions.php'),
(1278, '::1', 'root', '2017-04-09 09:38:38', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''78'')', '/smm/sysadmin/role_permissions.php'),
(1279, '::1', 'root', '2017-04-09 09:38:38', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''17'')', '/smm/sysadmin/role_permissions.php'),
(1280, '::1', 'root', '2017-04-09 09:38:38', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''29'')', '/smm/sysadmin/role_permissions.php'),
(1281, '::1', 'root', '2017-04-09 09:38:38', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''9'')', '/smm/sysadmin/role_permissions.php'),
(1282, '::1', 'root', '2017-04-09 09:38:38', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''21'')', '/smm/sysadmin/role_permissions.php'),
(1283, '::1', 'root', '2017-04-09 09:38:38', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''25'')', '/smm/sysadmin/role_permissions.php'),
(1284, '::1', 'root', '2017-04-09 09:38:38', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''13'')', '/smm/sysadmin/role_permissions.php'),
(1285, '::1', 'root', '2017-04-09 09:38:38', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''82'')', '/smm/sysadmin/role_permissions.php'),
(1286, '::1', 'root', '2017-04-09 09:38:38', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''59'')', '/smm/sysadmin/role_permissions.php'),
(1287, '::1', 'root', '2017-04-09 09:38:39', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''63'')', '/smm/sysadmin/role_permissions.php'),
(1288, '::1', 'root', '2017-04-09 09:38:39', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''96'')', '/smm/sysadmin/role_permissions.php'),
(1289, '::1', 'root', '2017-04-09 09:38:39', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''100'')', '/smm/sysadmin/role_permissions.php'),
(1290, '::1', 'root', '2017-04-09 09:38:39', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''1'')', '/smm/sysadmin/role_permissions.php'),
(1291, '::1', 'root', '2017-04-09 09:38:39', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''6'')', '/smm/sysadmin/role_permissions.php'),
(1292, '::1', 'root', '2017-04-09 09:38:39', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''75'')', '/smm/sysadmin/role_permissions.php'),
(1293, '::1', 'root', '2017-04-09 09:38:39', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''79'')', '/smm/sysadmin/role_permissions.php'),
(1294, '::1', 'root', '2017-04-09 09:38:39', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''85'')', '/smm/sysadmin/role_permissions.php'),
(1295, '::1', 'root', '2017-04-09 09:38:39', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''32'')', '/smm/sysadmin/role_permissions.php'),
(1296, '::1', 'root', '2017-04-09 09:38:39', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''3'')', '/smm/sysadmin/role_permissions.php'),
(1297, '::1', 'root', '2017-04-09 09:38:39', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''2'')', '/smm/sysadmin/role_permissions.php'),
(1298, '::1', 'root', '2017-04-09 09:38:39', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''18'')', '/smm/sysadmin/role_permissions.php'),
(1299, '::1', 'root', '2017-04-09 09:38:39', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''30'')', '/smm/sysadmin/role_permissions.php'),
(1300, '::1', 'root', '2017-04-09 09:38:40', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''10'')', '/smm/sysadmin/role_permissions.php'),
(1301, '::1', 'root', '2017-04-09 09:38:40', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''22'')', '/smm/sysadmin/role_permissions.php'),
(1302, '::1', 'root', '2017-04-09 09:38:40', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''26'')', '/smm/sysadmin/role_permissions.php'),
(1303, '::1', 'root', '2017-04-09 09:38:40', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''14'')', '/smm/sysadmin/role_permissions.php'),
(1304, '::1', 'root', '2017-04-09 09:38:40', 'Query executed: INSERT INTO user_role_links(role_id, link_id) VALUES(''1'', ''83'')', '/smm/sysadmin/role_permissions.php'),
(1305, '::1', 'root', '2017-04-09 09:38:49', 'Query executed: DELETE FROM user_passport WHERE username IN (''root'')', '/smm/sysadmin/role_permissions_cascade.php'),
(1306, '::1', 'root', '2017-04-09 09:38:49', 'Query executed: INSERT `user_passport` SELECT ''root'', `link_id` FROM user_role_links WHERE role_id=''1''', '/smm/sysadmin/role_permissions_cascade.php'),
(1307, '::1', 'root', '2017-04-09 09:38:51', 'Pressed cancel button', '/smm/sysadmin/role_permissions_cascade.php'),
(1308, '::1', 'root', '2017-04-09 09:39:01', 'Pressed delete button', '/smm/modules/equipment/warranty/delete_warranty.php'),
(1309, '::1', 'root', '2017-04-09 09:39:01', 'Query Executed: DELETE FROM warranty WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 1\n)\n', '/smm/modules/equipment/warranty/delete_warranty.php'),
(1310, '::1', 'root', '2017-04-09 09:39:03', 'Pressed delete button', '/smm/modules/equipment/warranty/delete_warranty.php'),
(1311, '::1', 'root', '2017-04-09 09:39:04', 'Query Executed: DELETE FROM warranty WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 2\n)\n', '/smm/modules/equipment/warranty/delete_warranty.php'),
(1312, '::1', 'root', '2017-04-09 09:39:13', 'Pressed delete button', '/smm/modules/maintenance/maintenance/delete_maintenance.php'),
(1313, '::1', 'root', '2017-04-09 09:39:13', 'Query Executed: DELETE FROM maintenance_document WHERE maintenance_id = ?\r\nArray\n(\n    [0] => i\n    [1] => \n)\n', '/smm/modules/maintenance/maintenance/delete_maintenance.php'),
(1314, '::1', 'root', '2017-04-09 09:39:14', 'Query Executed: DELETE FROM maintenance WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 1\n)\n', '/smm/modules/maintenance/maintenance/delete_maintenance.php'),
(1315, '::1', 'root', '2017-04-09 09:39:17', 'Pressed delete button', '/smm/modules/maintenance/maintenance/delete_maintenance.php'),
(1316, '::1', 'root', '2017-04-09 09:39:17', 'Query Executed: DELETE FROM maintenance_document WHERE maintenance_id = ?\r\nArray\n(\n    [0] => i\n    [1] => \n)\n', '/smm/modules/maintenance/maintenance/delete_maintenance.php'),
(1317, '::1', 'root', '2017-04-09 09:39:18', 'Query Executed: DELETE FROM maintenance WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 2\n)\n', '/smm/modules/maintenance/maintenance/delete_maintenance.php'),
(1318, '::1', 'root', '2017-04-09 09:39:21', 'Pressed delete button', '/smm/modules/maintenance/maintenance/delete_maintenance.php'),
(1319, '::1', 'root', '2017-04-09 09:39:21', 'Query Executed: DELETE FROM maintenance_document WHERE maintenance_id = ?\r\nArray\n(\n    [0] => i\n    [1] => \n)\n', '/smm/modules/maintenance/maintenance/delete_maintenance.php'),
(1320, '::1', 'root', '2017-04-09 09:39:21', 'Query Executed: DELETE FROM maintenance WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 3\n)\n', '/smm/modules/maintenance/maintenance/delete_maintenance.php'),
(1321, '::1', 'root', '2017-04-09 09:39:25', 'Pressed delete button', '/smm/modules/maintenance/maintenance/delete_maintenance.php'),
(1322, '::1', 'root', '2017-04-09 09:39:25', 'Query Executed: DELETE FROM maintenance_document WHERE maintenance_id = ?\r\nArray\n(\n    [0] => i\n    [1] => \n)\n', '/smm/modules/maintenance/maintenance/delete_maintenance.php'),
(1323, '::1', 'root', '2017-04-09 09:39:25', 'Query Executed: DELETE FROM maintenance WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 4\n)\n', '/smm/modules/maintenance/maintenance/delete_maintenance.php'),
(1324, '::1', 'root', '2017-04-09 09:39:37', 'Pressed delete button', '/smm/modules/maintenance/maintenance_document/delete_maintenance_document.php'),
(1325, '::1', 'root', '2017-04-09 09:39:37', 'Query Executed: DELETE FROM maintenance_document WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 1\n)\n', '/smm/modules/maintenance/maintenance_document/delete_maintenance_document.php'),
(1326, '::1', 'root', '2017-04-09 09:39:40', 'Pressed delete button', '/smm/modules/maintenance/maintenance_document/delete_maintenance_document.php'),
(1327, '::1', 'root', '2017-04-09 09:39:40', 'Query Executed: DELETE FROM maintenance_document WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 2\n)\n', '/smm/modules/maintenance/maintenance_document/delete_maintenance_document.php'),
(1328, '::1', 'root', '2017-04-09 09:39:43', 'Pressed delete button', '/smm/modules/maintenance/maintenance_document/delete_maintenance_document.php'),
(1329, '::1', 'root', '2017-04-09 09:39:43', 'Query Executed: DELETE FROM maintenance_document WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 3\n)\n', '/smm/modules/maintenance/maintenance_document/delete_maintenance_document.php'),
(1330, '::1', 'root', '2017-04-09 09:39:46', 'Pressed delete button', '/smm/modules/maintenance/maintenance_document/delete_maintenance_document.php'),
(1331, '::1', 'root', '2017-04-09 09:39:46', 'Query Executed: DELETE FROM maintenance_document WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 4\n)\n', '/smm/modules/maintenance/maintenance_document/delete_maintenance_document.php'),
(1332, '::1', 'root', '2017-04-09 09:39:48', 'Pressed delete button', '/smm/modules/maintenance/maintenance_document/delete_maintenance_document.php'),
(1333, '::1', 'root', '2017-04-09 09:39:48', 'Query Executed: DELETE FROM maintenance_document WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 5\n)\n', '/smm/modules/maintenance/maintenance_document/delete_maintenance_document.php'),
(1334, '::1', 'root', '2017-04-09 09:39:50', 'Pressed delete button', '/smm/modules/maintenance/maintenance_document/delete_maintenance_document.php'),
(1335, '::1', 'root', '2017-04-09 09:39:51', 'Query Executed: DELETE FROM maintenance_document WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 6\n)\n', '/smm/modules/maintenance/maintenance_document/delete_maintenance_document.php'),
(1336, '::1', 'root', '2017-04-09 09:39:53', 'Pressed cancel button', '/smm/modules/maintenance/maintenance_document/delete_maintenance_document.php'),
(1337, '::1', 'root', '2017-04-09 09:39:55', 'Pressed delete button', '/smm/modules/maintenance/maintenance_document/delete_maintenance_document.php'),
(1338, '::1', 'root', '2017-04-09 09:39:55', 'Query Executed: DELETE FROM maintenance_document WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 7\n)\n', '/smm/modules/maintenance/maintenance_document/delete_maintenance_document.php'),
(1339, '::1', 'root', '2017-04-09 09:40:00', 'Pressed delete button', '/smm/modules/equipment/deploy/delete_deploy.php'),
(1340, '::1', 'root', '2017-04-09 09:40:07', 'Pressed delete button', '/smm/modules/equipment/deploy_equipment/delete_deploy_equipment.php'),
(1341, '::1', 'root', '2017-04-09 09:40:07', 'Query Executed: DELETE FROM deploy_equipment WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 1\n)\n', '/smm/modules/equipment/deploy_equipment/delete_deploy_equipment.php'),
(1342, '::1', 'root', '2017-04-09 09:40:10', 'Pressed delete button', '/smm/modules/equipment/deploy_equipment/delete_deploy_equipment.php'),
(1343, '::1', 'root', '2017-04-09 09:40:10', 'Query Executed: DELETE FROM deploy_equipment WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 2\n)\n', '/smm/modules/equipment/deploy_equipment/delete_deploy_equipment.php'),
(1344, '::1', 'root', '2017-04-09 09:40:12', 'Pressed delete button', '/smm/modules/equipment/deploy_equipment/delete_deploy_equipment.php'),
(1345, '::1', 'root', '2017-04-09 09:40:12', 'Query Executed: DELETE FROM deploy_equipment WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 3\n)\n', '/smm/modules/equipment/deploy_equipment/delete_deploy_equipment.php'),
(1346, '::1', 'root', '2017-04-09 09:40:15', 'Pressed delete button', '/smm/modules/equipment/deploy_equipment/delete_deploy_equipment.php'),
(1347, '::1', 'root', '2017-04-09 09:40:15', 'Query Executed: DELETE FROM deploy_equipment WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 4\n)\n', '/smm/modules/equipment/deploy_equipment/delete_deploy_equipment.php'),
(1348, '::1', 'root', '2017-04-09 09:40:17', 'Pressed delete button', '/smm/modules/equipment/deploy_equipment/delete_deploy_equipment.php'),
(1349, '::1', 'root', '2017-04-09 09:40:17', 'Query Executed: DELETE FROM deploy_equipment WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 5\n)\n', '/smm/modules/equipment/deploy_equipment/delete_deploy_equipment.php'),
(1350, '::1', 'root', '2017-04-09 09:40:21', 'Pressed delete button', '/smm/modules/equipment/deploy/delete_deploy.php'),
(1351, '::1', 'root', '2017-04-09 09:40:21', 'Query Executed: DELETE FROM deploy WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 1\n)\n', '/smm/modules/equipment/deploy/delete_deploy.php'),
(1352, '::1', 'root', '2017-04-09 09:40:23', 'Pressed delete button', '/smm/modules/equipment/deploy/delete_deploy.php'),
(1353, '::1', 'root', '2017-04-09 09:40:24', 'Query Executed: DELETE FROM deploy WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 2\n)\n', '/smm/modules/equipment/deploy/delete_deploy.php'),
(1354, '::1', 'root', '2017-04-09 09:40:30', 'Pressed delete button', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1355, '::1', 'root', '2017-04-09 09:40:30', 'Query Executed: DELETE FROM equipment WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 1\n)\n', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1356, '::1', 'root', '2017-04-09 09:40:32', 'Pressed delete button', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1357, '::1', 'root', '2017-04-09 09:40:33', 'Query Executed: DELETE FROM equipment WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 2\n)\n', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1358, '::1', 'root', '2017-04-09 09:40:35', 'Pressed delete button', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1359, '::1', 'root', '2017-04-09 09:40:35', 'Query Executed: DELETE FROM equipment WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 3\n)\n', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1360, '::1', 'root', '2017-04-09 09:40:37', 'Pressed delete button', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1361, '::1', 'root', '2017-04-09 09:40:37', 'Query Executed: DELETE FROM equipment WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 4\n)\n', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1362, '::1', 'root', '2017-04-09 09:40:40', 'Pressed delete button', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1363, '::1', 'root', '2017-04-09 09:40:40', 'Query Executed: DELETE FROM equipment WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 5\n)\n', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1364, '::1', 'root', '2017-04-09 09:40:42', 'Pressed delete button', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1365, '::1', 'root', '2017-04-09 09:40:42', 'Query Executed: DELETE FROM equipment WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 6\n)\n', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1366, '::1', 'root', '2017-04-09 09:40:44', 'Pressed delete button', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1367, '::1', 'root', '2017-04-09 09:40:52', 'Pressed delete button', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1368, '::1', 'root', '2017-04-09 09:40:52', 'Query Executed: DELETE FROM purchase_data_document WHERE purchase_data_id = ?\r\nArray\n(\n    [0] => i\n    [1] => \n)\n', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1369, '::1', 'root', '2017-04-09 09:40:53', 'Query Executed: DELETE FROM purchase_data WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 4\n)\n', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1370, '::1', 'root', '2017-04-09 09:40:57', 'Pressed delete button', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1371, '::1', 'root', '2017-04-09 09:40:57', 'Query Executed: DELETE FROM purchase_data_document WHERE purchase_data_id = ?\r\nArray\n(\n    [0] => i\n    [1] => \n)\n', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1372, '::1', 'root', '2017-04-09 09:40:57', 'Query Executed: DELETE FROM purchase_data WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 5\n)\n', '/smm/modules/equipment/purchase_data/delete_purchase_data.php'),
(1373, '::1', 'root', '2017-04-09 09:41:01', 'Pressed delete button', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1374, '::1', 'root', '2017-04-09 09:41:01', 'Query Executed: DELETE FROM equipment WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 7\n)\n', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1375, '::1', 'root', '2017-04-09 09:41:04', 'Pressed delete button', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1376, '::1', 'root', '2017-04-09 09:41:04', 'Query Executed: DELETE FROM equipment WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 8\n)\n', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1377, '::1', 'root', '2017-04-09 09:41:07', 'Pressed delete button', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1378, '::1', 'root', '2017-04-09 09:41:07', 'Query Executed: DELETE FROM equipment WHERE id = ?\r\nArray\n(\n    [0] => i\n    [1] => 9\n)\n', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1379, '::1', 'root', '2017-04-09 09:43:29', 'Pressed submit button', '/smm/modules/equipment/equipment/add_equipment.php'),
(1380, '::1', 'root', '2017-04-09 09:43:29', 'Query Executed: INSERT INTO equipment(id, name, type, brand, description, function, price, rating) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => isssssdi\n    [1] => \n    [2] => C008\n    [3] => USB\n    [4] => ADATA\n    [5] => X\n    [6] => X\n    [7] => 850\n    [8] => 8\n)\n', '/smm/modules/equipment/equipment/add_equipment.php'),
(1381, '::1', 'root', '2017-04-09 09:44:13', 'Pressed submit button', '/smm/sysadmin/edit_user_links.php'),
(1382, '::1', 'root', '2017-04-09 09:44:13', 'Query Executed: UPDATE user_links SET name = ?, target = ?, descriptive_title = ?, description = ?, passport_group_id = ?, show_in_tasklist = ?, status = ?, icon = ?, priority = ? WHERE link_id = ?\r\nArray\n(\n    [0] => ssssisssii\n    [1] => Delete warranty\n    [2] => modules/equipment/warranty/delete_warranty.php\n    [3] => Delete Warranty\n    [4] => X\n    [5] => 3\n    [6] => No\n    [7] => On\n    [8] => form3.png\n    [9] => 1\n    [10] => 106\n)\n', '/smm/sysadmin/edit_user_links.php'),
(1383, '::1', 'root', '2017-04-09 09:44:40', 'Pressed submit button', '/smm/modules/equipment/deploy/add_deploy.php'),
(1384, '::1', 'root', '2017-04-09 09:44:40', 'Query Executed: INSERT INTO deploy(id, room, location, deployDate, employee_id) VALUES(?,?,?,?,?)\r\nArray\n(\n    [0] => isssi\n    [1] => \n    [2] => 1010\n    [3] => 10th Floor\n    [4] => 2017-04-09\n    [5] => 1\n)\n', '/smm/modules/equipment/deploy/add_deploy.php'),
(1385, '::1', 'root', '2017-04-09 09:44:46', 'Pressed submit button', '/smm/modules/equipment/deploy_equipment/add_deploy_equipment.php'),
(1386, '::1', 'root', '2017-04-09 09:44:47', 'Query Executed: INSERT INTO deploy_equipment(id, equipment_id, deploy_id) VALUES(?,?,?)\r\nArray\n(\n    [0] => iii\n    [1] => \n    [2] => 10\n    [3] => 3\n)\n', '/smm/modules/equipment/deploy_equipment/add_deploy_equipment.php'),
(1387, '::1', 'root', '2017-04-09 09:45:41', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1388, '::1', 'root', '2017-04-09 09:45:41', 'Query Executed: INSERT INTO disposal(id, method, remarks, remove_date, dispose_date, days, equipment_id, deploy_id) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssiii\n    [1] => \n    [2] => Throw into Electronic Basket\n    [3] => No Difficulty\n    [4] => 2017-04-09\n    [5] => 2017-04-09\n    [6] => \n    [7] => 10\n    [8] => 3\n)\n', '/smm/modules/equipment/disposal/add_disposal.php'),
(1389, '::1', 'root', '2017-04-09 09:46:03', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` WHERE `rating` >="2" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1390, '::1', 'root', '2017-04-09 10:54:44', 'Logged in', '/smm/login.php'),
(1391, '::1', 'root', '2017-04-09 10:55:20', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` WHERE `rating` >="1" ORDER BY `rating` ASC ', '/smm/modules/reports/report_rating_type.php'),
(1392, '::1', 'root', '2017-04-09 11:02:49', 'Pressed cancel button', '/smm/modules/equipment/equipment/delete_equipment.php'),
(1393, '::1', 'root', '2017-04-09 11:07:30', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` ORDER BY `rating` ASC ', '/smm/modules/reports/report_longevity.php'),
(1394, '::1', 'root', '2017-04-09 11:07:54', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` ORDER BY `rating` ASC ', '/smm/modules/reports/report_longevity.php'),
(1395, '::1', 'root', '2017-04-09 11:08:35', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `equipment`.`description`, `disposal`.`reason`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` ORDER BY `rating` ASC ', '/smm/modules/reports/report_longevity.php'),
(1396, '::1', 'root', '2017-04-09 11:08:45', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `equipment`.`description`, `disposal`.`reason`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` ORDER BY `rating` ASC ', '/smm/modules/reports/report_longevity.php'),
(1397, '::1', 'root', '2017-04-09 11:10:50', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `equipment`.`description`,`deploy`.`room`, `deploy`.`location`, `disposal`.`reason`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` ORDER BY `rating` ASC ', '/smm/modules/reports/report_longevity.php'),
(1398, '::1', 'root', '2017-04-09 11:12:51', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `equipment`.`description`,`deploy`.`room`, `deploy`.`location`, `disposal`.`reason`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` ORDER BY `rating` ASC ', '/smm/modules/reports/report_longevity.php'),
(1399, '::1', 'root', '2017-04-09 15:12:31', 'Logged in', '/smm/login.php'),
(1400, '::1', 'root', '2017-04-09 15:12:48', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `equipment`.`description`,`deploy`.`room`, `deploy`.`location`, `disposal`.`reason`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` ORDER BY `rating` ASC ', '/smm/modules/reports/report_longevity.php'),
(1401, '::1', 'root', '2017-04-09 15:13:19', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `equipment`.`description`,`deploy`.`room`, `deploy`.`location`, `disposal`.`reason`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` ORDER BY `rating` ASC ', '/smm/modules/reports/report_longevity.php'),
(1402, '::1', 'root', '2017-04-09 15:15:25', 'Pressed submit button', '/smm/modules/equipment/equipment/add_equipment.php'),
(1403, '::1', 'root', '2017-04-09 15:15:26', 'Query Executed: INSERT INTO equipment(id, name, type, brand, description, function, price, rating) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => isssssdi\n    [1] => \n    [2] => N4050\n    [3] => Laptop\n    [4] => DELL\n    [5] => Laptop for Educational Uses\n    [6] => ASD\n    [7] => 20000\n    [8] => 7.5\n)\n', '/smm/modules/equipment/equipment/add_equipment.php'),
(1404, '::1', 'root', '2017-04-09 15:15:29', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `equipment`.`description`,`deploy`.`room`, `deploy`.`location`, `disposal`.`reason`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` ORDER BY `rating` ASC ', '/smm/modules/reports/report_longevity.php'),
(1405, '::1', 'root', '2017-04-09 15:16:06', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `equipment`.`description`,`deploy`.`room`, `deploy`.`location`, `disposal`.`reason`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` WHERE `disposal`.`remove_date` != NULL ORDER BY `rating` ASC ', '/smm/modules/reports/report_longevity.php'),
(1406, '::1', 'root', '2017-04-09 15:18:05', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `equipment`.`description`,`deploy`.`room`, `deploy`.`location`, `disposal`.`reason`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` WHERE `disposal`.`remove_date` IS NOT NULL ORDER BY `rating` ASC ', '/smm/modules/reports/report_longevity.php'),
(1407, '::1', 'root', '2017-04-09 15:18:27', 'Pressed submit button', '/smm/modules/equipment/deploy_equipment/add_deploy_equipment.php'),
(1408, '::1', 'root', '2017-04-09 15:18:28', 'Query Executed: INSERT INTO deploy_equipment(id, equipment_id, deploy_id) VALUES(?,?,?)\r\nArray\n(\n    [0] => iii\n    [1] => \n    [2] => 11\n    [3] => 3\n)\n', '/smm/modules/equipment/deploy_equipment/add_deploy_equipment.php'),
(1409, '::1', 'root', '2017-04-09 15:19:14', 'Pressed submit button', '/smm/modules/equipment/disposal/add_disposal.php'),
(1410, '::1', 'root', '2017-04-09 15:19:14', 'Query Executed: INSERT INTO disposal(id, reason, method, remarks, remove_date, dispose_date, equipment_id) VALUES(?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => isssssi\n    [1] => \n    [2] => Broken Screen\n    [3] => Disposing Unusable Parts\n    [4] => Difficulty was easy\n    [5] => 2017-03-10\n    [6] => 2017-03-13\n    [7] => 11\n)\n', '/smm/modules/equipment/disposal/add_disposal.php'),
(1411, '::1', 'root', '2017-04-09 15:19:20', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `equipment`.`description`,`deploy`.`room`, `deploy`.`location`, `disposal`.`reason`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` WHERE `disposal`.`remove_date` IS NOT NULL ORDER BY `rating` ASC ', '/smm/modules/reports/report_longevity.php'),
(1412, '::1', 'root', '2017-04-09 15:24:46', 'Query executed: SELECT DISTINCT `equipment`.`name`, `equipment`.`brand`, `equipment`.`rating`, `equipment`.`price`, `equipment`.`description`,`deploy`.`room`, `deploy`.`location`, `disposal`.`reason`, `deploy`.`deployDate`, `disposal`.`remove_date` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `disposal` ON `equipment`.`id` = `disposal`.`equipment_id` WHERE `disposal`.`remove_date` IS NOT NULL ORDER BY `rating` ASC ', '/smm/modules/reports/report_longevity.php'),
(1413, '::1', 'root', '2017-04-09 17:13:26', 'Logged in', '/smm/login.php'),
(1414, '::1', 'root', '2017-04-09 17:21:41', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="" ORDER BY `price` ASC ', '/smm/modules/reports/report_maintenance_type.php'),
(1415, '::1', 'root', '2017-04-09 17:26:03', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="" ORDER BY `price` ASC ', '/smm/modules/reports/report_maintenance_type.php'),
(1416, '::1', 'root', '2017-04-09 17:32:02', 'Query executed: SELECT * FROM `equipment` WHERE `price` >=""', '/smm/modules/reports/report_maintenance_type.php'),
(1417, '::1', 'root', '2017-04-09 17:32:37', 'Query executed: SELECT * FROM `equipment` WHERE `price` >=""', '/smm/modules/reports/report_maintenance_type.php'),
(1418, '::1', 'root', '2017-04-09 17:35:42', 'Query executed: SELECT * FROM `equipment` WHERE `price` >="2017-04-09"', '/smm/modules/reports/report_maintenance_type.php'),
(1419, '::1', 'root', '2017-04-09 17:37:51', 'Query executed: SELECT * FROM `disposal` WHERE `remove_date` >="2017-04-09"', '/smm/modules/reports/report_maintenance_type.php'),
(1420, '::1', 'root', '2017-04-09 17:38:17', 'Query executed: SELECT * FROM `disposal` WHERE `remove_date` >="2017-04-09"', '/smm/modules/reports/report_maintenance_type.php'),
(1421, '::1', 'root', '2017-04-09 17:40:13', 'Query executed: SELECT * FROM `disposal` WHERE `remove_date` >="2017-04-09"', '/smm/modules/reports/report_maintenance_type.php'),
(1422, '::1', 'root', '2017-04-09 17:40:39', 'Query executed: SELECT * FROM `disposal` WHERE `remove_date` >="2017-04-09"', '/smm/modules/reports/report_maintenance_type.php'),
(1423, '::1', 'root', '2017-04-09 17:50:08', 'Query executed: SELECT `equipment`.`name`, `equipment`.`brand`, `equipment`.`type`, `equipment`.`price`, `deploy`.`location`,`deploy`.`room`, `maintenance`.`start_date`, `maintenance`.`end_date`,`maintenance`.`status` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `maintenance` ON `equipment`.`id` = `maintenance`.`equipment_id` WHERE `maintenance`.`start_date` >="2017-04-09" AND `maintenance`.`type` = ""', '/smm/modules/reports/report_maintenance_type.php'),
(1424, '::1', 'root', '2017-04-09 17:51:20', 'Query executed: SELECT `equipment`.`name`, `equipment`.`brand`, `equipment`.`type`, `equipment`.`price`, `deploy`.`location`,`deploy`.`room`, `maintenance`.`start_date`, `maintenance`.`end_date`,`maintenance`.`status` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `maintenance` ON `equipment`.`id` = `maintenance`.`equipment_id` WHERE `maintenance`.`start_date` >="2017-04-09" AND `maintenance`.`type` = ""', '/smm/modules/reports/report_maintenance_type.php'),
(1425, '::1', 'root', '2017-04-09 17:52:22', 'Query executed: SELECT `equipment`.`name`, `equipment`.`brand`, `equipment`.`type`, `equipment`.`price`, `deploy`.`location`,`deploy`.`room`, `maintenance`.`start_date`, `maintenance`.`end_date`,`maintenance`.`status` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `maintenance` ON `equipment`.`id` = `maintenance`.`equipment_id` WHERE `maintenance`.`start_date` >="2017-04-09" AND `maintenance`.`type` = "Corrective"', '/smm/modules/reports/report_maintenance_type.php'),
(1426, '::1', 'root', '2017-04-09 17:53:00', 'Pressed submit button', '/smm/modules/maintenance/maintenance/add_maintenance.php'),
(1427, '::1', 'root', '2017-04-09 17:53:11', 'Pressed submit button', '/smm/modules/maintenance/maintenance/add_maintenance.php'),
(1428, '::1', 'root', '2017-04-09 17:53:11', 'Query Executed: INSERT INTO maintenance(id, type, start_date, end_date, time, state, reason, status, service_provider, cost, equipment_id, employee_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssssssdii\n    [1] => \n    [2] => Corrective\n    [3] => 2017-04-09\n    [4] => 2017-04-15\n    [5] => 7:30\n    [6] => Subpar\n    [7] => AS\n    [8] => Incomplete\n    [9] => ADATA\n    [10] => 8500\n    [11] => 10\n    [12] => 1\n)\n', '/smm/modules/maintenance/maintenance/add_maintenance.php'),
(1429, '::1', 'root', '2017-04-09 17:53:11', 'Query Executed: INSERT INTO maintenance_document(id, document, remarks, maintenance_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => issi\n    [1] => \n    [2] => ef078c34896429e8f37ba46b5f2fc15b1780e490Context.jpg\n    [3] => 1\n    [4] => 1\n)\n', '/smm/modules/maintenance/maintenance/add_maintenance.php'),
(1430, '::1', 'root', '2017-04-09 17:53:18', 'Query executed: SELECT `equipment`.`name`, `equipment`.`brand`, `equipment`.`type`, `equipment`.`price`, `deploy`.`location`,`deploy`.`room`, `maintenance`.`start_date`, `maintenance`.`end_date`,`maintenance`.`status` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `maintenance` ON `equipment`.`id` = `maintenance`.`equipment_id` WHERE `maintenance`.`start_date` >="2017-04-09" AND `maintenance`.`type` = "Corrective"', '/smm/modules/reports/report_maintenance_type.php'),
(1431, '::1', 'root', '2017-04-09 17:57:31', 'Query executed: SELECT `equipment`.`name`, `equipment`.`brand`, `equipment`.`type`, `equipment`.`price`, `deploy`.`location`,`deploy`.`room`, `maintenance`.`start_date`, `maintenance`.`end_date`,`maintenance`.`status` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `maintenance` ON `equipment`.`id` = `maintenance`.`equipment_id` WHERE `maintenance`.`start_date` >="2017-04-09" AND `maintenance`.`type` = "Corrective"', '/smm/modules/reports/report_maintenance_type.php'),
(1432, '::1', 'root', '2017-04-09 17:58:22', 'Query executed: SELECT `equipment`.`name`, `equipment`.`brand`, `equipment`.`type`, `equipment`.`price`, `deploy`.`location`,`deploy`.`room`, `maintenance`.`start_date`, `maintenance`.`end_date`,`maintenance`.`status` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `maintenance` ON `equipment`.`id` = `maintenance`.`equipment_id` WHERE `maintenance`.`start_date` >="2017-04-09" AND `maintenance`.`type` = "Corrective"', '/smm/modules/reports/report_maintenance_type.php'),
(1433, '::1', 'root', '2017-04-09 17:58:47', 'Query executed: SELECT `equipment`.`name`, `equipment`.`brand`, `equipment`.`type`, `equipment`.`price`, `deploy`.`location`,`deploy`.`room`, `maintenance`.`start_date`, `maintenance`.`end_date`,`maintenance`.`status`, `maintenance`.`cost` FROM `equipment` LEFT JOIN `deploy_equipment` ON `equipment`.`id` = `deploy_equipment`.`equipment_id` LEFT JOIN `deploy` ON `deploy_equipment`.`deploy_id` = `deploy`.`id` LEFT JOIN `maintenance` ON `equipment`.`id` = `maintenance`.`equipment_id` WHERE `maintenance`.`start_date` >="2017-04-09" AND `maintenance`.`type` = "Corrective"', '/smm/modules/reports/report_maintenance_type.php'),
(1434, '::1', 'root', '2017-04-09 18:11:32', 'Pressed submit button', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(1435, '::1', 'root', '2017-04-09 18:11:32', 'Query Executed: INSERT INTO purchase_data(id, purchase_date, receive_date, receiver, person, location, contact, equiment_id) VALUES(?,?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssssi\n    [1] => \n    [2] => 2017-04-09\n    [3] => 2017-04-09\n    [4] => Sir Jojo\n    [5] => Octagon\n    [6] => MOA\n    [7] => 09162839011\n    [8] => 10\n)\n', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(1436, '::1', 'root', '2017-04-09 18:11:32', 'Query Executed: INSERT INTO purchase_data_document(id, document, remarks, purchase_data_id) VALUES(?,?,?,?)\r\nArray\n(\n    [0] => issi\n    [1] => \n    [2] => 0a1cfe3f115cc903f3107a5582947b35abf20244DFD 2.jpg\n    [3] => X\n    [4] => 1\n)\n', '/smm/modules/equipment/purchase_data/add_purchase_data.php'),
(1437, '::1', 'root', '2017-04-09 18:11:56', 'Pressed submit button', '/smm/modules/equipment/warranty/add_warranty.php'),
(1438, '::1', 'root', '2017-04-09 18:11:57', 'Query Executed: INSERT INTO warranty(id, start_date, end_date, assigned, copy, purchase_id, equipment_id) VALUES(?,?,?,?,?,?,?)\r\nArray\n(\n    [0] => issssii\n    [1] => \n    [2] => 2017-04-09\n    [3] => 2017-04-09\n    [4] => Adrian Tobias\n    [5] => ea04728f1744a0da82ff40a5539f969a08a50384DFD 3.jpg\n    [6] => 1\n    [7] => 10\n)\n', '/smm/modules/equipment/warranty/add_warranty.php');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `setting` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`setting`, `value`) VALUES
('Max Attachment Height', '0'),
('Max Attachment Size (MB)', '0'),
('Max Attachment Width', '0'),
('Security Level', 'HIGH');

-- --------------------------------------------------------

--
-- Table structure for table `system_skins`
--

CREATE TABLE `system_skins` (
  `skin_id` int(11) NOT NULL,
  `skin_name` varchar(255) NOT NULL,
  `header` varchar(255) NOT NULL,
  `footer` varchar(255) NOT NULL,
  `master_css` varchar(255) NOT NULL,
  `colors_css` varchar(255) NOT NULL,
  `fonts_css` varchar(255) NOT NULL,
  `override_css` varchar(255) NOT NULL,
  `icon_set` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `system_skins`
--

INSERT INTO `system_skins` (`skin_id`, `skin_name`, `header`, `footer`, `master_css`, `colors_css`, `fonts_css`, `override_css`, `icon_set`) VALUES
(1, 'Cobalt Default', 'skins/default_header.php', 'skins/default_footer.php', 'cobalt_master.css', 'cobalt_colors.css', 'cobalt_fonts.css', 'cobalt_override.css', 'cobalt'),
(2, 'Cobalt Minimal', 'skins/minimal_header.php', 'skins/minimal_footer.php', 'cobalt_minimal.css', 'cobalt_minimal.css', 'cobalt_minimal.css', 'cobalt_minimal.css', 'cobalt'),
(3, 'After Sunset', 'skins/default_header.php', 'skins/default_footer.php', 'after_sunset_master.css', 'after_sunset_colors.css', 'after_sunset_fonts.css', 'after_sunset_override.css', 'cobalt'),
(4, 'Hello There', 'skins/default_header.php', 'skins/default_footer.php', 'hello_there_master.css', 'hello_there_colors.css', 'hello_there_fonts.css', 'hello_there_override.css', 'cobalt'),
(5, 'Gold Titanium', 'skins/default_header.php', 'skins/default_footer.php', 'gold_titanium_master.css', 'gold_titanium_colors.css', 'gold_titanium_fonts.css', 'gold_titanium_override.css', 'cobalt'),
(6, 'Summer Rain', 'skins/default_header.php', 'skins/default_footer.php', 'summer_rain_master.css', 'summer_rain_colors.css', 'summer_rain_fonts.css', 'summer_rain_override.css', 'cobalt'),
(7, 'Salmon Impression', 'skins/default_header.php', 'skins/default_footer.php', 'salmon_impression_master.css', 'salmon_impression_colors.css', 'salmon_impression_fonts.css', 'salmon_impression_override.css', 'cobalt'),
(8, 'Royal Amethyst', 'skins/default_header.php', 'skins/default_footer.php', 'royal_amethyst_master.css', 'royal_amethyst_colors.css', 'royal_amethyst_fonts.css', 'royal_amethyst_override.css', 'cobalt'),
(9, 'Red Decadence', 'skins/default_header.php', 'skins/default_footer.php', 'red_decadence_master.css', 'red_decadence_colors.css', 'red_decadence_fonts.css', 'red_decadence_override.css', 'cobalt'),
(10, 'Modern Eden', 'skins/default_header.php', 'skins/default_footer.php', 'modern_eden_master.css', 'modern_eden_colors.css', 'modern_eden_fonts.css', 'modern_eden_override.css', 'cobalt'),
(11, 'Warm Teal', 'skins/default_header.php', 'skins/default_footer.php', 'warm_teal_master.css', 'warm_teal_colors.css', 'warm_teal_fonts.css', 'warm_teal_override.css', 'cobalt'),
(12, 'Purple Rain', 'skins/default_header.php', 'skins/default_footer.php', 'purple_rain_master.css', 'purple_rain_colors.css', 'purple_rain_fonts.css', 'purple_rain_override.css', 'cobalt');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `iteration` int(11) NOT NULL,
  `method` varchar(255) NOT NULL,
  `person_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `skin_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `salt`, `iteration`, `method`, `person_id`, `role_id`, `skin_id`) VALUES
('root', '$2y$12$esc2I5X4hcbI6waT09MrmOjI7eIfKDbnRiykd9wssOhSrG7CHhfTe', 'esc2I5X4hcbI6waT09MrmQ', 12, 'blowfish', 1, 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `user_links`
--

CREATE TABLE `user_links` (
  `link_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `target` varchar(255) NOT NULL,
  `descriptive_title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `passport_group_id` int(11) NOT NULL,
  `show_in_tasklist` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_links`
--

INSERT INTO `user_links` (`link_id`, `name`, `target`, `descriptive_title`, `description`, `passport_group_id`, `show_in_tasklist`, `status`, `icon`, `priority`) VALUES
(1, 'Module Control', 'sysadmin/module_control.php', 'Module Control', 'Enable or disable system modules', 2, 'Yes', 'On', 'modulecontrol.png', 0),
(2, 'Set User Passports', 'sysadmin/set_user_passports.php', 'Set User Passports', 'Change the passport settings of system users', 2, 'Yes', 'On', 'passport.png', 0),
(3, 'Security Monitor', 'sysadmin/security_monitor.php', 'Security Monitor', 'Examine the system log', 2, 'Yes', 'On', 'security3.png', 0),
(4, 'Add person', 'sysadmin/add_person.php', 'Add Person', '', 2, 'No', 'On', 'form.png', 0),
(5, 'Edit person', 'sysadmin/edit_person.php', 'Edit Person', '', 2, 'No', 'On', 'form.png', 0),
(6, 'View person', 'sysadmin/listview_person.php', 'Person', '', 2, 'Yes', 'On', 'persons.png', 0),
(7, 'Delete person', 'sysadmin/delete_person.php', 'Delete Person', '', 2, 'No', 'On', 'form.png', 0),
(8, 'Add user', 'sysadmin/add_user.php', 'Add User', '', 2, 'No', 'On', 'form.png', 0),
(9, 'Edit user', 'sysadmin/edit_user.php', 'Edit User', '', 2, 'No', 'On', 'form.png', 0),
(10, 'View user', 'sysadmin/listview_user.php', 'User', '', 2, 'Yes', 'On', 'card.png', 0),
(11, 'Delete user', 'sysadmin/delete_user.php', 'Delete User', '', 2, 'No', 'On', 'form.png', 0),
(12, 'Add user role', 'sysadmin/add_user_role.php', 'Add User Role', '', 2, 'No', 'On', 'form.png', 0),
(13, 'Edit user role', 'sysadmin/edit_user_role.php', 'Edit User Role', '', 2, 'No', 'On', 'form.png', 0),
(14, 'View user role', 'sysadmin/listview_user_role.php', 'User Roles', '', 2, 'Yes', 'On', 'roles.png', 0),
(15, 'Delete user role', 'sysadmin/delete_user_role.php', 'Delete User Role', '', 2, 'No', 'On', 'form.png', 0),
(16, 'Add system settings', 'sysadmin/add_system_settings.php', 'Add System Settings', '', 2, 'No', 'On', 'form.png', 0),
(17, 'Edit system settings', 'sysadmin/edit_system_settings.php', 'Edit System Settings', '', 2, 'No', 'On', 'form.png', 0),
(18, 'View system settings', 'sysadmin/listview_system_settings.php', 'System Settings', '', 2, 'Yes', 'On', 'system_settings.png', 0),
(19, 'Delete system settings', 'sysadmin/delete_system_settings.php', 'Delete System Settings', '', 2, 'No', 'On', 'form.png', 0),
(20, 'Add user links', 'sysadmin/add_user_links.php', 'Add User Links', '', 2, 'No', 'On', 'form.png', 0),
(21, 'Edit user links', 'sysadmin/edit_user_links.php', 'Edit User Links', '', 2, 'No', 'On', 'form.png', 0),
(22, 'View user links', 'sysadmin/listview_user_links.php', 'User Links', '', 2, 'Yes', 'On', 'links.png', 0),
(23, 'Delete user links', 'sysadmin/delete_user_links.php', 'Delete User Links', '', 2, 'No', 'On', 'form.png', 0),
(24, 'Add user passport groups', 'sysadmin/add_user_passport_groups.php', 'Add User Passport Groups', '', 2, 'No', 'On', 'form.png', 0),
(25, 'Edit user passport groups', 'sysadmin/edit_user_passport_groups.php', 'Edit User Passport Groups', '', 2, 'No', 'On', 'form.png', 0),
(26, 'View user passport groups', 'sysadmin/listview_user_passport_groups.php', 'User Passport Groups', '', 2, 'Yes', 'On', 'passportgroup.png', 0),
(27, 'Delete user passport groups', 'sysadmin/delete_user_passport_groups.php', 'Delete User Passport Groups', '', 2, 'No', 'On', 'form.png', 0),
(28, 'Add system skins', 'sysadmin/add_system_skins.php', 'Add System Skins', '', 2, 'No', 'On', 'form.png', 0),
(29, 'Edit system skins', 'sysadmin/edit_system_skins.php', 'Edit System Skins', '', 2, 'No', 'On', 'form.png', 0),
(30, 'View system skins', 'sysadmin/listview_system_skins.php', 'System Skins', '', 2, 'Yes', 'On', 'system_skins.png', 0),
(31, 'Delete system skins', 'sysadmin/delete_system_skins.php', 'Delete System Skins', '', 2, 'No', 'On', 'form.png', 0),
(32, 'Reset Password', 'sysadmin/reset_password.php', 'Reset Password', '', 2, 'Yes', 'On', 'lock_big.png', 0),
(33, 'Add cobalt sst', 'sst/add_cobalt_sst.php', 'Add Cobalt SST', '', 2, 'No', 'On', 'form3.png', 0),
(34, 'Edit cobalt sst', 'sst/edit_cobalt_sst.php', 'Edit Cobalt SST', '', 2, 'No', 'On', 'form3.png', 0),
(35, 'View cobalt sst', 'sst/listview_cobalt_sst.php', 'Cobalt SST', '', 2, 'Yes', 'On', 'form3.png', 0),
(36, 'Delete cobalt sst', 'sst/delete_cobalt_sst.php', 'Delete Cobalt SST', '', 2, 'No', 'On', 'form3.png', 0),
(53, 'Add disposal', 'modules/equipment/disposal/add_disposal.php', 'Add Disposal', '', 3, 'No', 'On', 'form3.png', 0),
(54, 'Edit disposal', 'modules/equipment/disposal/edit_disposal.php', 'Edit Disposal', '', 3, 'No', 'On', 'form3.png', 0),
(55, 'View disposal', 'modules/equipment/disposal/listview_disposal.php', 'Disposal', '', 3, 'Yes', 'On', 'form3.png', 0),
(56, 'Delete disposal', 'modules/equipment/disposal/delete_disposal.php', 'Delete Disposal', '', 3, 'No', 'On', 'form3.png', 0),
(57, 'Add employee', 'modules/staff/employee/add_employee.php', 'Add Employee', '', 4, 'No', 'On', 'form3.png', 0),
(58, 'Edit employee', 'modules/staff/employee/edit_employee.php', 'Edit Employee', '', 4, 'No', 'On', 'form3.png', 0),
(59, 'View employee', 'modules/staff/employee/listview_employee.php', 'Employee', '', 4, 'Yes', 'On', 'form3.png', 0),
(60, 'Delete employee', 'modules/staff/employee/delete_employee.php', 'Delete Employee', '', 4, 'No', 'On', 'form3.png', 0),
(61, 'Add equipment', 'modules/equipment/equipment/add_equipment.php', 'Add Equipment', '', 3, 'No', 'On', 'form3.png', 0),
(62, 'Edit equipment', 'modules/equipment/equipment/edit_equipment.php', 'Edit Equipment', '', 3, 'No', 'On', 'form3.png', 0),
(63, 'View equipment', 'modules/equipment/equipment/listview_equipment.php', 'Equipment', '', 3, 'Yes', 'On', 'form3.png', 0),
(64, 'Delete equipment', 'modules/equipment/equipment/delete_equipment.php', 'Delete Equipment', '', 3, 'No', 'On', 'form3.png', 0),
(73, 'Add purchase data', 'modules/equipment/purchase_data/add_purchase_data.php', 'Add Purchase Data', '', 3, 'No', 'On', 'form3.png', 0),
(74, 'Edit purchase data', 'modules/equipment/purchase_data/edit_purchase_data.php', 'Edit Purchase Data', '', 3, 'No', 'On', 'form3.png', 0),
(75, 'View purchase data', 'modules/equipment/purchase_data/listview_purchase_data.php', 'Purchase Data', '', 3, 'Yes', 'On', 'form3.png', 0),
(76, 'Delete purchase data', 'modules/equipment/purchase_data/delete_purchase_data.php', 'Delete Purchase Data', '', 3, 'No', 'On', 'form3.png', 0),
(77, 'Add purchase data document', 'modules/equipment/purchase_data_document/add_purchase_data_document.php', 'Add Purchase Data Document', '', 3, 'No', 'On', 'form3.png', 0),
(78, 'Edit purchase data document', 'modules/equipment/purchase_data_document/edit_purchase_data_document.php', 'Edit Purchase Data Document', '', 3, 'No', 'On', 'form3.png', 0),
(79, 'View purchase data document', 'modules/equipment/purchase_data_document/listview_purchase_data_document.php', 'Purchase Data Document', '', 3, 'Yes', 'On', 'form3.png', 0),
(80, 'Delete purchase data document', 'modules/equipment/purchase_data_document/delete_purchase_data_document.php', 'Delete Purchase Data Document', '', 3, 'No', 'On', 'form3.png', 0),
(81, 'Add warranty', 'modules/equipment/warranty/add_warranty.php', 'Add Warranty', '', 3, 'No', 'On', 'form3.png', 0),
(82, 'Edit warranty', 'modules/equipment/warranty/edit_warranty.php', 'Edit Warranty', '', 3, 'No', 'On', 'form3.png', 0),
(83, 'View warranty', 'modules/equipment/warranty/listview_warranty.php', 'Warranty', '', 3, 'Yes', 'On', 'form3.png', 0),
(85, 'Report', 'modules/reports/report.php', 'Reports', 'X', 3, 'Yes', 'On', 'form3.png', 1),
(86, 'Add deploy', 'modules/equipment/deploy/add_deploy.php', 'Add Deploy', '', 1, 'No', 'On', 'form3.png', 0),
(87, 'Edit deploy', 'modules/equipment/deploy/edit_deploy.php', 'Edit Deploy', '', 1, 'No', 'On', 'form3.png', 0),
(88, 'View deploy', 'modules/equipment/deploy/listview_deploy.php', 'Deploy', '', 1, 'Yes', 'On', 'form3.png', 0),
(89, 'Delete deploy', 'modules/equipment/deploy/delete_deploy.php', 'Delete Deploy', '', 1, 'No', 'On', 'form3.png', 0),
(94, 'Add maintenance', 'modules/maintenance/maintenance/add_maintenance.php', 'Add Maintenance', '', 5, 'No', 'On', 'form3.png', 0),
(95, 'Edit maintenance', 'modules/maintenance/maintenance/edit_maintenance.php', 'Edit Maintenance', '', 5, 'No', 'On', 'form3.png', 0),
(96, 'View maintenance', 'modules/maintenance/maintenance/listview_maintenance.php', 'Maintenance', '', 5, 'Yes', 'On', 'form3.png', 0),
(97, 'Delete maintenance', 'modules/maintenance/maintenance/delete_maintenance.php', 'Delete Maintenance', '', 5, 'No', 'On', 'form3.png', 0),
(98, 'Add maintenance document', 'modules/maintenance/maintenance_document/add_maintenance_document.php', 'Add Maintenance Document', '', 5, 'No', 'On', 'form3.png', 0),
(99, 'Edit maintenance document', 'modules/maintenance/maintenance_document/edit_maintenance_document.php', 'Edit Maintenance Document', '', 5, 'No', 'On', 'form3.png', 0),
(100, 'View maintenance document', 'modules/maintenance/maintenance_document/listview_maintenance_document.php', 'Maintenance Document', '', 5, 'Yes', 'On', 'form3.png', 0),
(101, 'Delete maintenance document', 'modules/maintenance/maintenance_document/delete_maintenance_document.php', 'Delete Maintenance Document', '', 5, 'No', 'On', 'form3.png', 0),
(102, 'Add deploy equipment', 'modules/equipment/deploy_equipment/add_deploy_equipment.php', 'Add Deploy Equipment', '', 1, 'No', 'On', 'form3.png', 0),
(103, 'Edit deploy equipment', 'modules/equipment/deploy_equipment/edit_deploy_equipment.php', 'Edit Deploy Equipment', '', 1, 'No', 'On', 'form3.png', 0),
(104, 'View deploy equipment', 'modules/equipment/deploy_equipment/listview_deploy_equipment.php', 'Deploy Equipment', '', 1, 'Yes', 'On', 'form3.png', 0),
(105, 'Delete deploy equipment', 'modules/equipment/deploy_equipment/delete_deploy_equipment.php', 'Delete Deploy Equipment', '', 1, 'No', 'On', 'form3.png', 0),
(106, 'Delete warranty', 'modules/equipment/warranty/delete_warranty.php', 'Delete Warranty', 'X', 3, 'No', 'On', 'form3.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_passport`
--

CREATE TABLE `user_passport` (
  `username` varchar(255) NOT NULL,
  `link_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_passport`
--

INSERT INTO `user_passport` (`username`, `link_id`) VALUES
('root', 1),
('root', 2),
('root', 3),
('root', 4),
('root', 5),
('root', 6),
('root', 7),
('root', 8),
('root', 9),
('root', 10),
('root', 11),
('root', 12),
('root', 13),
('root', 14),
('root', 15),
('root', 16),
('root', 17),
('root', 18),
('root', 19),
('root', 20),
('root', 21),
('root', 22),
('root', 23),
('root', 24),
('root', 25),
('root', 26),
('root', 27),
('root', 28),
('root', 29),
('root', 30),
('root', 31),
('root', 32),
('root', 33),
('root', 34),
('root', 35),
('root', 36),
('root', 53),
('root', 54),
('root', 55),
('root', 56),
('root', 57),
('root', 58),
('root', 59),
('root', 60),
('root', 61),
('root', 62),
('root', 63),
('root', 64),
('root', 73),
('root', 74),
('root', 75),
('root', 76),
('root', 77),
('root', 78),
('root', 79),
('root', 80),
('root', 81),
('root', 82),
('root', 83),
('root', 85),
('root', 86),
('root', 87),
('root', 88),
('root', 89),
('root', 94),
('root', 95),
('root', 96),
('root', 97),
('root', 98),
('root', 99),
('root', 100),
('root', 101),
('root', 102),
('root', 103),
('root', 104),
('root', 105),
('root', 106);

-- --------------------------------------------------------

--
-- Table structure for table `user_passport_groups`
--

CREATE TABLE `user_passport_groups` (
  `passport_group_id` int(11) NOT NULL,
  `passport_group` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL,
  `icon` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_passport_groups`
--

INSERT INTO `user_passport_groups` (`passport_group_id`, `passport_group`, `priority`, `icon`) VALUES
(1, 'Default', 0, 'blue_folder3.png'),
(2, 'Admin', 0, 'preferences-system.png'),
(3, 'Equipment', 3, 'blue_folder3.png'),
(4, 'Staff', 2, 'blue_folder3.png'),
(5, 'Maintenance', 1, 'blue_folder3.png'),
(6, 'Assignment', 4, 'blue_folder3.png');

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `role_id` int(11) NOT NULL,
  `role` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`role_id`, `role`, `description`) VALUES
(1, 'Super Admin', 'Super admin role with 100% system privileges'),
(2, 'System Admin', 'System admin role with all sysadmin permissions');

-- --------------------------------------------------------

--
-- Table structure for table `user_role_links`
--

CREATE TABLE `user_role_links` (
  `role_id` int(11) NOT NULL,
  `link_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_role_links`
--

INSERT INTO `user_role_links` (`role_id`, `link_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(1, 13),
(1, 14),
(1, 15),
(1, 16),
(1, 17),
(1, 18),
(1, 19),
(1, 20),
(1, 21),
(1, 22),
(1, 23),
(1, 24),
(1, 25),
(1, 26),
(1, 27),
(1, 28),
(1, 29),
(1, 30),
(1, 31),
(1, 32),
(1, 33),
(1, 34),
(1, 35),
(1, 36),
(1, 53),
(1, 54),
(1, 55),
(1, 56),
(1, 57),
(1, 58),
(1, 59),
(1, 60),
(1, 61),
(1, 62),
(1, 63),
(1, 64),
(1, 73),
(1, 74),
(1, 75),
(1, 76),
(1, 77),
(1, 78),
(1, 79),
(1, 80),
(1, 81),
(1, 82),
(1, 83),
(1, 85),
(1, 86),
(1, 87),
(1, 88),
(1, 89),
(1, 94),
(1, 95),
(1, 96),
(1, 97),
(1, 98),
(1, 99),
(1, 100),
(1, 101),
(1, 102),
(1, 103),
(1, 104),
(1, 105),
(1, 106),
(2, 1),
(2, 2),
(2, 3),
(2, 4),
(2, 5),
(2, 6),
(2, 7),
(2, 8),
(2, 9),
(2, 10),
(2, 11),
(2, 12),
(2, 13),
(2, 14),
(2, 15),
(2, 16),
(2, 17),
(2, 18),
(2, 19),
(2, 20),
(2, 21),
(2, 22),
(2, 23),
(2, 24),
(2, 25),
(2, 26),
(2, 27),
(2, 28),
(2, 29),
(2, 30),
(2, 31),
(2, 32),
(2, 33),
(2, 34),
(2, 35),
(2, 36);

-- --------------------------------------------------------

--
-- Table structure for table `warranty`
--

CREATE TABLE `warranty` (
  `id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `assigned` text NOT NULL,
  `copy` varchar(255) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `equipment_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `warranty`
--

INSERT INTO `warranty` (`id`, `start_date`, `end_date`, `assigned`, `copy`, `purchase_id`, `equipment_id`) VALUES
(1, '2017-04-09', '2017-04-09', 'Adrian Tobias', 'ea04728f1744a0da82ff40a5539f969a08a50384DFD 3.jpg', 1, 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cobalt_reporter`
--
ALTER TABLE `cobalt_reporter`
  ADD PRIMARY KEY (`module_name`,`report_name`);

--
-- Indexes for table `cobalt_sst`
--
ALTER TABLE `cobalt_sst`
  ADD PRIMARY KEY (`auto_id`);

--
-- Indexes for table `deploy`
--
ALTER TABLE `deploy`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `deploy_equipment`
--
ALTER TABLE `deploy_equipment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `equipment_id` (`equipment_id`),
  ADD KEY `assignee_id` (`deploy_id`);

--
-- Indexes for table `disposal`
--
ALTER TABLE `disposal`
  ADD PRIMARY KEY (`id`),
  ADD KEY `equipment_id` (`equipment_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `maintenance`
--
ALTER TABLE `maintenance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `equipment_id` (`equipment_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `maintenance_document`
--
ALTER TABLE `maintenance_document`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`person_id`);

--
-- Indexes for table `purchase_data`
--
ALTER TABLE `purchase_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `equiment_id` (`equiment_id`);

--
-- Indexes for table `purchase_data_document`
--
ALTER TABLE `purchase_data_document`
  ADD PRIMARY KEY (`id`),
  ADD KEY `purchase_data_id` (`purchase_data_id`);

--
-- Indexes for table `system_log`
--
ALTER TABLE `system_log`
  ADD PRIMARY KEY (`entry_id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`setting`);

--
-- Indexes for table `system_skins`
--
ALTER TABLE `system_skins`
  ADD PRIMARY KEY (`skin_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `user_links`
--
ALTER TABLE `user_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `user_passport`
--
ALTER TABLE `user_passport`
  ADD PRIMARY KEY (`username`,`link_id`);

--
-- Indexes for table `user_passport_groups`
--
ALTER TABLE `user_passport_groups`
  ADD PRIMARY KEY (`passport_group_id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `user_role_links`
--
ALTER TABLE `user_role_links`
  ADD PRIMARY KEY (`role_id`,`link_id`);

--
-- Indexes for table `warranty`
--
ALTER TABLE `warranty`
  ADD PRIMARY KEY (`id`),
  ADD KEY `purchase_id` (`purchase_id`),
  ADD KEY `equipment_equipment_id` (`equipment_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cobalt_sst`
--
ALTER TABLE `cobalt_sst`
  MODIFY `auto_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `deploy`
--
ALTER TABLE `deploy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `deploy_equipment`
--
ALTER TABLE `deploy_equipment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `disposal`
--
ALTER TABLE `disposal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `maintenance`
--
ALTER TABLE `maintenance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `maintenance_document`
--
ALTER TABLE `maintenance_document`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `person`
--
ALTER TABLE `person`
  MODIFY `person_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `purchase_data`
--
ALTER TABLE `purchase_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `purchase_data_document`
--
ALTER TABLE `purchase_data_document`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `system_log`
--
ALTER TABLE `system_log`
  MODIFY `entry_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1439;
--
-- AUTO_INCREMENT for table `system_skins`
--
ALTER TABLE `system_skins`
  MODIFY `skin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `user_links`
--
ALTER TABLE `user_links`
  MODIFY `link_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;
--
-- AUTO_INCREMENT for table `user_passport_groups`
--
ALTER TABLE `user_passport_groups`
  MODIFY `passport_group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `warranty`
--
ALTER TABLE `warranty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `deploy`
--
ALTER TABLE `deploy`
  ADD CONSTRAINT `deploy_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `deploy_equipment`
--
ALTER TABLE `deploy_equipment`
  ADD CONSTRAINT `deploy_equipment_ibfk_1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `deploy_equipment_ibfk_2` FOREIGN KEY (`deploy_id`) REFERENCES `deploy` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `disposal`
--
ALTER TABLE `disposal`
  ADD CONSTRAINT `disposal_ibfk_1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `maintenance`
--
ALTER TABLE `maintenance`
  ADD CONSTRAINT `maintenance_ibfk_1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `purchase_data`
--
ALTER TABLE `purchase_data`
  ADD CONSTRAINT `purchase_data_ibfk_1` FOREIGN KEY (`equiment_id`) REFERENCES `equipment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `warranty`
--
ALTER TABLE `warranty`
  ADD CONSTRAINT `warranty_ibfk_1` FOREIGN KEY (`equipment_id`) REFERENCES `purchase_data` (`equiment_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `warranty_ibfk_2` FOREIGN KEY (`purchase_id`) REFERENCES `purchase_data` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
